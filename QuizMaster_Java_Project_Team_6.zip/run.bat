@echo off
setlocal
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -cp "lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar" -d out -sourcepath src src\quizmaster\QuizMasterApp.java src\quizmaster\service\DatabaseConnection.java
if errorlevel 1 (
    echo.
    echo Compilation failed.
    exit /b 1
)
java --enable-native-access=ALL-UNNAMED -cp "out;lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar;lib\slf4j-nop-1.7.36.jar" quizmaster.QuizMasterApp
if errorlevel 1 (
    echo.
    echo QuizMaster exited with an error.
    exit /b 1
)
endlocal
