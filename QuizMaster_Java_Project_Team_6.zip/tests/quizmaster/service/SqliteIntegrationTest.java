package quizmaster.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Comparator;
import java.util.List;
import quizmaster.model.MCQQuestion;
import quizmaster.model.Question;
import quizmaster.model.ScoreRecord;
import quizmaster.model.TrueFalseQuestion;
import quizmaster.model.User;

public final class SqliteIntegrationTest {
    private SqliteIntegrationTest() {
    }

    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("quizmaster-sqlite-test-");
        try {
            runChecks(directory);
            verifyLegacyQuestionSchemaMigration(directory.resolve("legacy"));
            verifyQuestionFileMigration(directory.resolve("file-migration"));
            verifyDatabaseFailureDoesNotFallBack(directory);
            System.out.println("QuizMaster SQLite integration tests passed.");
        } finally {
            try (var paths = Files.walk(directory)) {
                paths.sorted(Comparator.reverseOrder()).forEach(path -> {
                    try {
                        Files.deleteIfExists(path);
                    } catch (IOException exception) {
                        throw new RuntimeException("Could not clean up SQLite integration data.", exception);
                    }
                });
            }
        }
    }

    private static void runChecks(Path directory) throws Exception {
        DatabaseConnection database = new DatabaseConnection(directory.resolve("quizmaster.sqlite"));
        AuthService auth = new AuthService(database);
        QuestionService questions = new QuestionService(database);
        ScoreService scores = new ScoreService(database);
        SettingsService settings = new SettingsService(database);

        assert auth.login("ADMIN", "admin123").getRole() == User.Role.ADMIN;
        User student = auth.register("sqliteStudent", "SQLite Student", "secret123");
        assert auth.login("SQLITESTUDENT", "secret123").getDisplayName().equals("SQLite Student");
        expectIllegalArgument(() -> auth.register("sqlitestudent", "another1"));
        auth.changePassword(student.getUsername(), "secret123", "newsecret1");
        expectIllegalArgument(() -> auth.login(student.getUsername(), "secret123"));
        assert auth.login(student.getUsername(), "newsecret1") != null;
        assert auth.getStudents().stream().anyMatch(user -> user.getUsername().equals(student.getUsername()));

        questions.addCategory("Empty category");
        assert questions.getCategories().contains("Empty category");
        Question question = new MCQQuestion("SQLite Test", "Original prompt?",
                List.of("A", "B", "C", "D"), 2, "Easy", "The third option is correct.");
        questions.add(question);
        assert questions.getByCategory("SQLite Test").size() == 1;
        question = new MCQQuestion(question.getId(), "SQLite Test", "Updated prompt?",
                List.of("One", "Two", "Three", "Four"), 2, "Medium", "The third option is correct.");
        questions.update(question);
        assert questions.getAll().stream().anyMatch(item -> item.getPrompt().equals("Updated prompt?"));
        questions.renameCategory("SQLite Test", "Renamed SQLite Test");
        assert questions.getByCategory("Renamed SQLite Test").size() == 1;

        TrueFalseQuestion trueFalse = new TrueFalseQuestion("SQLite TrueFalse", "SQLite stores rows.",
                0, "Easy", "SQLite stores data in rows.");
        questions.add(trueFalse);
        Question loadedTrueFalse = questions.getByCategory("SQLite TrueFalse").get(0);
        assert loadedTrueFalse instanceof TrueFalseQuestion;
        assert loadedTrueFalse.getType().equals(Question.TRUE_FALSE_TYPE);
        assert loadedTrueFalse.getOptions().equals(List.of("True", "False", "", ""));
        try (Connection connection = database.open();
             PreparedStatement query = connection.prepareStatement("SELECT type FROM questions WHERE id = ?")) {
            query.setString(1, trueFalse.getId());
            try (ResultSet row = query.executeQuery()) {
                assert row.next();
                assert row.getString(1).equals(Question.TRUE_FALSE_TYPE);
            }
        }

        QuizService quiz = new QuizService(questions, scores);
        var session = quiz.start("Renamed SQLite Test", true);
        session.selectAnswer(session.getCurrentQuestion().getCorrectAnswer());
        ScoreRecord result = quiz.submit(session, student);
        assert result.getScore() == 1;
        assert result.getAnswerReviews().size() == 1;
        assert scores.getForUser(student.getUsername()).size() == 1;
        ScoreRecord persisted = scores.getForUser(student.getUsername()).get(0);
        assert persisted.getId().equals(result.getId());
        assert persisted.getAnswerReviews().get(0).getPrompt().equals("Updated prompt?");
        var trueFalseSession = quiz.start("SQLite TrueFalse", true);
        trueFalseSession.selectAnswer(0);
        assert quiz.submit(trueFalseSession, student).getScore() == 1;
        Path csv = directory.resolve("history.csv");
        scores.exportCsv(csv, student.getUsername());
        String csvText = Files.readString(csv);
        assert csvText.contains("Username,Category");
        assert csvText.contains(student.getUsername());
        assert csvText.contains("Renamed SQLite Test");

        settings.set(student.getUsername(), "questionCount", "20");
        settings.set(student.getUsername(), "notifications", "false");
        assert settings.getDefaultQuestionCount(student.getUsername()) == 20;
        assert !settings.areNotificationsEnabled(student.getUsername());

        questions.delete(question.getId());
        assert questions.getByCategory("Renamed SQLite Test").isEmpty();
        questions.delete(trueFalse.getId());
        assert questions.getByCategory("SQLite TrueFalse").isEmpty();
        assert !questions.getCategories().contains("Renamed SQLite Test");
        assert questions.getCategories().contains("Empty category");
        questions.deleteCategory("Empty category");
        assert !questions.getCategories().contains("Empty category");
    }

    private static void verifyLegacyQuestionSchemaMigration(Path directory) throws Exception {
        Files.createDirectories(directory);
        Path databaseFile = directory.resolve("legacy.sqlite");
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + databaseFile);
             var statement = connection.createStatement()) {
            statement.execute("CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, "
                    + "applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
            statement.execute("INSERT INTO schema_migrations(version) VALUES (1), (2)");
            statement.execute("CREATE TABLE categories (name TEXT PRIMARY KEY COLLATE NOCASE)");
            statement.execute("INSERT INTO categories(name) VALUES ('Legacy category')");
            statement.execute("CREATE TABLE questions (id TEXT PRIMARY KEY, category TEXT NOT NULL, "
                    + "prompt TEXT NOT NULL, option_a TEXT NOT NULL, option_b TEXT NOT NULL, "
                    + "option_c TEXT NOT NULL, option_d TEXT NOT NULL, correct_answer INTEGER NOT NULL, "
                    + "difficulty TEXT NOT NULL, explanation TEXT NOT NULL, "
                    + "FOREIGN KEY (category) REFERENCES categories(name))");
            statement.execute("INSERT INTO questions VALUES ('legacy-question', 'Legacy category', "
                    + "'Existing question?', 'A', 'B', 'C', 'D', 1, 'Easy', 'Existing explanation.')");
        }

        DatabaseConnection database = new DatabaseConnection(databaseFile);
        QuestionService questions = new QuestionService(database);
        Question migrated = questions.getAll().stream()
                .filter(question -> question.getId().equals("legacy-question"))
                .findFirst().orElseThrow();
        assert migrated instanceof MCQQuestion;
        assert migrated.getPrompt().equals("Existing question?");
        try (Connection connection = database.open();
             var statement = connection.createStatement();
             ResultSet row = statement.executeQuery(
                     "SELECT type FROM questions WHERE id = 'legacy-question'")) {
            assert row.next();
            assert row.getString(1).equals(Question.MCQ_TYPE);
            try (ResultSet versions = statement.executeQuery(
                    "SELECT COUNT(*) FROM schema_migrations WHERE version = 3")) {
                assert versions.next();
                assert versions.getInt(1) == 1;
            }
        }
    }

    private static void verifyQuestionFileMigration(Path directory) throws Exception {
        FileStorage storage = new FileStorage(directory.resolve("files"));
        storage.write("questions.dat", List.of(
                new String[]{"legacy-file-question", "File migration", "Old format question?",
                        "A", "B", "C", "D", "1"},
                new String[]{"true-false-file-question", "File migration", "Typed question?",
                        "True", "False", "", "", "0", "Easy", "Typed explanation.",
                        Question.TRUE_FALSE_TYPE}));
        DatabaseConnection database = new DatabaseConnection(directory.resolve("migrated.sqlite"));
        MigrationService migration = new MigrationService(database, storage);
        MigrationService.MigrationResult firstRun = migration.migrate();
        assert firstRun.sourceRecords().questions() == 2;
        assert firstRun.newlyInsertedRecords().questions() == 2;
        MigrationService.MigrationResult secondRun = migration.migrate();
        assert secondRun.newlyInsertedRecords().questions() == 0;

        QuestionService questions = new QuestionService(database);
        Question legacyQuestion = questions.getAll().stream()
                .filter(question -> question.getId().equals("legacy-file-question"))
                .findFirst().orElseThrow();
        Question typedQuestion = questions.getAll().stream()
                .filter(question -> question.getId().equals("true-false-file-question"))
                .findFirst().orElseThrow();
        assert legacyQuestion instanceof MCQQuestion;
        assert typedQuestion instanceof TrueFalseQuestion;
        assert typedQuestion.getType().equals(Question.TRUE_FALSE_TYPE);
    }

    private static void verifyDatabaseFailureDoesNotFallBack(Path directory) throws Exception {
        Path blocker = directory.resolve("not-a-directory");
        Files.writeString(blocker, "blocker");
        DatabaseConnection unavailable = new DatabaseConnection(blocker.resolve("database.sqlite"));
        try {
            new AuthService(unavailable);
            throw new AssertionError("Expected SQLite startup failure.");
        } catch (IOException expected) {
            assert expected.getMessage().contains("SQLite");
        }
        assert !Files.exists(directory.resolve("users.dat"));
    }

    private static void expectIllegalArgument(ThrowingAction action) throws Exception {
        try {
            action.run();
            throw new AssertionError("Expected IllegalArgumentException.");
        } catch (IllegalArgumentException expected) {
            // Expected validation failure.
        }
    }

    @FunctionalInterface
    private interface ThrowingAction {
        void run() throws Exception;
    }
}
