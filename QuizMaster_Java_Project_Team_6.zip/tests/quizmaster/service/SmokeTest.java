package quizmaster.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Comparator;
import java.awt.Graphics2D;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.plaf.basic.BasicComboBoxUI;
import quizmaster.exception.TimeUpException;
import quizmaster.model.Question;
import quizmaster.model.MCQQuestion;
import quizmaster.model.QuizSession;
import quizmaster.model.ScoreRecord;
import quizmaster.model.TrueFalseQuestion;
import quizmaster.model.User;
import quizmaster.controller.QuizController;
import quizmaster.service.QuizTimerThread;
import quizmaster.view.AboutPanel;
import quizmaster.view.AdminPanel;
import quizmaster.view.AnswerReviewPanel;
import quizmaster.view.DashboardPanel;
import quizmaster.view.ExamPanel;
import quizmaster.view.HistoryPanel;
import quizmaster.view.ProfilePanel;
import quizmaster.view.ResultPanel;
import quizmaster.view.SettingsPanel;
import quizmaster.util.Theme;

public final class SmokeTest {
    private SmokeTest() {
    }

    public static void main(String[] args) throws Exception {
        Path dataDirectory = Files.createTempDirectory("quizmaster-test-");
        try {
            runChecks(dataDirectory);
            runLegacyMigrationCheck(dataDirectory.resolve("legacy"));
            verifyQuestionPolymorphism();
            verifyQuizTimerThread();
            verifyDialogButtonStyling();
            System.out.println("QuizMaster smoke tests passed.");
        } finally {
            try (var paths = Files.walk(dataDirectory)) {
                paths.sorted(Comparator.reverseOrder()).forEach(path -> {
                    try {
                        Files.deleteIfExists(path);
                    } catch (IOException exception) {
                        throw new RuntimeException("Could not clean up smoke test data.", exception);
                    }

                });
            }
        }
    }

    private static void verifyDialogButtonStyling() {
        Theme.configureDefaults();
        assert Theme.DIALOG_BUTTON.equals(javax.swing.UIManager.getColor("OptionPane.buttonBackground"));
        assert Color.WHITE.equals(javax.swing.UIManager.getColor("OptionPane.buttonForeground"));
        assert Theme.DIALOG_BACKGROUND.equals(javax.swing.UIManager.getColor("OptionPane.background"));

        JPanel dialogButtons = new JPanel();
        for (String text : List.of("OK", "Yes", "No", "Cancel")) {
            dialogButtons.add(new JButton(text));
        }
        Theme.styleDialogButtons(dialogButtons);
        Color purple = new Color(0x75, 0x45, 0xD6);
        for (Component component : dialogButtons.getComponents()) {
            JButton button = (JButton) component;
            assert button.getBackground().equals(purple);
            assert button.getForeground().equals(Color.WHITE);
            assert button.getUI() instanceof BasicButtonUI;
            assert button.getFont().isBold();
            assert button.isOpaque();
            assert button.isContentAreaFilled();
            assert button.getMargin().left >= 12;

            button.getModel().setRollover(true);
            assert button.getBackground().equals(Theme.DIALOG_BUTTON_HOVER);
            button.getModel().setArmed(true);
            button.getModel().setPressed(true);
            assert button.getBackground().equals(Theme.DIALOG_BUTTON_PRESSED);
            button.getModel().setPressed(false);
            button.getModel().setArmed(false);
        }
    }

    private static void runChecks(Path dataDirectory) throws Exception {
        FileStorage storage = new FileStorage(dataDirectory);
        AuthService auth = new AuthService(storage);
        QuestionService questions = new QuestionService(storage);
        ScoreService scores = new ScoreService(storage);
        List<String> expectedCategories = List.of("General Knowledge", "Mathematics", "English", "Science",
                "Computer Basics", "History", "Geography", "Reasoning", "Current Affairs", "Basic Programming");
        for (String category : expectedCategories) {
            List<Question> categoryQuestions = questions.getByCategory(category);
            assert categoryQuestions.size() == 20 : category + " should have 20 questions.";
            assert categoryQuestions.stream().map(Question::getPrompt).distinct().count() == 20;
            for (Question question : categoryQuestions) {
                assert question.getOptions().size() == 4;
                assert question.getCorrectAnswer() >= 0 && question.getCorrectAnswer() < 4;
                assert List.of("Easy", "Medium", "Hard").contains(question.getDifficulty());
                assert !question.getExplanation().isBlank();
            }
        }
        assert questions.getByCategory("Java").size() >= 20;

        assert auth.login("admin", "admin123").getRole() == User.Role.ADMIN;
        User student = auth.register("student1", "secret1");
        assert auth.login("STUDENT1", "secret1").getUsername().equals("student1");
        expectIllegalArgument(() -> auth.register("student1", "secret1"));

        List<Question> javaQuestions = questions.getByCategory("Java");
        assert javaQuestions.size() >= 4;
        Question added = new MCQQuestion("Testing", "Which option is correct?",
                List.of("A", "B", "C", "D"), 2, "Easy", "Option C is the correct choice.");
        questions.add(added);
        added = new MCQQuestion(added.getId(), "Testing", "Updated question?",
                List.of("One", "Two", "Three", "Four"), 1);
        questions.update(added);
        assert questions.getByCategory("Testing").get(0).getPrompt().equals("Updated question?");
        questions.delete(added.getId());
        assert questions.getByCategory("Testing").isEmpty();

        QuizService quizService = new QuizService(questions, scores);
        assert quizService.start("Mathematics", true, 10).getQuestionCount() == 10;
        assert quizService.start("Mathematics", true, 20).getQuestionCount() == 20;
        expectIllegalArgument(() -> quizService.start("Mathematics", true, 15));
        QuizSession session = quizService.start("Java", true);
        for (int i = 0; i < session.getQuestionCount(); i++) {
            session.goTo(i);
            session.selectAnswer(session.getCurrentQuestion().getCorrectAnswer());
        }
        ScoreRecord result = quizService.submit(session, student);
        assert result.getScore() == result.getTotal();
        assert result.getAnswerReviews().size() == result.getTotal();
        assert result.getIncorrectCount() == 0;
        assert result.getUnansweredCount() == 0;
        assert scores.getForUser(student.getUsername()).size() == 1;
        ScoreRecord persistedResult = scores.getForUser(student.getUsername()).get(0);
        assert persistedResult.getAnswerReviews().size() == persistedResult.getTotal();
        assert persistedResult.getDurationSeconds() >= 0;
        QuizSession partial = quizService.start("Mathematics", true, 20);
        partial.selectAnswer((partial.getCurrentQuestion().getCorrectAnswer() + 1) % 4);
        ScoreRecord partialResult = quizService.submit(partial, student);
        assert partialResult.getCorrectCount() == 0;
        assert partialResult.getIncorrectCount() == 1;
        assert partialResult.getUnansweredCount() == 19;
        Path csv = dataDirectory.resolve("history.csv");
        scores.exportCsv(csv, student.getUsername());
        assert Files.readString(csv).contains("Username,Category");
        assert Files.readString(csv).contains(student.getUsername());

        QuizSession expired = new QuizSession(javaQuestions, false, 0);
        try {
            expired.selectAnswer(0);
            throw new AssertionError("Expected TimeUpException.");
        } catch (TimeUpException expected) {
            assert expected.getMessage().contains("Time is up");
        }
        verifyDropdownStyling(student, questions);
        verifySettingsAndCategories(storage, questions, student);
        verifyPlatformPanels(student, questions, auth, scores, new SettingsService(storage),
                persistedResult);
    }

    private static void verifySettingsAndCategories(FileStorage storage, QuestionService questions,
                                                   User student) throws Exception {
        SettingsService settings = new SettingsService(storage);
        assert settings.getDefaultQuestionCount(student.getUsername()) == 10;
        settings.set(student.getUsername(), "questionCount", "20");
        settings.set(student.getUsername(), "notifications", "false");
        assert settings.getDefaultQuestionCount(student.getUsername()) == 20;
        assert !settings.areNotificationsEnabled(student.getUsername());

        questions.addCategory("Test category");
        assert questions.getCategories().contains("Test category");
        expectIllegalArgument(() -> questions.addCategory("test category"));
        questions.renameCategory("Test category", "Renamed category");
        assert questions.getCategories().contains("Renamed category");
        questions.deleteCategory("Renamed category");
        assert !questions.getCategories().contains("Renamed category");
    }

    private static void verifyPlatformPanels(User student, QuestionService questions, AuthService auth,
                                             ScoreService scores, SettingsService settings,
                                             ScoreRecord result) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            new ProfilePanel(student, auth);
            SettingsPanel settingsPanel = new SettingsPanel(student, settings);
            verifySettingsStyling(settingsPanel);
            new AboutPanel();
            new AdminPanel(questions, auth, scores, () -> { });
            new AnswerReviewPanel(result, () -> { });
            new ResultPanel(result, () -> { }, () -> { }, () -> { });
            try {
                new ExamPanel(new QuizController(new QuizService(questions, scores), student,
                        "Mathematics", true, 10), ignored -> { });
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
            try {
                new HistoryPanel(student, scores, () -> { });
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        });
    }

    private static void verifySettingsStyling(SettingsPanel panel) {
        List<JComboBox<?>> combos = new java.util.ArrayList<>();
        List<JCheckBox> checkboxes = new java.util.ArrayList<>();
        List<JButton> buttons = new java.util.ArrayList<>();
        collectSettingsComponents(panel, combos, checkboxes, buttons);
        assert combos.size() == 1;
        assert checkboxes.size() == 1;
        assert buttons.size() == 1;

        verifySettingsCombo(combos.get(0));
        assert !checkboxes.get(0).isSelected();
        assert buttons.get(0).getPreferredSize().width < 200;
        assert buttons.get(0).getPreferredSize().height <= 44;
    }

    private static <T> void verifySettingsCombo(JComboBox<T> count) {
        Color purple = new Color(0x75, 0x45, 0xD6);
        Color navy = new Color(0x19, 0x1F, 0x38);
        assert !count.isEditable();
        assert Integer.valueOf(20).equals(count.getSelectedItem());
        assert count.getPreferredSize().width <= 140;
        assert count.getBackground().equals(purple);
        assert count.getForeground().equals(Color.WHITE);
        assert count.getUI() instanceof BasicComboBoxUI;
        java.awt.Component closedValue = count.getRenderer().getListCellRendererComponent(
                new JList<T>(), count.getItemAt(1), -1, false, false);
        assert closedValue.getBackground().equals(purple);
        assert closedValue.getForeground().equals(Color.WHITE);
        java.awt.Component popupValue = count.getRenderer().getListCellRendererComponent(
                new JList<T>(), count.getItemAt(0), 0, false, false);
        assert popupValue.getBackground().equals(navy);
        assert popupValue.getForeground().equals(Color.WHITE);
        java.awt.Component selectedPopupValue = count.getRenderer().getListCellRendererComponent(
                new JList<T>(), count.getItemAt(1), 1, true, false);
        assert selectedPopupValue.getBackground().equals(purple);
        assert selectedPopupValue.getForeground().equals(Color.WHITE);
    }

    private static void collectSettingsComponents(Component component, List<JComboBox<?>> combos,
                                                  List<JCheckBox> checkboxes, List<JButton> buttons) {
        if (component instanceof JComboBox<?> combo) {
            combos.add(combo);
        } else if (component instanceof JCheckBox checkbox) {
            checkboxes.add(checkbox);
        } else if (component instanceof JButton button && button.getText().equals("Save Settings")) {
            buttons.add(button);
        }
        if (component instanceof Container container) {
            for (Component child : container.getComponents()) {
                collectSettingsComponents(child, combos, checkboxes, buttons);
            }
        }
    }

    private static void runLegacyMigrationCheck(Path directory) throws Exception {
        FileStorage storage = new FileStorage(directory);
        storage.write("questions.dat", java.util.Collections.singletonList(new String[]{
                "existing-custom-id", "General Knowledge", "Which is the largest planet in our solar system?",
                "Earth", "Jupiter", "Saturn", "Neptune", "1"
        }));
        QuestionService questions = new QuestionService(storage);
        List<Question> generalKnowledge = questions.getByCategory("General Knowledge");
        assert generalKnowledge.size() == 20;
        Question preserved = generalKnowledge.stream()
                .filter(question -> question.getId().equals("existing-custom-id"))
                .findFirst().orElseThrow();
        assert preserved.getCorrectAnswer() == 1;
        assert !preserved.getExplanation().isBlank();
        assert storage.read("questions.dat", 11, 10, 8).size() == questions.getAll().size();

        String salt = "legacy-salt";
        String hash = java.util.Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256")
                .digest((salt + "legacy-pass").getBytes(StandardCharsets.UTF_8)));
        storage.write("users.dat", java.util.Collections.singletonList(new String[]{
                "legacy-user", salt, hash, "STUDENT"
        }));
        AuthService auth = new AuthService(storage);
        assert auth.login("legacy-user", "legacy-pass").getDisplayName().equals("legacy-user");
        User updated = auth.register("new-user", "New Student", "new-pass");
        assert updated.getDisplayName().equals("New Student");
        expectIllegalArgument(() -> auth.changePassword(updated.getUsername(), "incorrect", "new-secret"));
        assert auth.login("new-user", "new-pass").getUsername().equals("new-user");
        auth.changePassword(updated.getUsername(), "new-pass", "new-secret");
        assert auth.login("new-user", "new-secret").getUsername().equals("new-user");
        assert auth.getStudents().size() == 2;

        storage.write("scores.dat", java.util.Collections.singletonList(new String[]{
                "legacy-score", "legacy-user", "General Knowledge", "7", "10",
                "false", java.time.LocalDateTime.now().toString()
        }));
        ScoreService scores = new ScoreService(storage);
        List<ScoreRecord> records = scores.getForUser("legacy-user");
        assert records.size() == 1;
        assert records.get(0).getScore() == 7;
        assert records.get(0).getAnswerReviews().isEmpty();
    }

    private static void verifyQuestionPolymorphism() throws Exception {
        MCQQuestion mcq = new MCQQuestion("Testing", "Choose the correct option.",
                List.of("A", "B", "C", "D"), 2, "Easy", "C is correct.");
        TrueFalseQuestion trueFalse = new TrueFalseQuestion("Testing", "The Earth orbits the Sun.",
                0, "Easy", "The Earth orbits the Sun.");
        assert mcq instanceof Question;
        assert trueFalse instanceof Question;
        assert Question.MCQ_TYPE.equals(mcq.getType());
        assert Question.TRUE_FALSE_TYPE.equals(trueFalse.getType());
        assert mcq.getOptionCount() == 4;
        assert trueFalse.getOptionCount() == 2;
        assert mcq.isCorrectAnswer(2);
        assert !mcq.isCorrectAnswer(4);
        assert trueFalse.isCorrectAnswer(0);
        assert !trueFalse.isCorrectAnswer(2);

        QuizSession session = new QuizSession(List.of(mcq, trueFalse), true, 0);
        session.selectAnswer(2);
        session.goTo(1);
        session.selectAnswer(0);
        assert session.countCorrectAnswers() == 2;
        assert mcq.withCategory("Renamed") instanceof MCQQuestion;
        assert trueFalse.withCategory("Renamed") instanceof TrueFalseQuestion;
    }

    private static void verifyQuizTimerThread() throws Exception {
        Question question = new MCQQuestion("Timer", "Timer expiry test.",
                List.of("A", "B", "C", "D"), 0);
        QuizSession active = new QuizSession(List.of(question), false, 10);
        CountDownLatch tick = new CountDownLatch(1);
        AtomicInteger tickCount = new AtomicInteger();
        AtomicInteger tickOnEdt = new AtomicInteger();
        QuizTimerThread runningTimer = new QuizTimerThread(active, remaining -> {
            tickCount.incrementAndGet();
            if (SwingUtilities.isEventDispatchThread()) {
                tickOnEdt.incrementAndGet();
            }
            tick.countDown();
        }, () -> { });
        assert runningTimer.startOnce();
        assert !runningTimer.startOnce();
        assert tick.await(5, TimeUnit.SECONDS);
        runningTimer.cancelTimer();
        runningTimer.join(2000);
        assert !runningTimer.isAlive();
        assert tickCount.get() == 1;
        assert tickOnEdt.get() == 1;

        QuizSession expired = new QuizSession(List.of(question), false, 0);
        CountDownLatch timeout = new CountDownLatch(1);
        AtomicInteger timeoutCount = new AtomicInteger();
        AtomicInteger callbacksOnEdt = new AtomicInteger();
        QuizTimerThread timer = new QuizTimerThread(expired, remaining -> {
            throw new AssertionError("An expired timer must not emit a countdown tick.");
        }, () -> {
            timeoutCount.incrementAndGet();
            if (SwingUtilities.isEventDispatchThread()) {
                callbacksOnEdt.incrementAndGet();
            }
            timeout.countDown();
        });
        assert timer.startOnce();
        assert !timer.startOnce();
        assert timeout.await(5, TimeUnit.SECONDS);
        assert timeoutCount.get() == 1;
        assert callbacksOnEdt.get() == 1;
    }

    private static void verifyDropdownStyling(User user, QuestionService service) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            DashboardPanel dashboard = new DashboardPanel(user, service,
                    (category, practice, count) -> { }, () -> { }, () -> { }, () -> { });
            List<JComboBox<?>> combos = new java.util.ArrayList<>();
            collectComboBoxes(dashboard, combos);
            assert combos.size() == 2;
            boolean hasQuestionCountChoices = false;
            for (JComboBox<?> combo : combos) {
                verifyComboColors(combo);
                if (combo.getItemCount() == 2
                        && Integer.valueOf(10).equals(combo.getItemAt(0))
                        && Integer.valueOf(20).equals(combo.getItemAt(1))) {
                    hasQuestionCountChoices = true;
                }
            }
            assert hasQuestionCountChoices;
        });
    }

    private static <T> void verifyComboColors(JComboBox<T> combo) {
        Color purple = new Color(0x75, 0x45, 0xD6);
        Color navy = new Color(0x19, 0x1F, 0x38);
        assert !combo.isEditable();
        assert combo.getBackground().equals(purple);
        assert combo.getForeground().equals(Color.WHITE);
        assert combo.getFont().isBold();
        assert combo.isOpaque();
        assert combo.getUI() instanceof BasicComboBoxUI;
        Component closedValue = combo.getRenderer().getListCellRendererComponent(
                new JList<T>(), combo.getItemAt(0), -1, false, false);
        assert closedValue.getBackground().equals(purple);
        assert closedValue.getForeground().equals(Color.WHITE);
        assert closedValue.getFont().isBold();
        Component selectedItem = combo.getRenderer().getListCellRendererComponent(
                new JList<T>(), combo.getItemAt(0), 0, true, false);
        assert selectedItem.getBackground().equals(purple);
        assert selectedItem.getForeground().equals(Color.WHITE);
        Component unselectedItem = combo.getRenderer().getListCellRendererComponent(
                new JList<T>(), combo.getItemAt(0), 0, false, false);
        assert unselectedItem.getBackground().equals(navy);
        assert unselectedItem.getForeground().equals(Color.WHITE);
        boolean foundArrow = false;
        for (Component child : combo.getComponents()) {
            if (child instanceof JButton arrow) {
                foundArrow = true;
                assert arrow.getBackground().equals(purple);
                assert arrow.getForeground().equals(Color.WHITE);
                assert arrow.isOpaque();
            }
        }
        assert foundArrow;

        combo.setSize(280, 42);
        combo.doLayout();
        BufferedImage rendered = new BufferedImage(280, 42, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = rendered.createGraphics();
        combo.paint(graphics);
        graphics.dispose();
        assert new Color(rendered.getRGB(8, 21), true).equals(purple)
                : "Closed selected-value area was not painted purple.";
        combo.setSelectedIndex(combo.getItemCount() - 1);
        rendered = new BufferedImage(280, 42, BufferedImage.TYPE_INT_ARGB);
        graphics = rendered.createGraphics();
        combo.paint(graphics);
        graphics.dispose();
        assert new Color(rendered.getRGB(8, 21), true).equals(purple)
                : "Closed selected-value area lost its purple background after selection.";
    }

    private static void collectComboBoxes(Component component, List<JComboBox<?>> combos) {
        if (component instanceof JComboBox<?> combo) {
            combos.add(combo);
        }
        if (component instanceof Container container) {
            for (Component child : container.getComponents()) {
                collectComboBoxes(child, combos);
            }
        }
    }

    private static void expectIllegalArgument(CheckedAction action) throws Exception {
        try {
            action.run();
            throw new AssertionError("Expected IllegalArgumentException.");
        } catch (IllegalArgumentException expected) {
            // Expected validation result.
        }
    }

    @FunctionalInterface
    private interface CheckedAction {
        void run() throws Exception;
    }
}
