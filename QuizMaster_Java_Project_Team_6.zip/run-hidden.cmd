@echo off
setlocal
cd /d "%~dp0"
if not exist logs mkdir logs
if not exist out mkdir out

javac -encoding UTF-8 -cp "lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar" -d out -sourcepath src src\quizmaster\QuizMasterApp.java src\quizmaster\service\DatabaseConnection.java > "logs\quizmaster-launch.log" 2>&1
if errorlevel 1 exit /b 1

javaw --enable-native-access=ALL-UNNAMED -cp "out;lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar;lib\slf4j-nop-1.7.36.jar" quizmaster.QuizMasterApp >> "logs\quizmaster-launch.log" 2>&1
if errorlevel 1 exit /b 1

endlocal
