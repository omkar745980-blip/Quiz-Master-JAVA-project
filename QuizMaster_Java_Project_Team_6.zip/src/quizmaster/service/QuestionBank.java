package quizmaster.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import quizmaster.model.MCQQuestion;
import quizmaster.model.Question;

final class QuestionBank {
    static final List<String> CATEGORIES = List.of(
            "General Knowledge", "Mathematics", "English", "Science", "Computer Basics",
            "History", "Geography", "Reasoning", "Current Affairs", "Basic Programming", "Java");

    private QuestionBank() {
    }

    static List<Question> createQuestions() {
        List<Question> questions = new ArrayList<>();
        add(questions, "General Knowledge", """
                Which is the largest planet in our solar system?~Earth~Jupiter~Saturn~Neptune~1~Easy~Jupiter is the largest planet by both mass and diameter.
                How many sides does a hexagon have?~Five~Six~Seven~Eight~1~Easy~A hexagon is a polygon with six sides.
                What is the capital city of Japan?~Seoul~Beijing~Tokyo~Bangkok~2~Easy~Tokyo is Japan's capital and largest metropolitan area.
                Which ocean is the largest?~Atlantic Ocean~Indian Ocean~Arctic Ocean~Pacific Ocean~3~Easy~The Pacific Ocean is the largest and deepest ocean.
                How many colors are traditionally named in a rainbow?~Five~Six~Seven~Eight~2~Easy~The traditional list divides a rainbow into seven visible color bands.
                What is the currency of the United Kingdom?~Euro~Pound sterling~Dollar~Franc~1~Easy~The pound sterling is the United Kingdom's currency.
                Which animal is the largest living mammal?~African elephant~Blue whale~Giraffe~Hippopotamus~1~Easy~The blue whale is the largest animal known to have lived.
                Which language is primarily spoken in Brazil?~Spanish~Portuguese~French~Italian~1~Easy~Brazil's official language is Portuguese.
                How many days are in a leap year?~364~365~366~367~2~Easy~A leap year has one extra day in February, making 366 days.
                Which instrument measures temperature?~Barometer~Thermometer~Hygrometer~Compass~1~Easy~A thermometer measures temperature.
                What is the largest land animal?~Rhinoceros~Giraffe~African elephant~Polar bear~2~Easy~The African elephant is the largest living land animal.
                Which planet is known as the Red Planet?~Venus~Mars~Mercury~Saturn~1~Easy~Iron-rich dust gives Mars its reddish appearance.
                How many players from one team are on a soccer field during regular play?~Nine~Ten~Eleven~Twelve~2~Easy~A soccer team fields eleven players, including the goalkeeper.
                Which bird is commonly associated with delivering babies in folklore?~Swan~Stork~Eagle~Heron~1~Easy~European folklore traditionally associates the stork with babies.
                What is the main ingredient in traditional guacamole?~Cucumber~Avocado~Pea~Zucchini~1~Easy~Mashed avocado forms the base of guacamole.
                Which metal is liquid at typical room temperature?~Iron~Aluminium~Mercury~Copper~2~Medium~Mercury is a metal that remains liquid at ordinary room temperature.
                How many months have 31 days?~Five~Six~Seven~Eight~2~Easy~January, March, May, July, August, October, and December have 31 days.
                Which country is famous for the ancient pyramids at Giza?~Mexico~Egypt~Greece~India~1~Easy~The Giza pyramid complex is in Egypt.
                What is the name for a shape with eight sides?~Hexagon~Heptagon~Octagon~Nonagon~2~Easy~An octagon has eight sides.
                Which sport uses a racket and a shuttlecock?~Squash~Badminton~Table tennis~Lacrosse~1~Easy~Badminton is played with rackets and a shuttlecock.
                """);
        add(questions, "Mathematics", """
                What is 7 + 8?~13~14~15~16~2~Easy~Adding seven and eight gives fifteen.
                What is 9 x 6?~42~48~54~56~2~Easy~Nine multiplied by six equals fifty-four.
                What is 144 divided by 12?~10~11~12~13~2~Easy~Twelve times twelve is 144.
                What is the perimeter of a square with side length 5 cm?~10 cm~15 cm~20 cm~25 cm~2~Easy~A square has four equal sides, so its perimeter is 4 x 5 = 20 cm.
                What is 25 percent of 80?~15~20~25~30~1~Easy~One quarter of 80 is 20.
                Which fraction is equivalent to 1/2?~2/3~3/6~4/6~5/8~1~Easy~Three divided by six simplifies to one half.
                What is the area of a rectangle 7 cm long and 3 cm wide?~10 cm2~20 cm2~21 cm2~24 cm2~2~Easy~Rectangle area is length times width: 7 x 3 = 21 cm2.
                Solve: x + 9 = 14. What is x?~3~4~5~6~2~Easy~Subtracting nine from both sides gives x = 5.
                What is the next prime number after 7?~8~9~10~11~3~Medium~Eleven has no positive divisors other than one and itself.
                How many degrees are in a right angle?~45~90~120~180~1~Easy~A right angle measures 90 degrees.
                What is 3 squared?~6~8~9~12~2~Easy~Three squared means 3 multiplied by 3, which is 9.
                What is the mean of 2, 4, and 9?~4~5~6~15~1~Medium~The sum is 15, and 15 divided by 3 is 5.
                Convert 0.75 to a fraction in simplest form.~1/4~1/2~3/4~4/5~2~Medium~0.75 is 75/100, which reduces to 3/4.
                What is 1000 minus 375?~525~575~625~675~2~Easy~Subtracting 375 from 1000 gives 625.
                If a triangle has angles 60 and 70 degrees, what is the third angle?~40~50~60~70~1~Medium~Triangle angles total 180 degrees, so the third angle is 50.
                What is the value of 2 x (5 + 3)?~13~16~18~21~1~Easy~Evaluate the parentheses first: 2 x 8 = 16.
                What is the least common multiple of 4 and 6?~8~10~12~24~2~Medium~Twelve is the smallest positive number divisible by both four and six.
                A book costs $12 and is discounted by $3. What is its sale price?~$8~$9~$10~$15~1~Easy~Subtract the $3 discount from $12 to get $9.
                What is the value of 5 cubed?~25~75~100~125~3~Medium~Five cubed is 5 x 5 x 5 = 125.
                Which number is irrational?~0.5~3/4~Square root of 2~-3~2~Hard~The square root of 2 cannot be expressed as a ratio of integers.
                """);
        add(questions, "English", """
                Which word is a noun?~Quickly~Happiness~Blue~Run~1~Easy~Happiness names a feeling and is an abstract noun.
                Choose the correct plural of child.~Childs~Childes~Children~Childrens~2~Easy~Children is the irregular plural form of child.
                Which sentence is correctly punctuated?~Where are you.~Where are you?~Where are you!~Where, are you~1~Easy~A direct question ends with a question mark.
                What is the past tense of go?~Goed~Gone~Went~Going~2~Easy~Went is the simple past tense of go.
                Which word is an adjective in "The bright sun rose"?~The~Bright~Sun~Rose~1~Easy~Bright describes the noun sun, so it is an adjective.
                Choose a synonym for begin.~Finish~Start~Forget~Pause~1~Easy~Start means the same as begin.
                Choose an antonym for ancient.~Old~Historic~Modern~Early~2~Easy~Modern is the opposite of ancient.
                Which word is spelled correctly?~Necessary~Neccessary~Necesary~Necessery~0~Easy~Necessary is spelled with one c and two s letters.
                Which is a complete sentence?~Because it was raining.~The small red kite.~Birds fly south in winter.~After the long walk.~2~Easy~The third option has a subject and a complete predicate.
                What is the plural of mouse when referring to the animal?~Mouses~Mouse~Mice~Meese~2~Easy~Mice is the irregular plural of the animal mouse.
                Which pronoun can replace "Maria and I"?~We~They~She~Us~0~Easy~Maria and I refers to the first-person plural pronoun we.
                In "He ran quickly," what part of speech is quickly?~Noun~Verb~Adjective~Adverb~3~Easy~Quickly describes how he ran, so it is an adverb.
                Choose the correct word: "___ going to the library."~Their~There~They're~Theirs~2~Medium~They're is the contraction of they are.
                Which sentence uses its correctly?~The dog wagged it's tail.~The dog wagged its tail.~Its a sunny day.~The dog wagged its' tail.~1~Medium~Its is the possessive form; it's means it is.
                What is the comparative form of good?~Gooder~More good~Best~Better~3~Easy~Better is the comparative form of good.
                Which word is a conjunction?~Although~Green~Silently~Table~0~Medium~Although joins clauses and introduces a contrast.
                What does the prefix "un-" usually mean?~Again~Not~Before~Under~1~Easy~The prefix un- often makes a word mean not or the opposite.
                Which is the correct possessive form for one teacher?~Teachers desk~Teacher's desk~Teachers' desk~Teacher desk's~1~Medium~An apostrophe and s mark possession by one teacher.
                What is the subject in "The little puppy chased the ball"?~Little~Puppy~Chased~Ball~1~Easy~The puppy is the subject performing the action.
                Choose the correct article: "She ate ___ apple."~a~an~thee~no article~1~Easy~An is used before the vowel sound at the start of apple.
                """);
        add(questions, "Science", """
                What is the chemical symbol for water?~CO2~O2~H2O~NaCl~2~Easy~A water molecule contains two hydrogen atoms and one oxygen atom.
                Which part of a plant typically absorbs water?~Flower~Leaves~Stem~Roots~3~Easy~Roots take up water and minerals from the soil.
                Which planet is closest to the Sun?~Venus~Mercury~Earth~Mars~1~Easy~Mercury is the innermost planet in the solar system.
                What gas do humans need to breathe for cellular respiration?~Nitrogen~Oxygen~Helium~Carbon dioxide~1~Easy~Cells use oxygen to release energy from food.
                What force pulls objects toward Earth?~Friction~Magnetism~Gravity~Tension~2~Easy~Earth's gravity attracts objects toward its center.
                Which state of matter has a fixed volume but no fixed shape?~Solid~Liquid~Gas~Plasma~1~Easy~A liquid keeps its volume but takes the shape of its container.
                What is the center of an atom called?~Electron cloud~Nucleus~Molecule~Cell~1~Easy~The nucleus contains protons and neutrons.
                Which organ pumps blood around the human body?~Lungs~Brain~Heart~Liver~2~Easy~The heart circulates blood through the body's vessels.
                What do plants take in from the air during photosynthesis?~Oxygen~Carbon dioxide~Hydrogen~Nitrogen~1~Easy~Plants use carbon dioxide and water to make sugars in photosynthesis.
                At what temperature does pure water freeze at standard pressure?~0 C~10 C~32 C~100 C~0~Easy~Pure water freezes at 0 degrees Celsius at standard pressure.
                Which is a renewable energy source?~Coal~Natural gas~Solar power~Diesel~2~Easy~Sunlight is naturally replenished and can generate solar energy.
                Which simple machine is a ramp?~Lever~Pulley~Inclined plane~Wheel and axle~2~Easy~A ramp is an inclined plane that reduces the force needed to raise an object.
                Which blood cells help defend the body against infection?~Red blood cells~White blood cells~Platelets~Plasma cells only~1~Medium~White blood cells are key components of the immune system.
                What is the chemical symbol for oxygen?~Ox~O~Og~O2~1~Easy~O is the chemical symbol for the element oxygen.
                Which layer of Earth is the outermost solid layer?~Inner core~Outer core~Mantle~Crust~3~Easy~The crust is Earth's thin, outermost solid layer.
                Sound travels fastest through which state of matter?~Vacuum~Gas~Liquid~Solid~3~Medium~Particles are closely packed in solids, allowing sound vibrations to travel quickly.
                What is the main function of red blood cells?~Fight infection~Carry oxygen~Digest food~Produce hormones~1~Medium~Hemoglobin in red blood cells binds and transports oxygen.
                Which process changes liquid water into water vapor?~Condensation~Freezing~Evaporation~Melting~2~Easy~Evaporation changes a liquid into a gas at its surface.
                What is the smallest unit of life?~Atom~Tissue~Cell~Organ~2~Easy~A cell is the smallest structure that can perform the basic functions of life.
                Which vitamin can the skin produce with sunlight exposure?~Vitamin A~Vitamin B12~Vitamin C~Vitamin D~3~Medium~Sunlight helps the skin synthesize vitamin D.
                """);
        add(questions, "Computer Basics", """
                What does CPU stand for?~Central Processing Unit~Computer Personal Utility~Core Program User~Central Print Unit~0~Easy~CPU stands for Central Processing Unit, the main processor of a computer.
                Which device is primarily used to move a pointer on a desktop screen?~Scanner~Mouse~Speaker~Printer~1~Easy~A mouse moves and controls the on-screen pointer.
                Which of these is an operating system?~Windows~HTML~USB~Wi-Fi~0~Easy~Windows is an operating system that manages computer hardware and software.
                What does RAM primarily provide?~Long-term file storage~Temporary working memory~Printed output~Internet access~1~Easy~RAM temporarily stores data and instructions currently in use.
                Which device produces a paper copy of a document?~Monitor~Router~Printer~Microphone~2~Easy~A printer produces a physical paper output.
                What is a keyboard mainly used for?~Entering text and commands~Displaying images~Storing backups~Connecting to Wi-Fi~0~Easy~A keyboard lets users enter text and command input.
                Which file extension commonly identifies a plain text file?~.txt~.jpg~.mp3~.exe~0~Easy~The .txt extension is commonly used for plain text documents.
                What does USB commonly allow you to do?~Connect peripherals and transfer data~Cool a processor~Increase screen brightness~Create a password~0~Easy~USB is a standard interface for connecting devices and transferring data.
                Which is an example of a web browser?~Firefox~Excel~Paint~Notepad~0~Easy~Firefox is software used to access and browse websites.
                What does a computer monitor do?~Displays visual output~Records sound~Scans paper~Stores electricity~0~Easy~A monitor presents visual information from a computer.
                Which component is commonly used for long-term file storage?~RAM~SSD~CPU cache~Register~1~Easy~An SSD stores files even when the computer is turned off.
                What is the main purpose of a computer network?~Connect devices to share data and resources~Increase keyboard size~Replace all software~Convert text to sound~0~Easy~Networks connect computers so they can exchange information and share resources.
                What does a strong password usually include?~Only a first name~A mix of characters and sufficient length~A common dictionary word~The word password~1~Easy~Long, unique passwords with varied characters are harder to guess.
                Which key commonly deletes the character to the left of the cursor?~Shift~Backspace~Escape~Tab~1~Easy~Backspace removes the character immediately before the cursor.
                What is a folder used for?~Organizing files~Charging a laptop~Increasing internet speed~Editing a processor~0~Easy~Folders group files to make them easier to organize.
                What does Wi-Fi provide?~Wireless network connectivity~Extra disk space~A type of printer ink~A computer language~0~Easy~Wi-Fi connects devices to a network wirelessly.
                Which device converts a paper image into a digital file?~Scanner~Speaker~Projector~Joystick~0~Easy~A scanner captures a paper document as digital data.
                What should you do with an unexpected email attachment from an unknown sender?~Open it immediately~Forward it to everyone~Avoid opening it and verify the sender~Disable the screen~2~Medium~Unknown attachments may be malicious, so verify them before opening.
                Which unit is commonly used to measure file size?~Kilobyte~Volt~Hertz~Watt~0~Easy~A kilobyte is a unit used to describe digital data size.
                What does the Recycle Bin usually hold?~Temporarily deleted files~Newly installed programs~Internet passwords~Printer settings~0~Easy~Deleted files are often kept in the Recycle Bin until permanently removed.
                """);
        add(questions, "History", """
                Which ancient civilization built the pyramids at Giza?~Romans~Ancient Egyptians~Persians~Vikings~1~Easy~The ancient Egyptians built the Giza pyramids as royal tombs.
                In which year did World War II end?~1943~1944~1945~1946~2~Easy~World War II ended in 1945.
                Who was the first person to walk on the Moon?~Yuri Gagarin~Neil Armstrong~Buzz Aldrin~John Glenn~1~Easy~Neil Armstrong stepped onto the Moon during Apollo 11 in 1969.
                Which wall fell in 1989, becoming a symbol of German reunification?~Hadrian's Wall~Great Wall of China~Berlin Wall~Western Wall~2~Easy~The Berlin Wall opened in 1989 and was later dismantled.
                The ancient Olympic Games began in which country?~Italy~Greece~Egypt~Turkey~1~Easy~The ancient Olympic Games originated at Olympia in Greece.
                Which ship carried the Pilgrims to North America in 1620?~Santa Maria~Mayflower~Endeavour~Beagle~1~Easy~The Mayflower carried English Pilgrims to Plymouth in 1620.
                Who was the first president of the United States?~Thomas Jefferson~Abraham Lincoln~George Washington~John Adams~2~Easy~George Washington served as the first U.S. president.
                Which empire was ruled from Rome?~Mongol Empire~Roman Empire~Mali Empire~Inca Empire~1~Easy~Rome was the capital and governing center of the Roman Empire.
                In which year did the French Revolution begin?~1776~1789~1812~1848~1~Medium~The French Revolution began in 1789.
                Which civilization developed a writing system called cuneiform?~Sumerians~Aztecs~Incas~Phoenicians~0~Medium~Sumerians in Mesopotamia developed early cuneiform writing.
                Who is traditionally credited with inventing the movable-type printing press in Europe?~Galileo Galilei~Johannes Gutenberg~Isaac Newton~Leonardo da Vinci~1~Medium~Johannes Gutenberg developed a movable-type printing system in Europe.
                The Renaissance began in which European country?~France~Italy~England~Norway~1~Easy~The Renaissance began in Italian city-states before spreading across Europe.
                Which ancient trade route connected China with regions westward?~Silk Road~Spice Canal~Amber Highway~Royal Road only~0~Easy~The Silk Road was a network of routes linking China and western regions.
                Who was the Egyptian queen associated with Julius Caesar and Mark Antony?~Nefertiti~Hatshepsut~Cleopatra VII~Arsinoe II~2~Medium~Cleopatra VII ruled Egypt and was allied with both Roman leaders.
                Which document signed in 1215 limited the power of the English king?~Bill of Rights~Magna Carta~Declaration of Independence~Treaty of Versailles~1~Medium~Magna Carta placed limits on King John's authority.
                What was the name of the first artificial satellite launched into orbit?~Explorer 1~Sputnik 1~Vostok 1~Luna 2~1~Medium~The Soviet Union launched Sputnik 1 in 1957.
                Which civilization built Machu Picchu?~Maya~Aztec~Inca~Olmec~2~Easy~Machu Picchu was built by the Inca in the Andes.
                Which war was fought between the northern and southern states of the United States from 1861 to 1865?~War of 1812~American Civil War~Revolutionary War~Spanish-American War~1~Easy~The American Civil War lasted from 1861 to 1865.
                Who was the first woman to win a Nobel Prize?~Ada Lovelace~Marie Curie~Rosa Parks~Jane Addams~1~Medium~Marie Curie received the Nobel Prize in Physics in 1903.
                Which ancient Greek city-state is often associated with the origins of democracy?~Sparta~Athens~Corinth~Thebes~1~Easy~Athens developed an early form of citizen democracy.
                """);
        add(questions, "Geography", """
                What is the capital of France?~Madrid~Paris~Rome~Lisbon~1~Easy~Paris is the capital city of France.
                Which is the longest river in South America?~Amazon River~Orinoco River~Parana River~Sao Francisco River~0~Easy~The Amazon is South America's largest river system and longest river.
                On which continent is the Sahara Desert?~Asia~Africa~Australia~South America~1~Easy~The Sahara Desert is in northern Africa.
                What is the capital of Canada?~Toronto~Vancouver~Ottawa~Montreal~2~Easy~Ottawa is Canada's capital city.
                Mount Everest is part of which mountain range?~Andes~Alps~Himalayas~Rockies~2~Easy~Mount Everest is in the Himalayas on the Nepal-China border.
                Which country has the largest land area?~Canada~China~Russia~United States~2~Easy~Russia is the world's largest country by land area.
                Which imaginary line divides Earth into Northern and Southern Hemispheres?~Prime Meridian~Equator~Tropic of Cancer~Arctic Circle~1~Easy~The Equator divides Earth into Northern and Southern Hemispheres.
                What is the capital of Australia?~Sydney~Melbourne~Canberra~Perth~2~Easy~Canberra is Australia's capital city.
                Which sea lies between Europe and Africa?~Caribbean Sea~Mediterranean Sea~Bering Sea~Coral Sea~1~Easy~The Mediterranean Sea separates southern Europe from northern Africa.
                Which is the smallest continent by land area?~Europe~Antarctica~Australia~South America~2~Easy~Australia is the smallest continent by land area.
                What is the capital of Kenya?~Lagos~Nairobi~Kampala~Addis Ababa~1~Easy~Nairobi is the capital and largest city of Kenya.
                Which U.S. state is made up of islands in the Pacific Ocean?~Alaska~Hawaii~Florida~Maine~1~Easy~Hawaii is an island state in the central Pacific.
                The Andes Mountains are primarily located on which continent?~Africa~Europe~South America~Asia~2~Easy~The Andes run along the western side of South America.
                Which country is shaped like a long boot on many maps?~Greece~Italy~Portugal~Croatia~1~Easy~The Italian Peninsula is commonly described as boot-shaped.
                What is the capital of Egypt?~Cairo~Alexandria~Giza~Luxor~0~Easy~Cairo is Egypt's capital and largest city.
                Which direction is opposite east on a compass?~North~South~West~Northeast~2~Easy~West is directly opposite east.
                Which river flows through London?~Severn~Thames~Clyde~Trent~1~Easy~The River Thames flows through London.
                What is the world's largest hot desert?~Gobi Desert~Sahara Desert~Kalahari Desert~Arabian Desert~1~Easy~The Sahara is the largest hot desert on Earth.
                Which ocean borders the east coast of the United States?~Pacific Ocean~Atlantic Ocean~Indian Ocean~Arctic Ocean~1~Easy~The Atlantic Ocean lies off the eastern coast of the United States.
                Which country contains the city of Barcelona?~Portugal~Spain~France~Italy~1~Easy~Barcelona is a major city in northeastern Spain.
                """);
        add(questions, "Reasoning", """
                What number comes next: 2, 4, 6, 8, __?~9~10~11~12~1~Easy~The sequence increases by two each time.
                Which item does not belong: apple, pear, carrot, peach?~Apple~Pear~Carrot~Peach~2~Easy~Carrot is a vegetable, while the others are fruits.
                If all Bloops are Razzies and all Razzies are Lazzies, are all Bloops Lazzies?~Yes~No~Only some~Cannot be determined~0~Medium~The two statements make Bloops a subset of Razzies and Lazzies.
                What letter comes next: A, C, E, G, __?~H~I~J~K~1~Easy~The sequence skips one letter each time: A, C, E, G, I.
                If today is Monday, what day will it be in three days?~Tuesday~Wednesday~Thursday~Friday~2~Easy~Three days after Monday is Thursday.
                Find the missing number: 5, 10, 20, 40, __?~45~60~80~100~2~Easy~Each number is multiplied by two.
                Which word can be made from the letters in LISTEN?~Silent~Little~Stone~Lines~0~Medium~Silent uses exactly the letters in LISTEN.
                A is taller than B, and B is taller than C. Who is the shortest?~A~B~C~Cannot tell~2~Easy~Since A is taller than B and B taller than C, C is shortest.
                If 3 pens cost $6, what do 5 pens cost at the same rate?~$8~$9~$10~$12~2~Easy~Each pen costs $2, so five cost $10.
                Which number is different: 4, 9, 16, 20, 25?~4~9~20~25~2~Medium~All the others are perfect squares; 20 is not.
                What comes next: Z, X, V, T, __?~R~S~Q~P~0~Medium~The sequence moves backward by two letters each time.
                If every square is a rectangle, which statement must be true?~Every rectangle is a square~Some squares are not rectangles~Every square is a rectangle~No rectangle has four sides~2~Easy~This is exactly the given relationship.
                How many times does the digit 1 appear when counting from 1 to 12?~3~4~5~6~2~Medium~The digit appears in 1, 10, 11 twice, and 12: five times.
                If you face north and turn right, which direction are you facing?~West~East~South~Northwest~1~Easy~A right turn from north points east.
                Find the next number: 1, 4, 9, 16, __?~20~24~25~36~2~Medium~These are consecutive square numbers: 1 squared through 5 squared.
                Which pair has the same relationship as bird:nest?~Bee:hive~Fish:sky~Dog:feather~Tree:river~0~Easy~A nest is a bird's home, just as a hive is a bee's home.
                Sam is older than Lee but younger than Pat. Who is oldest?~Sam~Lee~Pat~Cannot tell~2~Easy~Pat is older than Sam, who is older than Lee.
                A clock shows 3:00. What is the smaller angle between its hands?~45 degrees~60 degrees~90 degrees~180 degrees~2~Medium~At 3:00 the hands point to 3 and 12, forming a right angle.
                If 12 is divided equally among 3 people, how many does each receive?~3~4~6~9~1~Easy~Twelve divided by three equals four.
                Which shape has no corners?~Triangle~Rectangle~Circle~Pentagon~2~Easy~A circle has a continuous curved edge and no corners.
                """);
        add(questions, "Current Affairs", """
                Which city hosted the 2024 Summer Olympic Games?~Tokyo~Paris~Los Angeles~Rome~1~Easy~Paris hosted the 2024 Summer Olympics.
                Which Indian mission made a soft landing near the Moon's south polar region in 2023?~Chandrayaan-1~Chandrayaan-2~Chandrayaan-3~Mangalyaan~2~Easy~Chandrayaan-3 landed on the Moon in August 2023.
                Which country hosted the 2023 United Nations Climate Change Conference, COP28?~Egypt~United Arab Emirates~Brazil~Japan~1~Medium~COP28 was held in Dubai in the United Arab Emirates.
                Which country won the 2022 FIFA World Cup?~France~Argentina~Brazil~Croatia~1~Easy~Argentina won the 2022 FIFA World Cup final.
                What was the name of NASA's mission that returned asteroid samples to Earth in 2023?~OSIRIS-REx~Juno~New Horizons~Parker Solar Probe~0~Medium~OSIRIS-REx delivered samples from asteroid Bennu in September 2023.
                Which country became the first to land a spacecraft near the Moon's south pole in 2023?~India~Japan~United States~China~0~Medium~India achieved the first successful landing near the lunar south pole with Chandrayaan-3.
                The 2024 total solar eclipse crossed parts of which continent?~Europe~North America~Africa~Australia~1~Easy~The April 2024 total eclipse crossed Mexico, the United States, and Canada.
                Which city hosted the 2024 United Nations climate conference COP29?~Baku~Nairobi~Madrid~Seoul~0~Medium~COP29 took place in Baku, Azerbaijan.
                Which organization publishes the annual World Happiness Report with partner institutions?~World Health Organization~United Nations Sustainable Development Solutions Network~World Trade Organization~International Olympic Committee~1~Medium~The UN Sustainable Development Solutions Network is associated with the report.
                Which country hosted the 2023 Cricket World Cup?~Australia~India~England~South Africa~1~Easy~India hosted the 2023 Men's Cricket World Cup.
                Which city hosted the 2022 Commonwealth Games?~Birmingham~Glasgow~Melbourne~Delhi~0~Easy~The 2022 Commonwealth Games were held in Birmingham, England.
                Which country joined the European Union in 2013?~Serbia~Croatia~Norway~Switzerland~1~Medium~Croatia became the EU's 28th member in July 2013.
                What is the name of the global goals adopted by the United Nations for 2030?~Millennium Targets~Sustainable Development Goals~Global Trade Goals~Earth Charter Goals~1~Easy~The 17 Sustainable Development Goals guide the UN's 2030 Agenda.
                Which country hosted the 2023 G20 Leaders' Summit?~Indonesia~India~Brazil~Italy~1~Easy~India hosted the G20 Leaders' Summit in New Delhi in 2023.
                Which country won the 2023 Women's FIFA World Cup?~England~Spain~Sweden~United States~1~Easy~Spain won the 2023 FIFA Women's World Cup.
                Which company developed the reusable Falcon 9 launch vehicle?~Blue Origin~SpaceX~Boeing~Airbus~1~Medium~SpaceX developed the Falcon 9 and regularly reuses its first stage.
                In 2024, which country was the first to approve a CRISPR-based treatment for sickle cell disease?~United Kingdom~Canada~Japan~Australia~0~Hard~The United Kingdom approved Casgevy in November 2023, before the United States.
                Which country hosted the 2024 Summer Paralympic Games?~France~Japan~China~Brazil~0~Easy~Paris, France hosted the 2024 Summer Paralympic Games.
                What was the name of India's first solar observatory mission launched in 2023?~Aditya-L1~Surya-1~Bhaskara-L2~Aryabhata-S~0~Medium~Aditya-L1 is India's solar observatory mission.
                Which city hosted the 2023 Asian Games?~Tokyo~Hangzhou~Bangkok~Jakarta~1~Easy~The 2022 Asian Games, held in 2023, took place in Hangzhou, China.
                """);
        add(questions, "Basic Programming", """
                What is a variable commonly used for in a program?~Storing a value that can be used or changed~Printing a computer case~Cleaning the keyboard~Connecting to a monitor~0~Easy~A variable names a storage location for a value.
                Which structure repeats a block of instructions?~Loop~Comment~Import~Constant~0~Easy~A loop runs a block repeatedly while its condition or iteration allows.
                What does an if statement do?~Chooses whether code runs based on a condition~Always repeats code forever~Deletes a file~Declares a monitor~0~Easy~An if statement conditionally runs code when its condition is true.
                What is a function?~A named reusable block of code~A type of computer cable~A storage device~A screen setting~0~Easy~Functions package reusable instructions and can accept input.
                In many languages, what does the operator == test?~Assignment~Equality~Addition~Negation~1~Easy~The double-equals operator commonly compares two values for equality.
                What is an array commonly used to store?~An ordered collection of values~Only one character~A picture of a screen~A network connection~0~Easy~An array stores multiple values in an indexed order.
                Which data type is commonly used for true or false values?~String~Boolean~Decimal~Character~1~Easy~A Boolean type represents either true or false.
                What is a comment in source code for?~Explaining code to readers and documenting intent~Running faster loops~Storing passwords securely~Replacing a compiler~0~Easy~Comments are notes for people and are generally ignored by program execution.
                What is debugging?~Finding and fixing program errors~Writing only comments~Installing a monitor~Changing a file extension~0~Easy~Debugging is the process of locating and correcting defects in code.
                What does a program's input represent?~Data the program receives~Only its final printed result~An error message~The program's source file name~0~Easy~Input is information supplied to a program for processing.
                What is an algorithm?~A step-by-step method for solving a problem~A type of keyboard~A graphics card~A password format~0~Easy~An algorithm is a finite sequence of steps to solve a problem.
                What is the result of 10 % 3 in languages where % is remainder?~0~1~2~3~1~Medium~Three fits into ten three times with a remainder of one.
                Which loop is commonly suited to processing each item in a collection?~For-each loop~Comment block~Import statement~Class declaration~0~Easy~A for-each loop visits each element in a collection.
                What is a syntax error?~Code that violates the language's grammar~An incorrect monitor resolution~A slow internet connection~An empty hard drive~0~Medium~Syntax errors occur when source code does not follow language rules.
                What does a return statement commonly do in a function?~Sends a result back to its caller~Starts the computer~Repeats the previous line~Renames a variable~0~Easy~Return ends a function call and can provide its result.
                What is a string?~A sequence of text characters~A whole-number-only value~A loop condition~A file system~0~Easy~A string represents text as a sequence of characters.
                Why use meaningful variable names?~To make code easier to understand~To make code run without a processor~To avoid all testing~To turn comments into commands~0~Easy~Clear names help readers understand what stored values represent.
                What is a Boolean expression?~An expression that evaluates to true or false~A list of words only~A drawing command~A number format for fractions~0~Medium~Boolean expressions represent logical true-or-false results.
                What is the purpose of testing a program?~Checking whether it behaves as expected~Making the source file larger~Replacing all variables~Removing the operating system~0~Easy~Tests compare actual behavior with expected behavior.
                What is an infinite loop?~A loop that does not reach its stopping condition~A loop that runs exactly once~A function with no name~A comment inside a loop~0~Medium~An infinite loop continues because its exit condition is never reached.
                """);
        add(questions, "Java", """
                Which keyword is used to inherit a class in Java?~this~extends~implements~super~1~Easy~A class uses extends to inherit from another class.
                Which collection stores unique elements?~ArrayList~LinkedList~HashSet~Vector~2~Medium~A HashSet stores elements without duplicates.
                What is the entry point of a Java application?~start()~run()~main()~init()~2~Easy~The JVM starts a standard Java application by calling main.
                Which type holds a single true or false value?~boolean~char~String~int~0~Easy~The primitive boolean type stores true or false.
                Which keyword creates a new object in Java?~make~new~class~object~1~Easy~The new operator creates an object instance.
                Which keyword declares a constant-like field that cannot be reassigned?~static~final~private~void~1~Medium~A final variable can be assigned only once.
                Which collection preserves insertion order and allows duplicate elements?~HashSet~ArrayList~TreeSet~Map~1~Medium~ArrayList maintains order and permits duplicates.
                Which access modifier allows access from any package?~private~protected~public~default~2~Easy~A public member can be accessed from other packages.
                What does a Java constructor do?~Initializes a newly created object~Destroys the JVM~Sorts every collection~Imports a package~0~Easy~A constructor initializes an instance when it is created.
                Which keyword refers to the current object?~self~this~current~that~1~Easy~In Java, this refers to the current object.
                Which type is used for whole numbers within the int range?~boolean~double~int~char[]~2~Easy~The int primitive stores 32-bit signed whole numbers.
                Which statement handles an exception that may occur in a try block?~catch~throwable~finally~import~0~Medium~A catch block handles exceptions thrown from its associated try block.
                Which keyword is used to implement an interface?~extends~implements~interface~inherits~1~Easy~A class uses implements to provide an interface's methods.
                Which package contains the basic Java String class?~java.io~java.lang~java.net~java.sql~1~Medium~String is in java.lang, which is implicitly imported.
                What does the length field of a Java array provide?~Number of elements~Last element value~Array capacity in bytes~Number of dimensions always~0~Easy~An array's length field gives its number of elements.
                Which loop checks its condition before each iteration?~while~do-while only after body~switch~try-catch~0~Medium~A while loop tests its condition before executing each iteration.
                What is the default value of an instance boolean field?~true~false~null~0~1~Medium~Instance boolean fields default to false.
                Which method compares the content of two Java strings?~same()~equals()~compare()~content()~1~Easy~String.equals compares character content.
                Which keyword prevents a method from being overridden in a subclass?~static~final~native~volatile~1~Medium~A final method cannot be overridden by a subclass.
                What does System.out.println do?~Reads a file~Prints text and a line break~Creates an object~Stops the JVM~1~Easy~println writes output followed by a line terminator.
                """);
        return questions;
    }

    private static void add(List<Question> questions, String category, String rows) {
        String slug = category.toLowerCase().replace(' ', '-');
        String[] entries = rows.strip().split("\\R");
        for (int i = 0; i < entries.length; i++) {
            String[] fields = entries[i].split("~", -1);
            if (fields.length != 8) {
                throw new IllegalStateException("Invalid built-in question in " + category + ".");
            }
            questions.add(new MCQQuestion("seed-" + slug + "-"
                    + String.format(Locale.ROOT, "%02d", i + 1),
                    category, fields[0], List.of(fields[1], fields[2], fields[3], fields[4]),
                    Integer.parseInt(fields[5]), fields[6], fields[7]));
        }
    }
}
