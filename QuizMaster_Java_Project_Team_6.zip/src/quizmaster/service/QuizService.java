package quizmaster.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import quizmaster.model.AnswerReview;
import quizmaster.model.Question;
import quizmaster.model.QuizSession;
import quizmaster.model.ScoreRecord;
import quizmaster.model.User;

public final class QuizService {
    public static final int TIMED_DURATION_SECONDS = 10 * 60;

    private final QuestionService questions;
    private final ScoreService scores;

    public QuizService(QuestionService questions, ScoreService scores) {
        this.questions = questions;
        this.scores = scores;
    }

    public QuizSession start(String category, boolean practice) throws IOException {
        QuizEngine<Question> engine = new QuizEngine<>(questions.getByCategory(category));
        if (engine.getQuestionCount() == 0) {
            throw new IllegalArgumentException("There are no questions in this category yet.");
        }
        engine.shuffleQuestions();
        return new QuizSession(engine.getQuestions(), practice, TIMED_DURATION_SECONDS);
    }

    public QuizSession start(String category, boolean practice, int questionCount) throws IOException {
        if (questionCount != 10 && questionCount != 20) {
            throw new IllegalArgumentException("Choose either 10 or 20 questions.");
        }
        QuizEngine<Question> engine = new QuizEngine<>(questions.getByCategory(category));
        if (engine.getQuestionCount() < questionCount) {
            throw new IllegalArgumentException("This subject has only " + engine.getQuestionCount()
                    + " questions. Add more questions or choose another subject.");
        }
        engine.shuffleQuestions();
        return new QuizSession(engine.getQuestions().subList(0, questionCount),
                practice, TIMED_DURATION_SECONDS);
    }

    public ScoreRecord submit(QuizSession session, User user) throws IOException {
        List<AnswerReview> answerReviews = new ArrayList<>();
        for (int i = 0; i < session.getQuestionCount(); i++) {
            Question question = session.getQuestions().get(i);
            answerReviews.add(new AnswerReview(question.getPrompt(), question.getOptions(),
                    question.getCorrectAnswer(), session.getAnswer(i), question.getExplanation(),
                    question.getDifficulty()));
        }
        ScoreRecord score = new ScoreRecord(user.getUsername(), session.getQuestions().get(0).getCategory(),
                session.countCorrectAnswers(), session.getQuestionCount(), session.isPractice(),
                (int) Math.min(Integer.MAX_VALUE, session.elapsedSeconds()), answerReviews);
        scores.save(score);
        session.markSubmitted();
        return score;
    }
}
