package quizmaster.service;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public final class MigrationService {
    private static final String USERS_FILE = "users.dat";
    private static final String QUESTIONS_FILE = "questions.dat";
    private static final String CATEGORIES_FILE = "categories.dat";
    private static final String SCORES_FILE = "scores.dat";
    private static final String SETTINGS_FILE = "settings.dat";

    private final DatabaseConnection database;
    private final FileStorage storage;

    public MigrationService(DatabaseConnection database, FileStorage storage) {
        this.database = Objects.requireNonNull(database, "database");
        this.storage = Objects.requireNonNull(storage, "storage");
    }

    public MigrationResult migrate() throws IOException, SQLException {
        List<UserRow> users = readUsers();
        List<QuestionRow> questions = readQuestions();
        List<CategoryRow> categories = readCategories(questions);
        List<AttemptRow> attempts = readAttempts();
        List<SettingRow> settings = readSettings();
        int reviewCount = attempts.stream().mapToInt(attempt -> attempt.reviews().size()).sum();

        Counts sourceCounts = new Counts(users.size(), categories.size(), questions.size(),
                attempts.size(), reviewCount, settings.size());
        Counts insertedCounts;
        try (Connection connection = database.open()) {
            connection.setAutoCommit(false);
            try {
                int insertedUsers = importUsers(connection, users);
                int insertedCategories = importCategories(connection, categories);
                int insertedQuestions = importQuestions(connection, questions);
                int insertedAttempts = importAttempts(connection, attempts);
                int insertedReviews = importReviews(connection, attempts);
                int insertedSettings = importSettings(connection, settings);
                connection.commit();
                insertedCounts = new Counts(insertedUsers, insertedCategories, insertedQuestions,
                        insertedAttempts, insertedReviews, insertedSettings);
            } catch (IOException | SQLException | RuntimeException exception) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
                throw exception;
            }
        }
        return new MigrationResult(sourceCounts, insertedCounts);
    }

    private List<UserRow> readUsers() throws IOException {
        List<UserRow> users = new ArrayList<>();
        for (String[] row : storage.read(USERS_FILE, 5, 4)) {
            users.add(new UserRow(row[0], row[1], row[2], row[3], row.length > 4 ? row[4] : row[0]));
        }
        return users;
    }

    private List<QuestionRow> readQuestions() throws IOException {
        List<QuestionRow> questions = new ArrayList<>();
        for (String[] row : storage.read(QUESTIONS_FILE, 11, 10, 8)) {
            try {
                questions.add(new QuestionRow(row[0], row[1], row[2],
                        List.of(row[3], row[4], row[5], row[6]), Integer.parseInt(row[7]),
                        row.length > 8 ? row[8] : "Medium",
                        row.length > 9 ? row[9] : "Legacy question; explanation not provided.",
                        row.length > 10 ? row[10] : quizmaster.model.Question.MCQ_TYPE));
            } catch (RuntimeException exception) {
                throw new IOException("A question record is invalid.", exception);
            }
        }
        return questions;
    }

    private List<CategoryRow> readCategories(List<QuestionRow> questions) throws IOException {
        Map<String, CategoryRow> categories = new LinkedHashMap<>();
        for (QuestionRow question : questions) {
            addCategory(categories, question.category(), false);
        }
        for (String[] row : storage.read(CATEGORIES_FILE, 1)) {
            addCategory(categories, row[0], true);
        }
        return new ArrayList<>(categories.values());
    }

    private void addCategory(Map<String, CategoryRow> categories, String category, boolean explicit)
            throws IOException {
        String key = category.toLowerCase(Locale.ROOT);
        CategoryRow existing = categories.get(key);
        if (existing == null) {
            categories.put(key, new CategoryRow(category, explicit));
        } else if (!existing.name().equals(category)) {
            throw new IOException("Category names differ only by letter case and cannot be represented "
                    + "without loss in SQLite: " + existing.name() + " / " + category);
        } else if (explicit && !existing.explicit()) {
            categories.put(key, new CategoryRow(category, true));
        }
    }

    private List<AttemptRow> readAttempts() throws IOException {
        List<AttemptRow> attempts = new ArrayList<>();
        for (String[] row : storage.read(SCORES_FILE, 9, 7)) {
            try {
                int duration = row.length > 7 ? Math.max(0, Integer.parseInt(row[7])) : 0;
                List<ReviewRow> reviews = row.length > 8 ? decodeReviews(row[8]) : List.of();
                int score = Integer.parseInt(row[3]);
                int total = Integer.parseInt(row[4]);
                if (score < 0 || total <= 0 || score > total) {
                    throw new IllegalArgumentException("Invalid score or total.");
                }
                attempts.add(new AttemptRow(row[0], row[1], row[2], score, total,
                        Boolean.parseBoolean(row[5]), row[6], duration, reviews));
            } catch (RuntimeException exception) {
                throw new IOException("A score history record is invalid.", exception);
            }
        }
        return attempts;
    }

    private List<ReviewRow> decodeReviews(String encoded) throws IOException {
        if (encoded.isEmpty()) {
            return List.of();
        }
        byte[] bytes;
        try {
            bytes = Base64.getUrlDecoder().decode(encoded);
        } catch (IllegalArgumentException exception) {
            throw new IOException("A quiz review record is invalid.", exception);
        }
        List<ReviewRow> reviews = new ArrayList<>();
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(bytes))) {
            int size = input.readInt();
            if (size < 0 || size > 100) {
                throw new IOException("A quiz review record is invalid.");
            }
            for (int i = 0; i < size; i++) {
                String prompt = input.readUTF();
                int optionCount = input.readInt();
                if (optionCount != 4) {
                    throw new IOException("A quiz review record is invalid.");
                }
                List<String> options = new ArrayList<>(4);
                for (int j = 0; j < optionCount; j++) {
                    options.add(input.readUTF());
                }
                int correct = input.readInt();
                int selected = input.readInt();
                String explanation = input.readUTF();
                String difficulty = input.readUTF();
                if (correct < 0 || correct > 3 || selected > 3) {
                    throw new IOException("A quiz review record is invalid.");
                }
                reviews.add(new ReviewRow(prompt, options, correct,
                        selected < 0 ? null : selected, explanation, difficulty));
            }
            if (input.available() != 0) {
                throw new IOException("A quiz review record is invalid.");
            }
        } catch (EOFException exception) {
            throw new IOException("A quiz review record is incomplete.", exception);
        }
        return reviews;
    }

    private List<SettingRow> readSettings() throws IOException {
        List<SettingRow> settings = new ArrayList<>();
        for (String[] row : storage.read(SETTINGS_FILE, 3)) {
            settings.add(new SettingRow(row[0], row[1], row[2]));
        }
        return settings;
    }

    private int importUsers(Connection connection, List<UserRow> users) throws SQLException, IOException {
        String insertSql = "INSERT OR IGNORE INTO users"
                + "(username, salt, password_hash, role, display_name) VALUES (?, ?, ?, ?, ?)";
        String selectSql = "SELECT username, salt, password_hash, role, display_name "
                + "FROM users WHERE username = ?";
        int inserted = 0;
        try (PreparedStatement insert = connection.prepareStatement(insertSql);
             PreparedStatement select = connection.prepareStatement(selectSql)) {
            for (UserRow user : users) {
                insert.setString(1, user.username());
                insert.setString(2, user.salt());
                insert.setString(3, user.passwordHash());
                insert.setString(4, user.role());
                insert.setString(5, user.displayName());
                inserted += insert.executeUpdate();
                select.setString(1, user.username());
                try (ResultSet row = select.executeQuery()) {
                    if (!row.next() || !user.matches(row, 1)) {
                        throw conflict("user", user.username());
                    }
                }
            }
        }
        return inserted;
    }

    private int importCategories(Connection connection, List<CategoryRow> categories)
            throws SQLException, IOException {
        int inserted = 0;
        try (PreparedStatement insert = connection.prepareStatement(
                     "INSERT OR IGNORE INTO categories(name, is_explicit) VALUES (?, ?)");
             PreparedStatement update = connection.prepareStatement(
                     "UPDATE categories SET is_explicit = 1 WHERE name = ? AND ? = 1");
             PreparedStatement select = connection.prepareStatement(
                     "SELECT name FROM categories WHERE name = ?")) {
            for (CategoryRow category : categories) {
                insert.setString(1, category.name());
                insert.setInt(2, category.explicit() ? 1 : 0);
                inserted += insert.executeUpdate();
                update.setString(1, category.name());
                update.setInt(2, category.explicit() ? 1 : 0);
                update.executeUpdate();
                select.setString(1, category.name());
                try (ResultSet row = select.executeQuery()) {
                    if (!row.next() || !category.name().equals(row.getString(1))) {
                        throw conflict("category", category.name());
                    }
                }
            }
        }
        return inserted;
    }

    private int importQuestions(Connection connection, List<QuestionRow> questions)
            throws SQLException, IOException {
        String insertSql = "INSERT OR IGNORE INTO questions"
                + "(id, category, prompt, option_a, option_b, option_c, option_d, "
                + "correct_answer, difficulty, explanation, type) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String selectSql = "SELECT id, category, prompt, option_a, option_b, option_c, option_d, "
                + "correct_answer, difficulty, explanation, type FROM questions WHERE id = ?";
        int inserted = 0;
        try (PreparedStatement insert = connection.prepareStatement(insertSql);
             PreparedStatement select = connection.prepareStatement(selectSql)) {
            for (QuestionRow question : questions) {
                bindQuestion(insert, question);
                inserted += insert.executeUpdate();
                select.setString(1, question.id());
                try (ResultSet row = select.executeQuery()) {
                    if (!row.next() || !question.matches(row)) {
                        throw conflict("question", question.id());
                    }
                }
            }
        }
        return inserted;
    }

    private void bindQuestion(PreparedStatement statement, QuestionRow question) throws SQLException {
        statement.setString(1, question.id());
        statement.setString(2, question.category());
        statement.setString(3, question.prompt());
        for (int i = 0; i < 4; i++) {
            statement.setString(i + 4, question.options().get(i));
        }
        statement.setInt(8, question.correctAnswer());
        statement.setString(9, question.difficulty());
        statement.setString(10, question.explanation());
        statement.setString(11, question.type());
    }

    private int importAttempts(Connection connection, List<AttemptRow> attempts)
            throws SQLException, IOException {
        String insertSql = "INSERT OR IGNORE INTO quiz_attempts"
                + "(id, username, category, score, total, practice, completed_at, duration_seconds) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String selectSql = "SELECT id, username, category, score, total, practice, completed_at, "
                + "duration_seconds FROM quiz_attempts WHERE id = ?";
        int inserted = 0;
        try (PreparedStatement insert = connection.prepareStatement(insertSql);
             PreparedStatement select = connection.prepareStatement(selectSql)) {
            for (AttemptRow attempt : attempts) {
                insert.setString(1, attempt.id());
                insert.setString(2, attempt.username());
                insert.setString(3, attempt.category());
                insert.setInt(4, attempt.score());
                insert.setInt(5, attempt.total());
                insert.setInt(6, attempt.practice() ? 1 : 0);
                insert.setString(7, attempt.completedAt());
                insert.setInt(8, attempt.durationSeconds());
                inserted += insert.executeUpdate();
                select.setString(1, attempt.id());
                try (ResultSet row = select.executeQuery()) {
                    if (!row.next() || !attempt.matches(row)) {
                        throw conflict("quiz attempt", attempt.id());
                    }
                }
            }
        }
        return inserted;
    }

    private int importReviews(Connection connection, List<AttemptRow> attempts)
            throws SQLException, IOException {
        String insertSql = "INSERT OR IGNORE INTO reviews"
                + "(attempt_id, question_index, prompt, option_a, option_b, option_c, option_d, "
                + "correct_answer, selected_answer, explanation, difficulty) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String selectSql = "SELECT attempt_id, question_index, prompt, option_a, option_b, option_c, "
                + "option_d, correct_answer, selected_answer, explanation, difficulty "
                + "FROM reviews WHERE attempt_id = ? AND question_index = ?";
        int inserted = 0;
        try (PreparedStatement insert = connection.prepareStatement(insertSql);
             PreparedStatement select = connection.prepareStatement(selectSql)) {
            for (AttemptRow attempt : attempts) {
                for (int i = 0; i < attempt.reviews().size(); i++) {
                    ReviewRow review = attempt.reviews().get(i);
                    insert.setString(1, attempt.id());
                    insert.setInt(2, i);
                    insert.setString(3, review.prompt());
                    for (int option = 0; option < 4; option++) {
                        insert.setString(option + 4, review.options().get(option));
                    }
                    insert.setInt(8, review.correctAnswer());
                    if (review.selectedAnswer() == null) {
                        insert.setNull(9, java.sql.Types.INTEGER);
                    } else {
                        insert.setInt(9, review.selectedAnswer());
                    }
                    insert.setString(10, review.explanation());
                    insert.setString(11, review.difficulty());
                    inserted += insert.executeUpdate();

                    select.setString(1, attempt.id());
                    select.setInt(2, i);
                    try (ResultSet row = select.executeQuery()) {
                        if (!row.next() || !review.matches(row, attempt.id(), i)) {
                            throw conflict("quiz review", attempt.id() + "/" + i);
                        }
                    }
                }
            }
        }
        return inserted;
    }

    private int importSettings(Connection connection, List<SettingRow> settings)
            throws SQLException, IOException {
        String insertSql = "INSERT OR IGNORE INTO settings(username, setting_key, setting_value) "
                + "VALUES (?, ?, ?)";
        String selectSql = "SELECT username, setting_key, setting_value FROM settings "
                + "WHERE username = ? AND setting_key = ?";
        int inserted = 0;
        try (PreparedStatement insert = connection.prepareStatement(insertSql);
             PreparedStatement select = connection.prepareStatement(selectSql)) {
            for (SettingRow setting : settings) {
                insert.setString(1, setting.username());
                insert.setString(2, setting.key());
                insert.setString(3, setting.value());
                inserted += insert.executeUpdate();
                select.setString(1, setting.username());
                select.setString(2, setting.key());
                try (ResultSet row = select.executeQuery()) {
                    if (!row.next() || !setting.matches(row)) {
                        throw conflict("setting", setting.username() + "/" + setting.key());
                    }
                }
            }
        }
        return inserted;
    }

    private IOException conflict(String type, String key) {
        return new IOException("SQLite contains a conflicting " + type
                + " record; migration was rolled back: " + key);
    }

    public record Counts(int users, int categories, int questions, int attempts, int reviews, int settings) {
    }

    public record MigrationResult(Counts sourceRecords, Counts newlyInsertedRecords) {
    }

    private record CategoryRow(String name, boolean explicit) {
    }

    private record UserRow(String username, String salt, String passwordHash, String role, String displayName) {
        private boolean matches(ResultSet row, int start) throws SQLException {
            return username.equals(row.getString(start))
                    && salt.equals(row.getString(start + 1))
                    && passwordHash.equals(row.getString(start + 2))
                    && role.equals(row.getString(start + 3))
                    && displayName.equals(row.getString(start + 4));
        }
    }

    private record QuestionRow(String id, String category, String prompt, List<String> options,
                               int correctAnswer, String difficulty, String explanation, String type) {
        private boolean matches(ResultSet row) throws SQLException {
            return id.equals(row.getString(1))
                    && category.equals(row.getString(2))
                    && prompt.equals(row.getString(3))
                    && options.equals(Arrays.asList(row.getString(4), row.getString(5),
                            row.getString(6), row.getString(7)))
                    && correctAnswer == row.getInt(8)
                    && difficulty.equals(row.getString(9))
                    && explanation.equals(row.getString(10))
                    && type.equals(row.getString(11));
        }
    }

    private record AttemptRow(String id, String username, String category, int score, int total,
                              boolean practice, String completedAt, int durationSeconds,
                              List<ReviewRow> reviews) {
        private boolean matches(ResultSet row) throws SQLException {
            return id.equals(row.getString(1))
                    && username.equals(row.getString(2))
                    && category.equals(row.getString(3))
                    && score == row.getInt(4)
                    && total == row.getInt(5)
                    && (practice ? 1 : 0) == row.getInt(6)
                    && completedAt.equals(row.getString(7))
                    && durationSeconds == row.getInt(8);
        }
    }

    private record ReviewRow(String prompt, List<String> options, int correctAnswer,
                             Integer selectedAnswer, String explanation, String difficulty) {
        private boolean matches(ResultSet row, String attemptId, int index) throws SQLException {
            int selected = row.getInt(9);
            Integer storedSelected = row.wasNull() ? null : selected;
            return attemptId.equals(row.getString(1))
                    && index == row.getInt(2)
                    && prompt.equals(row.getString(3))
                    && options.equals(Arrays.asList(row.getString(4), row.getString(5),
                            row.getString(6), row.getString(7)))
                    && correctAnswer == row.getInt(8)
                    && Objects.equals(selectedAnswer, storedSelected)
                    && explanation.equals(row.getString(10))
                    && difficulty.equals(row.getString(11));
        }
    }

    private record SettingRow(String username, String key, String value) {
        private boolean matches(ResultSet row) throws SQLException {
            return username.equals(row.getString(1))
                    && key.equals(row.getString(2))
                    && value.equals(row.getString(3));
        }
    }
}
