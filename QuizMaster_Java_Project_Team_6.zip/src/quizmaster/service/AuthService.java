package quizmaster.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import quizmaster.model.User;
import quizmaster.model.User.Role;

public final class AuthService {
    private static final String USERS_FILE = "users.dat";
    private final FileStorage storage;
    private final DatabaseConnection database;

    public AuthService(FileStorage storage) throws IOException {
        this.storage = storage;
        this.database = null;
        if (storage.read(USERS_FILE, 5, 4).isEmpty()) {
            List<String[]> initial = new ArrayList<>();
            initial.add(createRow("admin", "admin123", Role.ADMIN));
            storage.write(USERS_FILE, initial);
        }
    }

    public AuthService(DatabaseConnection database) throws IOException {
        this.storage = null;
        this.database = database;
        SqliteSupport.transaction(database, "initialize authentication", connection -> {
            try (PreparedStatement query = connection.prepareStatement("SELECT 1 FROM users LIMIT 1");
                 ResultSet rows = query.executeQuery()) {
                if (!rows.next()) {
                    String[] admin = createRow("admin", "admin123", Role.ADMIN);
                    try (PreparedStatement insert = connection.prepareStatement(
                            "INSERT INTO users(username, salt, password_hash, role, display_name) "
                                    + "VALUES (?, ?, ?, ?, ?)")) {
                        bindUser(insert, admin);
                        insert.executeUpdate();
                    }
                }
            }
            return null;
        });
    }

    public User login(String username, String password) throws IOException {
        String normalized = normalizeUsername(username);
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Enter your password.");
        }
        if (database != null) {
            return SqliteSupport.read(database, "login", connection -> {
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT username, salt, password_hash, role, display_name "
                                + "FROM users WHERE username = ?")) {
                    query.setString(1, normalized);
                    try (ResultSet row = query.executeQuery()) {
                        if (row.next() && hash(password, row.getString("salt"))
                                .equals(row.getString("password_hash"))) {
                            return new User(row.getString("username"), row.getString("salt"),
                                    row.getString("password_hash"), Role.valueOf(row.getString("role")),
                                    row.getString("display_name"));
                        }
                    }
                }
                throw new IllegalArgumentException("Username or password is incorrect.");
            });
        }
        for (String[] row : storage.read(USERS_FILE, 5, 4)) {
            if (row[0].equalsIgnoreCase(normalized) && hash(password, row[1]).equals(row[2])) {
                return new User(row[0], row[1], row[2], Role.valueOf(row[3]),
                        row.length > 4 ? row[4] : row[0]);
            }
        }
        throw new IllegalArgumentException("Username or password is incorrect.");
    }

    public User register(String username, String password) throws IOException {
        return register(username, username, password);
    }

    public User register(String username, String displayName, String password) throws IOException {
        String normalized = normalizeUsername(username);
        if (normalized.length() < 3 || normalized.length() > 24) {
            throw new IllegalArgumentException("Username must be 3 to 24 characters.");
        }
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters.");
        }
        if (displayName == null || displayName.trim().isEmpty() || displayName.trim().length() > 60) {
            throw new IllegalArgumentException("Enter a name of at most 60 characters.");
        }
        if (database != null) {
            String[] userRow = createRow(normalized, password, Role.STUDENT, displayName.trim());
            try {
                SqliteSupport.transaction(database, "register user", connection -> {
                    try (PreparedStatement insert = connection.prepareStatement(
                            "INSERT INTO users(username, salt, password_hash, role, display_name) "
                                    + "VALUES (?, ?, ?, ?, ?)")) {
                        bindUser(insert, userRow);
                        insert.executeUpdate();
                    }
                    return null;
                });
            } catch (IOException exception) {
                if (isConstraintViolation(exception)) {
                    throw new IllegalArgumentException("That username is already registered.", exception);
                }
                throw exception;
            }
            return new User(userRow[0], userRow[1], userRow[2], Role.STUDENT, userRow[4]);
        }
        List<String[]> rows = storage.read(USERS_FILE, 5, 4);
        for (String[] row : rows) {
            if (row[0].equalsIgnoreCase(normalized)) {
                throw new IllegalArgumentException("That username is already registered.");
            }
        }
        String[] userRow = createRow(normalized, password, Role.STUDENT, displayName.trim());
        rows.add(userRow);
        storage.write(USERS_FILE, rows);
        return new User(userRow[0], userRow[1], userRow[2], Role.STUDENT, userRow[4]);
    }

    public synchronized void changePassword(String username, String currentPassword, String newPassword)
            throws IOException {
        String normalized = normalizeUsername(username);
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("New password must be at least 6 characters.");
        }
        if (database != null) {
            SqliteSupport.transaction(database, "change password", connection -> {
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT salt, password_hash, role, display_name FROM users WHERE username = ?")) {
                    query.setString(1, normalized);
                    try (ResultSet row = query.executeQuery()) {
                        if (!row.next()) {
                            throw new IllegalArgumentException("The selected account no longer exists.");
                        }
                        if (currentPassword == null || !hash(currentPassword, row.getString("salt"))
                                .equals(row.getString("password_hash"))) {
                            throw new IllegalArgumentException("Current password is incorrect.");
                        }
                        String[] updated = createRow(normalized, newPassword,
                                Role.valueOf(row.getString("role")), row.getString("display_name"));
                        try (PreparedStatement update = connection.prepareStatement(
                                "UPDATE users SET salt = ?, password_hash = ? WHERE username = ?")) {
                            update.setString(1, updated[1]);
                            update.setString(2, updated[2]);
                            update.setString(3, normalized);
                            update.executeUpdate();
                        }
                    }
                }
                return null;
            });
            return;
        }
        List<String[]> rows = storage.read(USERS_FILE, 5, 4);
        for (int i = 0; i < rows.size(); i++) {
            String[] row = rows.get(i);
            if (row[0].equalsIgnoreCase(normalized)) {
                if (currentPassword == null || !hash(currentPassword, row[1]).equals(row[2])) {
                    throw new IllegalArgumentException("Current password is incorrect.");
                }
                String[] updated = createRow(row[0], newPassword, Role.valueOf(row[3]),
                        row.length > 4 ? row[4] : row[0]);
                rows.set(i, updated);
                storage.write(USERS_FILE, rows);
                return;
            }
        }
        throw new IllegalArgumentException("The selected account no longer exists.");
    }

    public synchronized List<User> getAllUsers() throws IOException {
        List<User> users = new ArrayList<>();
        if (database != null) {
            return SqliteSupport.read(database, "read users", connection -> {
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT username, salt, password_hash, role, display_name "
                                + "FROM users ORDER BY username COLLATE NOCASE");
                     ResultSet rows = query.executeQuery()) {
                    while (rows.next()) {
                        users.add(new User(rows.getString("username"), rows.getString("salt"),
                                rows.getString("password_hash"), Role.valueOf(rows.getString("role")),
                                rows.getString("display_name")));
                    }
                }
                return users;
            });
        }
        for (String[] row : storage.read(USERS_FILE, 5, 4)) {
            users.add(new User(row[0], row[1], row[2], Role.valueOf(row[3]),
                    row.length > 4 ? row[4] : row[0]));
        }
        return users;
    }

    public synchronized List<User> getStudents() throws IOException {
        List<User> students = new ArrayList<>();
        for (User user : getAllUsers()) {
            if (user.getRole() == Role.STUDENT) {
                students.add(user);
            }
        }
        return students;
    }

    private void bindUser(PreparedStatement insert, String[] user) throws SQLException {
        for (int i = 0; i < user.length; i++) {
            insert.setString(i + 1, user[i]);
        }
    }

    private boolean isConstraintViolation(IOException exception) {
        Throwable cause = exception;
        while (cause != null) {
            if (cause instanceof SQLException sqlException && sqlException.getErrorCode() == 19) {
                return true;
            }
            cause = cause.getCause();
        }
        return false;
    }

    private String normalizeUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter a username.");
        }
        return username.trim();
    }

    private String[] createRow(String username, String password, Role role) {
        return createRow(username, password, role, username);
    }

    private String[] createRow(String username, String password, Role role, String displayName) {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        String salt = Base64.getEncoder().encodeToString(saltBytes);
        return new String[]{username, salt, hash(password, salt), role.name(), displayName};
    }

    private String hash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] result = digest.digest((salt + password).getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(result);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is not available.", exception);
        }
    }
}
