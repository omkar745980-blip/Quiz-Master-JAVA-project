package quizmaster.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import quizmaster.model.Question;

public final class QuizEngine<T extends Question> {
    private final List<T> questions;

    public QuizEngine(List<T> questions) {
        Objects.requireNonNull(questions, "questions");
        this.questions = new ArrayList<>(questions.size());
        for (T question : questions) {
            this.questions.add(Objects.requireNonNull(question, "question"));
        }
    }

    public List<T> getQuestions() {
        return Collections.unmodifiableList(questions);
    }

    public T getQuestion(int index) {
        return questions.get(index);
    }

    public int getQuestionCount() {
        return questions.size();
    }

    public void addQuestion(T question) {
        questions.add(Objects.requireNonNull(question, "question"));
    }

    public T removeQuestion(int index) {
        return questions.remove(index);
    }

    public void shuffleQuestions() {
        Collections.shuffle(questions);
    }
}
