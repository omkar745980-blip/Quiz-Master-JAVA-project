package quizmaster.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import quizmaster.model.Question;

public final class QuestionService {
    private static final String QUESTIONS_FILE = "questions.dat";
    private static final String CATEGORIES_FILE = "categories.dat";
    private final FileStorage storage;
    private final DatabaseConnection database;

    public QuestionService(FileStorage storage) throws IOException {
        this.storage = storage;
        this.database = null;
        List<Question> existing = readAll();
        Set<String> ids = new HashSet<>();
        Set<String> prompts = new HashSet<>();
        boolean changed = false;
        for (String[] row : storage.read(QUESTIONS_FILE, 11, 10, 8)) {
            if (row.length < 10) {
                changed = true;
            }
        }
        for (Question question : existing) {
            ids.add(question.getId());
            prompts.add(questionKey(question.getCategory(), question.getPrompt()));
        }
        for (Question question : QuestionBank.createQuestions()) {
            String key = questionKey(question.getCategory(), question.getPrompt());
            if (!ids.contains(question.getId()) && !prompts.contains(key)) {
                ids.add(question.getId());
                prompts.add(key);
                existing.add(question);
                changed = true;
            }
        }
        if (changed) {
            saveAll(existing);
        }
    }

    public QuestionService(DatabaseConnection database) throws IOException {
        this.storage = null;
        this.database = database;
        SqliteSupport.transaction(database, "initialize questions", connection -> {
            for (Question question : QuestionBank.createQuestions()) {
                ensureCategory(connection, question.getCategory());
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT 1 FROM questions WHERE category = ? COLLATE NOCASE "
                                + "AND prompt = ? COLLATE NOCASE LIMIT 1")) {
                    query.setString(1, question.getCategory());
                    query.setString(2, question.getPrompt());
                    try (ResultSet rows = query.executeQuery()) {
                        if (rows.next()) {
                            continue;
                        }
                    }
                }
                insertQuestion(connection, question);
            }
            return null;
        });
    }

    public synchronized List<Question> getAll() throws IOException {
        if (database != null) {
            return SqliteSupport.read(database, "read questions", connection -> readQuestions(connection));
        }
        List<Question> questions = readAll();
        questions.sort(Comparator.comparing(Question::getCategory, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(Question::getPrompt, String.CASE_INSENSITIVE_ORDER));
        return questions;
    }

    private List<Question> readAll() throws IOException {
        List<Question> questions = new ArrayList<>();
        for (String[] row : storage.read(QUESTIONS_FILE, 11, 10, 8)) {
            questions.add(toQuestion(row));
        }
        return questions;
    }

    public synchronized List<Question> getByCategory(String category) throws IOException {
        List<Question> result = new ArrayList<>();
        for (Question question : getAll()) {
            if (question.getCategory().equalsIgnoreCase(category)) {
                result.add(question);
            }
        }
        return result;
    }

    public synchronized List<String> getCategories() throws IOException {
        if (database != null) {
            return SqliteSupport.read(database, "read categories", connection -> {
                Set<String> categories = new LinkedHashSet<>();
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT name FROM categories ORDER BY name COLLATE NOCASE");
                     ResultSet rows = query.executeQuery()) {
                    while (rows.next()) {
                        categories.add(rows.getString(1));
                    }
                }
                return orderCategories(categories);
            });
        }
        Set<String> categories = new LinkedHashSet<>();
        for (Question question : getAll()) {
            categories.add(question.getCategory());
        }
        for (String[] row : storage.read(CATEGORIES_FILE, 1)) {
            categories.add(row[0]);
        }
        return orderCategories(categories);
    }

    public synchronized void addCategory(String category) throws IOException {
        String normalized = normalizeCategory(category);
        if (database != null) {
            SqliteSupport.transaction(database, "add category", connection -> {
                if (categoryExists(connection, normalized)) {
                    throw new IllegalArgumentException("That category already exists.");
                }
                try (PreparedStatement insert = connection.prepareStatement(
                        "INSERT INTO categories(name, is_explicit) VALUES (?, 1)")) {
                    insert.setString(1, normalized);
                    insert.executeUpdate();
                }
                return null;
            });
            return;
        }
        for (String existing : getCategories()) {
            if (existing.equalsIgnoreCase(normalized)) {
                throw new IllegalArgumentException("That category already exists.");
            }
        }
        List<String[]> rows = storage.read(CATEGORIES_FILE, 1);
        rows.add(new String[]{normalized});
        storage.write(CATEGORIES_FILE, rows);
    }

    public synchronized void renameCategory(String oldName, String newName) throws IOException {
        String oldCategory = normalizeCategory(oldName);
        String newCategory = normalizeCategory(newName);
        if (oldCategory.equalsIgnoreCase(newCategory)) {
            return;
        }
        if (database != null) {
            SqliteSupport.transaction(database, "rename category", connection -> {
                if (!categoryExists(connection, oldCategory)) {
                    throw new IllegalArgumentException("The selected category no longer exists.");
                }
                if (categoryExists(connection, newCategory)) {
                    throw new IllegalArgumentException("A category with that name already exists.");
                }
                try (PreparedStatement update = connection.prepareStatement(
                        "UPDATE categories SET name = ? WHERE name = ?")) {
                    update.setString(1, newCategory);
                    update.setString(2, oldCategory);
                    if (update.executeUpdate() != 1) {
                        throw new IllegalArgumentException("The selected category no longer exists.");
                    }
                }
                return null;
            });
            return;
        }
        if (getCategories().stream().noneMatch(category -> category.equalsIgnoreCase(oldCategory))) {
            throw new IllegalArgumentException("The selected category no longer exists.");
        }
        for (String category : getCategories()) {
            if (category.equalsIgnoreCase(newCategory)) {
                throw new IllegalArgumentException("A category with that name already exists.");
            }
        }
        List<Question> questions = getAll();
        boolean found = false;
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            if (question.getCategory().equalsIgnoreCase(oldCategory)) {
                questions.set(i, question.withCategory(newCategory));
                found = true;
            }
        }
        if (found) {
            saveAll(questions);
        }
        List<String[]> categories = storage.read(CATEGORIES_FILE, 1);
        categories.removeIf(row -> row[0].equalsIgnoreCase(oldCategory));
        categories.add(new String[]{newCategory});
        storage.write(CATEGORIES_FILE, categories);
    }

    public synchronized void deleteCategory(String categoryName) throws IOException {
        String category = normalizeCategory(categoryName);
        if (database != null) {
            SqliteSupport.transaction(database, "delete category", connection -> {
                if (!categoryExists(connection, category)) {
                    throw new IllegalArgumentException("The selected category no longer exists.");
                }
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT 1 FROM questions WHERE category = ? COLLATE NOCASE LIMIT 1")) {
                    query.setString(1, category);
                    try (ResultSet rows = query.executeQuery()) {
                        if (rows.next()) {
                            throw new IllegalArgumentException(
                                    "This category still has questions. Move or remove them first.");
                        }
                    }
                }
                try (PreparedStatement delete = connection.prepareStatement(
                        "DELETE FROM categories WHERE name = ?")) {
                    delete.setString(1, category);
                    delete.executeUpdate();
                }
                return null;
            });
            return;
        }
        for (Question question : getByCategory(category)) {
            throw new IllegalArgumentException("This category still has questions. Move or remove them first.");
        }
        List<String[]> categories = storage.read(CATEGORIES_FILE, 1);
        if (!categories.removeIf(row -> row[0].equalsIgnoreCase(category))) {
            throw new IllegalArgumentException("The selected category no longer exists.");
        }
        storage.write(CATEGORIES_FILE, categories);
    }

    public synchronized void add(Question question) throws IOException {
        validate(question);
        if (database != null) {
            SqliteSupport.transaction(database, "add question", connection -> {
                ensureCategory(connection, question.getCategory());
                insertQuestion(connection, question);
                return null;
            });
            return;
        }
        List<Question> questions = getAll();
        questions.add(question);
        saveAll(questions);
    }

    public synchronized void update(Question question) throws IOException {
        validate(question);
        if (database != null) {
            SqliteSupport.transaction(database, "update question", connection -> {
                String previousCategory;
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT category FROM questions WHERE id = ?")) {
                    query.setString(1, question.getId());
                    try (ResultSet row = query.executeQuery()) {
                        if (!row.next()) {
                            throw new IllegalArgumentException("The selected question no longer exists.");
                        }
                        previousCategory = row.getString(1);
                    }
                }
                ensureCategory(connection, question.getCategory());
                try (PreparedStatement update = connection.prepareStatement(
                        "UPDATE questions SET category = ?, prompt = ?, option_a = ?, option_b = ?, "
                                + "option_c = ?, option_d = ?, correct_answer = ?, difficulty = ?, "
                                + "explanation = ?, type = ? WHERE id = ?")) {
                    bindQuestion(update, question, false);
                    update.setString(11, question.getId());
                    if (update.executeUpdate() != 1) {
                        throw new IllegalArgumentException("The selected question no longer exists.");
                    }
                }
                if (!previousCategory.equalsIgnoreCase(question.getCategory())) {
                    removeUnusedImplicitCategory(connection, previousCategory);
                }
                return null;
            });
            return;
        }
        List<Question> questions = getAll();
        boolean found = false;
        for (int i = 0; i < questions.size(); i++) {
            if (questions.get(i).getId().equals(question.getId())) {
                questions.set(i, question);
                found = true;
                break;
            }
        }
        if (!found) {
            throw new IllegalArgumentException("The selected question no longer exists.");
        }
        saveAll(questions);
    }

    public synchronized void delete(String id) throws IOException {
        if (database != null) {
            SqliteSupport.transaction(database, "delete question", connection -> {
                String category;
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT category FROM questions WHERE id = ?")) {
                    query.setString(1, id);
                    try (ResultSet row = query.executeQuery()) {
                        if (!row.next()) {
                            throw new IllegalArgumentException("The selected question no longer exists.");
                        }
                        category = row.getString(1);
                    }
                }
                try (PreparedStatement delete = connection.prepareStatement(
                        "DELETE FROM questions WHERE id = ?")) {
                    delete.setString(1, id);
                    if (delete.executeUpdate() != 1) {
                        throw new IllegalArgumentException("The selected question no longer exists.");
                    }
                }
                removeUnusedImplicitCategory(connection, category);
                return null;
            });
            return;
        }
        List<Question> questions = getAll();
        if (!questions.removeIf(question -> question.getId().equals(id))) {
            throw new IllegalArgumentException("The selected question no longer exists.");
        }
        saveAll(questions);
    }

    private void validate(Question question) {
        if (question.getCategory().isEmpty() || question.getPrompt().isEmpty()) {
            throw new IllegalArgumentException("Category and question text are required.");
        }
        if (question.getExplanation().isEmpty()) {
            throw new IllegalArgumentException("A short explanation is required.");
        }
        for (int i = 0; i < question.getOptionCount(); i++) {
            if (question.getOptions().get(i).trim().isEmpty()) {
                throw new IllegalArgumentException("All question answer options are required.");
            }
        }
    }

    private Question toQuestion(String[] row) throws IOException {
        try {
            return Question.fromType(row.length > 10 ? row[10] : Question.MCQ_TYPE,
                    row[0], row[1], row[2], Arrays.asList(row[3], row[4], row[5], row[6]),
                    Integer.parseInt(row[7]), row.length > 8 ? row[8] : "Medium",
                    row.length > 9 ? row[9] : "Legacy question; explanation not provided.");
        } catch (RuntimeException exception) {
            throw new IOException("A question record is invalid.", exception);
        }
    }

    private String questionKey(String category, String prompt) {
        return category.trim().toLowerCase(Locale.ROOT) + "\n" + prompt.trim().toLowerCase(Locale.ROOT);
    }

    private String normalizeCategory(String category) {
        if (category == null || category.trim().isEmpty() || category.trim().length() > 40) {
            throw new IllegalArgumentException("Category name must contain 1 to 40 characters.");
        }
        return category.trim();
    }

    private void saveAll(List<Question> questions) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (Question question : questions) {
            rows.add(new String[]{question.getId(), question.getCategory(), question.getPrompt(),
                    question.getOptions().get(0), question.getOptions().get(1),
                    question.getOptions().get(2), question.getOptions().get(3),
                    Integer.toString(question.getCorrectAnswer()), question.getDifficulty(),
                    question.getExplanation(), question.getType()});
        }
        storage.write(QUESTIONS_FILE, rows);
    }

    private List<Question> readQuestions(java.sql.Connection connection) throws java.sql.SQLException {
        List<Question> questions = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT id, category, prompt, option_a, option_b, option_c, option_d, "
                        + "correct_answer, difficulty, explanation, type FROM questions "
                        + "ORDER BY category COLLATE NOCASE, prompt COLLATE NOCASE");
             ResultSet rows = query.executeQuery()) {
            while (rows.next()) {
                questions.add(Question.fromType(rows.getString("type"), rows.getString("id"),
                        rows.getString("category"),
                        rows.getString("prompt"), List.of(rows.getString("option_a"),
                                rows.getString("option_b"), rows.getString("option_c"),
                                rows.getString("option_d")),
                        rows.getInt("correct_answer"), rows.getString("difficulty"),
                        rows.getString("explanation")));
            }
        }
        return questions;
    }

    private List<String> orderCategories(Set<String> categories) {
        List<String> ordered = new ArrayList<>();
        for (String category : QuestionBank.CATEGORIES) {
            if (categories.remove(category)) {
                ordered.add(category);
            }
        }
        List<String> remaining = new ArrayList<>(categories);
        remaining.sort(String.CASE_INSENSITIVE_ORDER);
        ordered.addAll(remaining);
        return ordered;
    }

    private boolean categoryExists(java.sql.Connection connection, String category)
            throws java.sql.SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT 1 FROM categories WHERE name = ? COLLATE NOCASE")) {
            query.setString(1, category);
            try (ResultSet rows = query.executeQuery()) {
                return rows.next();
            }
        }
    }

    private void ensureCategory(java.sql.Connection connection, String category)
            throws java.sql.SQLException {
        try (PreparedStatement insert = connection.prepareStatement(
                "INSERT OR IGNORE INTO categories(name) VALUES (?)")) {
            insert.setString(1, category);
            insert.executeUpdate();
        }
    }

    private void removeUnusedImplicitCategory(java.sql.Connection connection, String category)
            throws java.sql.SQLException {
        try (PreparedStatement delete = connection.prepareStatement(
                "DELETE FROM categories WHERE name = ? COLLATE NOCASE AND is_explicit = 0 "
                        + "AND NOT EXISTS (SELECT 1 FROM questions "
                        + "WHERE questions.category = categories.name COLLATE NOCASE)")) {
            delete.setString(1, category);
            delete.executeUpdate();
        }
    }

    private void insertQuestion(java.sql.Connection connection, Question question)
            throws java.sql.SQLException {
        try (PreparedStatement insert = connection.prepareStatement(
                "INSERT INTO questions(id, category, prompt, option_a, option_b, option_c, option_d, "
                        + "correct_answer, difficulty, explanation, type) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            bindQuestion(insert, question, true);
            insert.executeUpdate();
        }
    }

    private void bindQuestion(PreparedStatement statement, Question question, boolean includeId)
            throws java.sql.SQLException {
        int offset = 0;
        if (includeId) {
            statement.setString(1, question.getId());
            offset = 1;
        }
        statement.setString(1 + offset, question.getCategory());
        statement.setString(2 + offset, question.getPrompt());
        for (int i = 0; i < 4; i++) {
            statement.setString(3 + offset + i, question.getOptions().get(i));
        }
        statement.setInt(7 + offset, question.getCorrectAnswer());
        statement.setString(8 + offset, question.getDifficulty());
        statement.setString(9 + offset, question.getExplanation());
        statement.setString(10 + offset, question.getType());
    }
}
