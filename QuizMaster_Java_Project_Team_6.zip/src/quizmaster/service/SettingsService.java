package quizmaster.service;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public final class SettingsService {
    private static final String SETTINGS_FILE = "settings.dat";
    private final FileStorage storage;
    private final DatabaseConnection database;

    public SettingsService(FileStorage storage) {
        this.storage = storage;
        this.database = null;
    }

    public SettingsService(DatabaseConnection database) {
        this.storage = null;
        this.database = database;
    }

    public synchronized String get(String username, String key, String defaultValue) throws IOException {
        if (database != null) {
            return SqliteSupport.read(database, "read settings", connection -> {
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT setting_value FROM settings WHERE username = ? COLLATE NOCASE "
                                + "AND setting_key = ?")) {
                    query.setString(1, username);
                    query.setString(2, key);
                    try (ResultSet row = query.executeQuery()) {
                        return row.next() ? row.getString(1) : defaultValue;
                    }
                }
            });
        }
        for (String[] row : storage.read(SETTINGS_FILE, 3)) {
            if (row[0].equalsIgnoreCase(username) && row[1].equals(key)) {
                return row[2];
            }
        }
        return defaultValue;
    }

    public synchronized void set(String username, String key, String value) throws IOException {
        if (database != null) {
            SqliteSupport.transaction(database, "save settings", connection -> {
                try (PreparedStatement update = connection.prepareStatement(
                        "INSERT INTO settings(username, setting_key, setting_value) VALUES (?, ?, ?) "
                                + "ON CONFLICT(username, setting_key) DO UPDATE "
                                + "SET setting_value = excluded.setting_value")) {
                    update.setString(1, username);
                    update.setString(2, key);
                    update.setString(3, value);
                    update.executeUpdate();
                }
                return null;
            });
            return;
        }
        List<String[]> rows = storage.read(SETTINGS_FILE, 3);
        boolean updated = false;
        for (int i = 0; i < rows.size(); i++) {
            if (rows.get(i)[0].equalsIgnoreCase(username) && rows.get(i)[1].equals(key)) {
                rows.set(i, new String[]{username, key, value});
                updated = true;
                break;
            }
        }
        if (!updated) {
            rows.add(new String[]{username, key, value});
        }
        storage.write(SETTINGS_FILE, rows);
    }

    public int getDefaultQuestionCount(String username) throws IOException {
        try {
            int count = Integer.parseInt(get(username, "questionCount", "10"));
            if (count != 10 && count != 20) {
                throw new IOException("The saved question-count setting must be 10 or 20.");
            }
            return count;
        } catch (NumberFormatException exception) {
            throw new IOException("The saved question-count setting is invalid.", exception);
        }
    }

    public boolean areNotificationsEnabled(String username) throws IOException {
        String value = get(username, "notifications", "true");
        if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) {
            throw new IOException("The saved notification setting is invalid.");
        }
        return Boolean.parseBoolean(value);
    }
}
