package quizmaster.service;

import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;
import quizmaster.model.AnswerReview;
import quizmaster.model.ScoreRecord;

public final class ScoreService {
    private static final String SCORES_FILE = "scores.dat";
    private final FileStorage storage;
    private final DatabaseConnection database;

    public ScoreService(FileStorage storage) {
        this.storage = storage;
        this.database = null;
    }

    public ScoreService(DatabaseConnection database) {
        this.storage = null;
        this.database = database;
    }

    public synchronized void save(ScoreRecord score) throws IOException {
        if (database != null) {
            SqliteSupport.transaction(database, "save quiz result", connection -> {
                try (PreparedStatement insert = connection.prepareStatement(
                        "INSERT INTO quiz_attempts(id, username, category, score, total, practice, "
                                + "completed_at, duration_seconds) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
                    insert.setString(1, score.getId());
                    insert.setString(2, score.getUsername());
                    insert.setString(3, score.getCategory());
                    insert.setInt(4, score.getScore());
                    insert.setInt(5, score.getTotal());
                    insert.setInt(6, score.isPractice() ? 1 : 0);
                    insert.setString(7, score.getCompletedAt().toString());
                    insert.setInt(8, score.getDurationSeconds());
                    insert.executeUpdate();
                }
                try (PreparedStatement insert = connection.prepareStatement(
                        "INSERT INTO reviews(attempt_id, question_index, prompt, option_a, option_b, "
                                + "option_c, option_d, correct_answer, selected_answer, explanation, difficulty) "
                                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                    for (int i = 0; i < score.getAnswerReviews().size(); i++) {
                        AnswerReview review = score.getAnswerReviews().get(i);
                        insert.setString(1, score.getId());
                        insert.setInt(2, i);
                        insert.setString(3, review.getPrompt());
                        for (int option = 0; option < 4; option++) {
                            insert.setString(option + 4, review.getOptions().get(option));
                        }
                        insert.setInt(8, review.getCorrectAnswer());
                        if (review.getSelectedAnswer() == null) {
                            insert.setNull(9, java.sql.Types.INTEGER);
                        } else {
                            insert.setInt(9, review.getSelectedAnswer());
                        }
                        insert.setString(10, review.getExplanation());
                        insert.setString(11, review.getDifficulty());
                        insert.addBatch();
                    }
                    insert.executeBatch();
                }
                return null;
            });
            return;
        }
        List<String[]> rows = storage.read(SCORES_FILE, 9, 7);
        rows.add(new String[]{score.getId(), score.getUsername(), score.getCategory(),
                Integer.toString(score.getScore()), Integer.toString(score.getTotal()),
                Boolean.toString(score.isPractice()), score.getCompletedAt().toString(),
                Integer.toString(score.getDurationSeconds()), encodeReviews(score.getAnswerReviews())});
        storage.write(SCORES_FILE, rows);
    }

    public synchronized List<ScoreRecord> getForUser(String username) throws IOException {
        List<ScoreRecord> records = new ArrayList<>();
        for (ScoreRecord record : getAll()) {
            if (record.getUsername().equalsIgnoreCase(username)) {
                records.add(record);
            }
        }
        return records;
    }

    public synchronized List<ScoreRecord> getAll() throws IOException {
        if (database != null) {
            return SqliteSupport.read(database, "read quiz history", connection -> {
                List<ScoreRecord> records = new ArrayList<>();
                try (PreparedStatement query = connection.prepareStatement(
                        "SELECT id, username, category, score, total, practice, completed_at, "
                                + "duration_seconds FROM quiz_attempts "
                                + "ORDER BY completed_at DESC, rowid DESC");
                     ResultSet rows = query.executeQuery()) {
                    while (rows.next()) {
                        String id = rows.getString("id");
                        List<AnswerReview> reviews = readReviews(connection, id);
                        records.add(new ScoreRecord(id, rows.getString("username"),
                                rows.getString("category"), rows.getInt("score"), rows.getInt("total"),
                                rows.getInt("practice") != 0,
                                LocalDateTime.parse(rows.getString("completed_at")),
                                rows.getInt("duration_seconds"), reviews));
                    }
                }
                return records;
            });
        }
        List<ScoreRecord> records = new ArrayList<>();
        for (String[] row : storage.read(SCORES_FILE, 9, 7)) {
            try {
                int duration = row.length > 7 ? Integer.parseInt(row[7]) : 0;
                List<AnswerReview> reviews = row.length > 8 ? decodeReviews(row[8]) : List.of();
                records.add(new ScoreRecord(row[0], row[1], row[2], Integer.parseInt(row[3]),
                        Integer.parseInt(row[4]), Boolean.parseBoolean(row[5]), LocalDateTime.parse(row[6]),
                        duration, reviews));
            } catch (RuntimeException exception) {
                throw new IOException("A score history record is invalid.", exception);
            }
        }
        records.sort(Comparator.comparing(ScoreRecord::getCompletedAt).reversed());
        return records;
    }

    private List<AnswerReview> readReviews(java.sql.Connection connection, String attemptId)
            throws SQLException {
        List<AnswerReview> reviews = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT prompt, option_a, option_b, option_c, option_d, correct_answer, "
                        + "selected_answer, explanation, difficulty FROM reviews "
                        + "WHERE attempt_id = ? ORDER BY question_index")) {
            query.setString(1, attemptId);
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) {
                    int selected = rows.getInt("selected_answer");
                    Integer selectedAnswer = rows.wasNull() ? null : selected;
                    reviews.add(new AnswerReview(rows.getString("prompt"),
                            List.of(rows.getString("option_a"), rows.getString("option_b"),
                                    rows.getString("option_c"), rows.getString("option_d")),
                            rows.getInt("correct_answer"), selectedAnswer,
                            rows.getString("explanation"), rows.getString("difficulty")));
                }
            }
        }
        return reviews;
    }

    public synchronized void exportCsv(Path target, String username) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("Completed,Username,Category,Mode,Score,Total,Percentage,Correct,Incorrect,Unanswered,Duration seconds");
        for (ScoreRecord record : getForUser(username)) {
            lines.add(csv(record.getCompletedAt().toString()) + "," + csv(record.getUsername()) + ","
                    + csv(record.getCategory()) + "," + csv(record.isPractice() ? "Practice" : "Timed exam")
                    + "," + record.getScore() + "," + record.getTotal() + "," + record.getPercentage()
                    + "," + record.getCorrectCount() + "," + record.getIncorrectCount() + ","
                    + record.getUnansweredCount() + "," + record.getDurationSeconds());
        }
        java.nio.file.Files.write(target, lines, StandardCharsets.UTF_8);
    }

    private String csv(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private String encodeReviews(List<AnswerReview> reviews) throws IOException {
        if (reviews.isEmpty()) {
            return "";
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream output = new DataOutputStream(bytes)) {
            output.writeInt(reviews.size());
            for (AnswerReview review : reviews) {
                output.writeUTF(review.getPrompt());
                output.writeInt(review.getOptions().size());
                for (String option : review.getOptions()) {
                    output.writeUTF(option);
                }
                output.writeInt(review.getCorrectAnswer());
                output.writeInt(review.getSelectedAnswer() == null ? -1 : review.getSelectedAnswer());
                output.writeUTF(review.getExplanation());
                output.writeUTF(review.getDifficulty());
            }
        }
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes.toByteArray());
    }

    private List<AnswerReview> decodeReviews(String encoded) throws IOException {
        if (encoded.isEmpty()) {
            return List.of();
        }
        byte[] bytes;
        try {
            bytes = Base64.getUrlDecoder().decode(encoded);
        } catch (IllegalArgumentException exception) {
            throw new IOException("A quiz review record is invalid.", exception);
        }
        List<AnswerReview> reviews = new ArrayList<>();
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(bytes))) {
            int size = input.readInt();
            if (size < 0 || size > 100) {
                throw new IOException("A quiz review record is invalid.");
            }
            for (int i = 0; i < size; i++) {
                String prompt = input.readUTF();
                int optionCount = input.readInt();
                if (optionCount != 4) {
                    throw new IOException("A quiz review record is invalid.");
                }
                List<String> options = new ArrayList<>(4);
                for (int j = 0; j < optionCount; j++) {
                    options.add(input.readUTF());
                }
                int correct = input.readInt();
                int selected = input.readInt();
                reviews.add(new AnswerReview(prompt, options, correct, selected < 0 ? null : selected,
                        input.readUTF(), input.readUTF()));
            }
            if (input.available() != 0) {
                throw new IOException("A quiz review record is invalid.");
            }
        } catch (java.io.EOFException exception) {
            throw new IOException("A quiz review record is incomplete.", exception);
        }
        return reviews;
    }
}
