package quizmaster.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

public final class DatabaseConnection {
    private static final String[] SCHEMA = {
        "CREATE TABLE IF NOT EXISTS schema_migrations ("
                + "version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE TABLE IF NOT EXISTS users ("
                + "username TEXT PRIMARY KEY COLLATE NOCASE, "
                + "salt TEXT NOT NULL, password_hash TEXT NOT NULL, "
                + "role TEXT NOT NULL CHECK (role IN ('STUDENT', 'ADMIN')), "
                + "display_name TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS categories ("
                + "name TEXT PRIMARY KEY COLLATE NOCASE, "
                + "is_explicit INTEGER NOT NULL DEFAULT 0 CHECK (is_explicit IN (0, 1)))",
        "CREATE TABLE IF NOT EXISTS questions ("
                + "id TEXT PRIMARY KEY, category TEXT NOT NULL, prompt TEXT NOT NULL, "
                + "option_a TEXT NOT NULL, option_b TEXT NOT NULL, "
                + "option_c TEXT NOT NULL, option_d TEXT NOT NULL, "
                + "correct_answer INTEGER NOT NULL CHECK (correct_answer BETWEEN 0 AND 3), "
                + "difficulty TEXT NOT NULL CHECK (difficulty IN ('Easy', 'Medium', 'Hard')), "
                + "explanation TEXT NOT NULL, "
                + "type TEXT NOT NULL DEFAULT 'MCQ' CHECK (type IN ('MCQ', 'TRUE_FALSE')), "
                + "FOREIGN KEY (category) REFERENCES categories(name) "
                + "ON UPDATE CASCADE ON DELETE RESTRICT)",
        "CREATE TABLE IF NOT EXISTS quiz_attempts ("
                + "id TEXT PRIMARY KEY, "
                + "username TEXT NOT NULL REFERENCES users(username) ON DELETE RESTRICT, "
                + "category TEXT NOT NULL, score INTEGER NOT NULL CHECK (score >= 0), "
                + "total INTEGER NOT NULL CHECK (total > 0 AND score <= total), "
                + "practice INTEGER NOT NULL CHECK (practice IN (0, 1)), "
                + "completed_at TEXT NOT NULL, duration_seconds INTEGER NOT NULL CHECK (duration_seconds >= 0))",
        "CREATE TABLE IF NOT EXISTS reviews ("
                + "attempt_id TEXT NOT NULL REFERENCES quiz_attempts(id) ON DELETE CASCADE, "
                + "question_index INTEGER NOT NULL CHECK (question_index >= 0), "
                + "prompt TEXT NOT NULL, option_a TEXT NOT NULL, option_b TEXT NOT NULL, "
                + "option_c TEXT NOT NULL, option_d TEXT NOT NULL, "
                + "correct_answer INTEGER NOT NULL CHECK (correct_answer BETWEEN 0 AND 3), "
                + "selected_answer INTEGER CHECK (selected_answer IS NULL OR selected_answer BETWEEN 0 AND 3), "
                + "explanation TEXT NOT NULL, difficulty TEXT NOT NULL, "
                + "PRIMARY KEY (attempt_id, question_index))",
        "CREATE TABLE IF NOT EXISTS settings ("
                + "username TEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE, "
                + "setting_key TEXT NOT NULL, setting_value TEXT NOT NULL, "
                + "PRIMARY KEY (username, setting_key))",
        "CREATE INDEX IF NOT EXISTS quiz_attempts_username_completed "
                + "ON quiz_attempts(username, completed_at DESC)",
        "INSERT OR IGNORE INTO schema_migrations(version) VALUES (1)",
        "INSERT OR IGNORE INTO schema_migrations(version) VALUES (2)",
        "INSERT OR IGNORE INTO schema_migrations(version) VALUES (3)"
    };

    private final Path databaseFile;

    public DatabaseConnection() {
        this(Paths.get("data", "quizmaster.sqlite"));
    }

    public DatabaseConnection(Path databaseFile) {
        this.databaseFile = Objects.requireNonNull(databaseFile, "databaseFile")
                .toAbsolutePath().normalize();
    }

    public Path getDatabaseFile() {
        return databaseFile;
    }

    public Connection open() throws IOException, SQLException {
        Path parent = databaseFile.getParent();
        if (parent != null) {
            try {
                Files.createDirectories(parent);
            } catch (IOException exception) {
                throw new IOException("SQLite database directory could not be created: "
                        + parent + " (" + exception.getMessage() + ")", exception);
            }
        }

        String path = databaseFile.toString().replace('\\', '/');
        Connection connection = DriverManager.getConnection("jdbc:sqlite:" + path);
        try {
            configure(connection);
            initializeSchema(connection);
            return connection;
        } catch (SQLException exception) {
            try {
                connection.close();
            } catch (SQLException closeException) {
                exception.addSuppressed(closeException);
            }
            throw exception;
        }
    }

    private void configure(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
            statement.execute("PRAGMA busy_timeout = 5000");
        }
    }

    private void initializeSchema(Connection connection) throws SQLException {
        boolean originalAutoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        SQLException schemaFailure = null;
        try (Statement statement = connection.createStatement()) {
            for (String sql : SCHEMA) {
                statement.execute(sql);
            }
            ensureCategoryMetadata(connection);
            ensureQuestionType(connection);
            connection.commit();
        } catch (SQLException exception) {
            schemaFailure = exception;
            try {
                connection.rollback();
            } catch (SQLException rollbackException) {
                exception.addSuppressed(rollbackException);
            }
            throw exception;
        } finally {
            try {
                connection.setAutoCommit(originalAutoCommit);
            } catch (SQLException restoreException) {
                if (schemaFailure != null) {
                    schemaFailure.addSuppressed(restoreException);
                } else {
                    throw restoreException;
                }
            }
        }
    }

    private void ensureCategoryMetadata(Connection connection) throws SQLException {
        boolean hasExplicitFlag = false;
        try (Statement statement = connection.createStatement();
             java.sql.ResultSet columns = statement.executeQuery("PRAGMA table_info(categories)")) {
            while (columns.next()) {
                if ("is_explicit".equalsIgnoreCase(columns.getString("name"))) {
                    hasExplicitFlag = true;
                    break;
                }
            }
        }
        if (!hasExplicitFlag) {
            try (Statement statement = connection.createStatement()) {
                statement.execute("ALTER TABLE categories ADD COLUMN "
                        + "is_explicit INTEGER NOT NULL DEFAULT 0 CHECK (is_explicit IN (0, 1))");
            }
        }
    }

    private void ensureQuestionType(Connection connection) throws SQLException {
        boolean hasType = false;
        try (Statement statement = connection.createStatement();
             java.sql.ResultSet columns = statement.executeQuery("PRAGMA table_info(questions)")) {
            while (columns.next()) {
                if ("type".equalsIgnoreCase(columns.getString("name"))) {
                    hasType = true;
                    break;
                }
            }
        }
        if (!hasType) {
            try (Statement statement = connection.createStatement()) {
                statement.execute("ALTER TABLE questions ADD COLUMN "
                        + "type TEXT NOT NULL DEFAULT 'MCQ' "
                        + "CHECK (type IN ('MCQ', 'TRUE_FALSE'))");
            }
        }
    }
}
