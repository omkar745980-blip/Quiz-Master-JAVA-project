package quizmaster.service;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.IntConsumer;
import javax.swing.SwingUtilities;
import quizmaster.model.QuizSession;

public final class QuizTimerThread extends Thread {
    private final QuizSession session;
    private final IntConsumer onTick;
    private final Runnable onTimeUp;
    private final AtomicBoolean started = new AtomicBoolean();
    private final AtomicBoolean cancelled = new AtomicBoolean();

    public QuizTimerThread(QuizSession session, IntConsumer onTick, Runnable onTimeUp) {
        super("quiz-countdown");
        this.session = Objects.requireNonNull(session, "session");
        this.onTick = Objects.requireNonNull(onTick, "onTick");
        this.onTimeUp = Objects.requireNonNull(onTimeUp, "onTimeUp");
        setDaemon(true);
    }

    public boolean startOnce() {
        if (!started.compareAndSet(false, true)) {
            return false;
        }
        start();
        return true;
    }

    public void cancelTimer() {
        cancelled.set(true);
        interrupt();
    }

    @Override
    public void run() {
        while (!cancelled.get()) {
            int remaining = session.remainingSeconds();
            if (remaining == 0) {
                SwingUtilities.invokeLater(onTimeUp);
                return;
            }
            SwingUtilities.invokeLater(() -> onTick.accept(remaining));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException exception) {
                if (!cancelled.get()) {
                    Thread.currentThread().interrupt();
                }
                return;
            }
        }
    }
}
