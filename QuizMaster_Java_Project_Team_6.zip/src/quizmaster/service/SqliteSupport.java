package quizmaster.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

final class SqliteSupport {
    @FunctionalInterface
    interface SqlWork<T> {
        T run(Connection connection) throws SQLException, IOException;
    }

    private SqliteSupport() {
    }

    static <T> T read(DatabaseConnection database, String operation, SqlWork<T> work) throws IOException {
        try (Connection connection = database.open()) {
            return work.run(connection);
        } catch (SQLException exception) {
            throw failure(operation, exception);
        }
    }

    static <T> T transaction(DatabaseConnection database, String operation, SqlWork<T> work)
            throws IOException {
        try (Connection connection = database.open()) {
            connection.setAutoCommit(false);
            try {
                T result = work.run(connection);
                connection.commit();
                return result;
            } catch (SQLException | IOException | RuntimeException exception) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
                if (exception instanceof SQLException sqlException) {
                    throw failure(operation, sqlException);
                }
                if (exception instanceof IOException ioException) {
                    throw ioException;
                }
                throw exception;
            }
        } catch (SQLException exception) {
            throw failure(operation, exception);
        }
    }

    private static IOException failure(String operation, SQLException exception) {
        return new IOException("SQLite " + operation + " failed: " + exception.getMessage(), exception);
    }
}
