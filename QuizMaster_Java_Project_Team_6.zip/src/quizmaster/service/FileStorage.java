package quizmaster.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public final class FileStorage {
    private final Path directory;

    public FileStorage() throws IOException {
        this(Paths.get("data"));
    }

    FileStorage(Path directory) throws IOException {
        this.directory = directory;
        Files.createDirectories(directory);
    }

    public synchronized List<String[]> read(String fileName, int fields) throws IOException {
        return read(fileName, fields, -1);
    }

    public synchronized List<String[]> read(String fileName, int fields, int... legacyFields) throws IOException {
        Path file = directory.resolve(fileName);
        List<String[]> result = new ArrayList<>();
        if (!Files.exists(file)) {
            return result;
        }
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            if (line.trim().isEmpty()) {
                continue;
            }
            String[] encoded = line.split("\\|", -1);
            boolean acceptedLength = encoded.length == fields;
            for (int legacyFieldCount : legacyFields) {
                acceptedLength |= encoded.length == legacyFieldCount;
            }
            if (!acceptedLength) {
                throw new IOException("Invalid data in " + fileName + ". Please check the file contents.");
            }
            String[] row = new String[encoded.length];
            try {
                for (int i = 0; i < encoded.length; i++) {
                    row[i] = new String(Base64.getUrlDecoder().decode(encoded[i]), StandardCharsets.UTF_8);
                }
            } catch (IllegalArgumentException exception) {
                throw new IOException("Invalid encoded data in " + fileName + ".", exception);
            }
            result.add(row);
        }
        return result;
    }

    public synchronized void write(String fileName, List<String[]> rows) throws IOException {
        Path file = directory.resolve(fileName);
        Path temporary = directory.resolve(fileName + ".tmp");
        List<String> lines = new ArrayList<>();
        for (String[] row : rows) {
            StringBuilder line = new StringBuilder();
            for (int i = 0; i < row.length; i++) {
                if (i > 0) {
                    line.append('|');
                }
                line.append(Base64.getUrlEncoder().withoutPadding()
                        .encodeToString(row[i].getBytes(StandardCharsets.UTF_8)));
            }
            lines.add(line.toString());
        }
        Files.write(temporary, lines, StandardCharsets.UTF_8);
        try {
            Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException exception) {
            Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
