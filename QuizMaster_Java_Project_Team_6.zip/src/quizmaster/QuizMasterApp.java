package quizmaster;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import quizmaster.controller.AppController;
import quizmaster.util.Theme;

public final class QuizMasterApp {
    private QuizMasterApp() {
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception exception) {
                System.err.println("Could not apply system look and feel: " + exception.getMessage());
            }
            Theme.configureDefaults();
            new AppController().start();
        });
    }
}
