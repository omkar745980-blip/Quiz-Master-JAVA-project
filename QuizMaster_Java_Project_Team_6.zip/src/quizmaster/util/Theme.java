package quizmaster.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeListener;
import javax.swing.UIManager;

public final class Theme {
    public static final Color BACKGROUND = new Color(15, 20, 39);
    public static final Color SURFACE = new Color(25, 32, 57);
    public static final Color SURFACE_LIGHT = new Color(35, 44, 75);
    public static final Color PURPLE = new Color(139, 92, 246);
    public static final Color PURPLE_DARK = new Color(112, 67, 220);
    public static final Color TEXT = new Color(239, 242, 255);
    public static final Color MUTED = new Color(163, 172, 199);
    public static final Color SUCCESS = new Color(74, 222, 128);
    public static final Color DANGER = new Color(248, 113, 113);
    public static final Color DIALOG_BACKGROUND = new Color(0x19, 0x1F, 0x38);
    public static final Color DIALOG_BUTTON = new Color(0x75, 0x45, 0xD6);
    public static final Color DIALOG_BUTTON_HOVER = new Color(0x91, 0x65, 0xF5);
    public static final Color DIALOG_BUTTON_PRESSED = new Color(0x59, 0x30, 0xB5);
    private static final String DIALOG_BUTTON_STYLED = "quizmaster.dialogButtonStyled";
    private static final Border DIALOG_BUTTON_BORDER = new CompoundBorder(
            new LineBorder(new Color(0xA9, 0x8B, 0xF5), 1, true),
            new EmptyBorder(6, 14, 6, 14));
    public static final Font BODY = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font LABEL = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font TITLE = new Font("Segoe UI", Font.BOLD, 28);

    private Theme() {
    }

    public static JButton button(String text, boolean primary) {
        JButton button = new JButton(text);
        button.setFont(LABEL);
        button.setForeground(TEXT);
        button.setBackground(primary ? PURPLE : SURFACE_LIGHT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        return button;
    }

    public static void configureDefaults() {
        UIManager.put("OptionPane.background", DIALOG_BACKGROUND);
        UIManager.put("OptionPane.foreground", Color.WHITE);
        UIManager.put("OptionPane.messageForeground", Color.WHITE);
        UIManager.put("OptionPane.buttonFont", LABEL);
        UIManager.put("OptionPane.buttonBackground", DIALOG_BUTTON);
        UIManager.put("OptionPane.buttonForeground", Color.WHITE);
        UIManager.put("OptionPane.buttonMargin", new Insets(6, 14, 6, 14));
        UIManager.put("Panel.background", SURFACE);
        UIManager.put("Button.background", SURFACE_LIGHT);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("Button.font", LABEL);
        UIManager.put("TextField.background", SURFACE_LIGHT);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("TextField.caretForeground", TEXT);
        UIManager.put("PasswordField.background", SURFACE_LIGHT);
        UIManager.put("PasswordField.foreground", TEXT);
        UIManager.put("PasswordField.caretForeground", TEXT);
    }

    public static void showMessageDialog(Component parent, Object message) {
        showMessageDialog(parent, message, "Message", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showMessageDialog(Component parent, Object message, String title, int messageType) {
        JOptionPane pane = new JOptionPane(message, messageType);
        showDialog(parent, pane, title);
    }

    public static int showConfirmDialog(Component parent, Object message, String title, int optionType) {
        return showConfirmDialog(parent, message, title, optionType, JOptionPane.QUESTION_MESSAGE);
    }

    public static int showConfirmDialog(Component parent, Object message, String title,
                                        int optionType, int messageType) {
        JOptionPane pane = new JOptionPane(message, messageType, optionType);
        showDialog(parent, pane, title);
        Object value = pane.getValue();
        return value instanceof Integer ? (Integer) value : JOptionPane.CLOSED_OPTION;
    }

    public static int showOptionDialog(Component parent, Object message, String title,
                                       int optionType, int messageType, Icon icon,
                                       Object[] options, Object initialValue) {
        JOptionPane pane = new JOptionPane(message, messageType, optionType, icon, options, initialValue);
        showDialog(parent, pane, title);
        Object value = pane.getValue();
        if (value == null || value == JOptionPane.UNINITIALIZED_VALUE) {
            return JOptionPane.CLOSED_OPTION;
        }
        if (options == null) {
            return value instanceof Integer ? (Integer) value : JOptionPane.CLOSED_OPTION;
        }
        for (int i = 0; i < options.length; i++) {
            if (value.equals(options[i])) {
                return i;
            }
        }
        return JOptionPane.CLOSED_OPTION;
    }

    public static String showInputDialog(Component parent, Object message) {
        JOptionPane pane = new JOptionPane(message, JOptionPane.QUESTION_MESSAGE,
                JOptionPane.OK_CANCEL_OPTION);
        pane.setWantsInput(true);
        showDialog(parent, pane, "Input");
        Object value = pane.getInputValue();
        return value == JOptionPane.UNINITIALIZED_VALUE || value == null ? null : value.toString();
    }

    public static String showInputDialog(Component parent, Object message, String initialValue) {
        JOptionPane pane = new JOptionPane(message, JOptionPane.QUESTION_MESSAGE,
                JOptionPane.OK_CANCEL_OPTION);
        pane.setWantsInput(true);
        pane.setInitialSelectionValue(initialValue);
        showDialog(parent, pane, "Input");
        Object value = pane.getInputValue();
        return value == JOptionPane.UNINITIALIZED_VALUE || value == null ? null : value.toString();
    }

    public static Object showInputDialog(Component parent, Object message, String title, int messageType,
                                         Icon icon, Object[] selectionValues, Object initialSelectionValue) {
        JOptionPane pane = new JOptionPane(message, messageType, JOptionPane.OK_CANCEL_OPTION,
                icon, new Object[]{JOptionPane.OK_OPTION, JOptionPane.CANCEL_OPTION},
                JOptionPane.OK_OPTION);
        pane.setWantsInput(true);
        pane.setSelectionValues(selectionValues);
        pane.setInitialSelectionValue(initialSelectionValue);
        showDialog(parent, pane, title);
        Object value = pane.getInputValue();
        return value == JOptionPane.UNINITIALIZED_VALUE ? null : value;
    }

    public static void styleDialogButtons(Container container) {
        for (Component component : container.getComponents()) {
            if (component instanceof JButton button) {
                styleDialogButton(button);
            }
            if (component instanceof Container child) {
                styleDialogButtons(child);
            }
        }
    }

    private static void styleDialogContents(Container container) {
        for (Component component : container.getComponents()) {
            if (component instanceof JLabel label) {
                label.setForeground(Color.WHITE);
            } else if (component instanceof JPanel panel) {
                panel.setBackground(DIALOG_BACKGROUND);
            }
            if (component instanceof JButton button) {
                styleDialogButton(button);
            }
            if (component instanceof Container child) {
                styleDialogContents(child);
            }
        }
    }

    public static void styleDialogButton(JButton button) {
        if (Boolean.TRUE.equals(button.getClientProperty(DIALOG_BUTTON_STYLED))) {
            return;
        }
        button.putClientProperty(DIALOG_BUTTON_STYLED, Boolean.TRUE);
        button.setUI(new BasicButtonUI());
        button.setFont(LABEL);
        button.setForeground(Color.WHITE);
        button.setBackground(DIALOG_BUTTON);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(true);
        button.setBorder(DIALOG_BUTTON_BORDER);
        button.setFocusPainted(false);
        button.setRolloverEnabled(true);
        button.setMargin(new Insets(6, 14, 6, 14));

        ChangeListener stateListener = event -> {
            var model = button.getModel();
            button.setBackground(model.isPressed() && model.isArmed() ? DIALOG_BUTTON_PRESSED
                    : model.isRollover() ? DIALOG_BUTTON_HOVER : DIALOG_BUTTON);
        };
        button.getModel().addChangeListener(stateListener);
        button.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent event) {
                button.setBorder(new CompoundBorder(new LineBorder(Color.WHITE, 2, true),
                        new EmptyBorder(5, 13, 5, 13)));
            }

            @Override
            public void focusLost(FocusEvent event) {
                button.setBorder(DIALOG_BUTTON_BORDER);
            }
        });
    }

    private static void showDialog(Component parent, JOptionPane pane, String title) {
        pane.setBackground(DIALOG_BACKGROUND);
        pane.setForeground(Color.WHITE);
        JDialog dialog = pane.createDialog(parent, title);
        dialog.getContentPane().setBackground(DIALOG_BACKGROUND);
        dialog.pack();
        styleDialogContents(dialog.getContentPane());
        dialog.setLocationRelativeTo(parent);
        dialog.setVisible(true);
        dialog.dispose();
    }
}
