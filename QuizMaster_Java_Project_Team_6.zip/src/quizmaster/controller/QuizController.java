package quizmaster.controller;

import java.io.IOException;
import quizmaster.exception.TimeUpException;
import quizmaster.model.QuizSession;
import quizmaster.model.ScoreRecord;
import quizmaster.model.User;
import quizmaster.service.QuizService;

public final class QuizController {
    private final QuizService service;
    private final User user;
    private final QuizSession session;

    public QuizController(QuizService service, User user, String category, boolean practice) throws IOException {
        this.service = service;
        this.user = user;
        this.session = service.start(category, practice);
    }

    public QuizController(QuizService service, User user, String category, boolean practice,
                          int questionCount) throws IOException {
        this.service = service;
        this.user = user;
        this.session = service.start(category, practice, questionCount);
    }

    public QuizSession getSession() {
        return session;
    }

    public void selectAnswer(int answer) throws TimeUpException {
        session.selectAnswer(answer);
    }

    public void goTo(int index) throws TimeUpException {
        session.goTo(index);
    }

    public ScoreRecord submit() throws IOException {
        return service.submit(session, user);
    }
}
