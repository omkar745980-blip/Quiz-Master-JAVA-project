package quizmaster.controller;

import java.io.IOException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JWindow;
import javax.swing.SwingWorker;
import java.util.concurrent.ExecutionException;
import quizmaster.model.User;
import quizmaster.service.AuthService;
import quizmaster.service.DatabaseConnection;
import quizmaster.service.QuestionService;
import quizmaster.service.ScoreService;
import quizmaster.service.SettingsService;
import quizmaster.util.Theme;
import quizmaster.view.LoginFrame;
import quizmaster.view.MainFrame;

public final class AppController {
    private DatabaseConnection database;
    private AuthService authService;
    private QuestionService questionService;
    private ScoreService scoreService;
    private SettingsService settingsService;
    private LoginFrame loginFrame;

    public void start() {
        JWindow loading = createLoadingScreen();
        loading.setVisible(true);
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws IOException {
                database = new DatabaseConnection();
                authService = new AuthService(database);
                questionService = new QuestionService(database);
                scoreService = new ScoreService(database);
                settingsService = new SettingsService(database);
                return null;
            }

            @Override
            protected void done() {
                loading.dispose();
                try {
                    get();
                    showLogin();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    Theme.showMessageDialog(null, "QuizMaster startup was interrupted.",
                            "Startup error", JOptionPane.ERROR_MESSAGE);
                } catch (ExecutionException exception) {
                    Throwable cause = exception.getCause();
                    String message = cause instanceof IOException ? cause.getMessage()
                            : "An unexpected startup error occurred: " + cause.getMessage();
                    Theme.showMessageDialog(null,
                            "QuizMaster could not open its SQLite database.\n" + message,
                            "Startup error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void showLogin() {
        loginFrame = new LoginFrame(authService, this::showMain);
        loginFrame.setVisible(true);
    }

    private void showMain(User user) {
        if (loginFrame != null) {
            loginFrame.dispose();
        }
        MainFrame frame = new MainFrame(user, questionService, scoreService, authService,
                settingsService, this::showLogin);
        frame.setVisible(true);
    }

    private JWindow createLoadingScreen() {
        JWindow window = new JWindow();
        JLabel label = new JLabel("◆  QUIZMASTER     Loading your learning workspace…", JLabel.CENTER);
        label.setOpaque(true);
        label.setBackground(Theme.SURFACE);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Segoe UI", Font.BOLD, 18));
        window.getContentPane().setBackground(Theme.BACKGROUND);
        window.getContentPane().add(label, BorderLayout.CENTER);
        window.setSize(520, 160);
        window.setLocationRelativeTo(null);
        return window;
    }
}
