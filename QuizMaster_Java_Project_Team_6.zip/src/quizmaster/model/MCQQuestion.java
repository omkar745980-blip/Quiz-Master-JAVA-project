package quizmaster.model;

import java.util.List;

public final class MCQQuestion extends Question {
    public MCQQuestion(String category, String prompt, List<String> options, int correctAnswer) {
        super(category, prompt, options, correctAnswer);
    }

    public MCQQuestion(String id, String category, String prompt, List<String> options, int correctAnswer) {
        super(id, category, prompt, options, correctAnswer);
    }

    public MCQQuestion(String category, String prompt, List<String> options, int correctAnswer,
                       String difficulty, String explanation) {
        super(category, prompt, options, correctAnswer, difficulty, explanation);
    }

    public MCQQuestion(String id, String category, String prompt, List<String> options, int correctAnswer,
                       String difficulty, String explanation) {
        super(id, category, prompt, options, correctAnswer, difficulty, explanation);
    }

    @Override
    public String getType() {
        return MCQ_TYPE;
    }

    @Override
    public int getOptionCount() {
        return 4;
    }

    @Override
    public boolean isCorrectAnswer(int selectedAnswer) {
        return isValidAnswer(selectedAnswer) && selectedAnswer == getCorrectAnswer();
    }

    @Override
    public MCQQuestion withCategory(String category) {
        return new MCQQuestion(getId(), category, getPrompt(), getOptions(), getCorrectAnswer(),
                getDifficulty(), getExplanation());
    }
}
