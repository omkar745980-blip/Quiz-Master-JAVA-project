package quizmaster.model;

public final class User {
    public enum Role {
        STUDENT, ADMIN
    }

    private final String username;
    private final String salt;
    private final String passwordHash;
    private final Role role;
    private final String displayName;

    public User(String username, String salt, String passwordHash, Role role) {
        this(username, salt, passwordHash, role, username);
    }

    public User(String username, String salt, String passwordHash, Role role, String displayName) {
        this.username = username;
        this.salt = salt;
        this.passwordHash = passwordHash;
        this.role = role;
        this.displayName = displayName == null || displayName.trim().isEmpty() ? username : displayName.trim();
    }

    public String getUsername() {
        return username;
    }

    public String getSalt() {
        return salt;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public Role getRole() {
        return role;
    }

    public String getDisplayName() {
        return displayName;
    }
}
