package quizmaster.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public abstract class Question {
    public static final String MCQ_TYPE = "MCQ";
    public static final String TRUE_FALSE_TYPE = "TRUE_FALSE";

    private final String id;
    private final String category;
    private final String prompt;
    private final List<String> options;
    private final int correctAnswer;
    private final String difficulty;
    private final String explanation;

    public Question(String category, String prompt, List<String> options, int correctAnswer) {
        this(UUID.randomUUID().toString(), category, prompt, options, correctAnswer,
                "Medium", "Explanation not available for this question.");
    }

    public Question(String id, String category, String prompt, List<String> options, int correctAnswer) {
        this(id, category, prompt, options, correctAnswer,
                "Medium", "Explanation not available for this question.");
    }

    public Question(String category, String prompt, List<String> options, int correctAnswer,
                    String difficulty, String explanation) {
        this(UUID.randomUUID().toString(), category, prompt, options, correctAnswer, difficulty, explanation);
    }

    public Question(String id, String category, String prompt, List<String> options, int correctAnswer,
                    String difficulty, String explanation) {
        if (options == null || options.size() != 4) {
            throw new IllegalArgumentException("A question must have exactly four stored options.");
        }
        if (correctAnswer < 0 || correctAnswer > 3) {
            throw new IllegalArgumentException("The correct answer must be between 1 and 4.");
        }
        if (difficulty == null || !List.of("Easy", "Medium", "Hard").contains(difficulty.trim())) {
            throw new IllegalArgumentException("Difficulty must be Easy, Medium, or Hard.");
        }
        if (explanation == null || explanation.trim().isEmpty()) {
            throw new IllegalArgumentException("A short explanation is required.");
        }
        this.id = id;
        this.category = category.trim();
        this.prompt = prompt.trim();
        this.options = Collections.unmodifiableList(new ArrayList<>(options));
        this.correctAnswer = correctAnswer;
        this.difficulty = difficulty.trim();
        this.explanation = explanation.trim();
    }

    public static Question fromType(String type, String id, String category, String prompt,
                                    List<String> options, int correctAnswer, String difficulty,
                                    String explanation) {
        if (MCQ_TYPE.equals(type)) {
            return new MCQQuestion(id, category, prompt, options, correctAnswer, difficulty, explanation);
        }
        if (TRUE_FALSE_TYPE.equals(type)) {
            return new TrueFalseQuestion(id, category, prompt, options, correctAnswer, difficulty, explanation);
        }
        throw new IllegalArgumentException("Unknown question type: " + type);
    }

    public abstract String getType();

    public abstract int getOptionCount();

    public abstract boolean isCorrectAnswer(int selectedAnswer);

    public abstract Question withCategory(String category);

    public boolean isValidAnswer(int selectedAnswer) {
        return selectedAnswer >= 0 && selectedAnswer < getOptionCount();
    }

    public String getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getPrompt() {
        return prompt;
    }

    public List<String> getOptions() {
        return options;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public String getExplanation() {
        return explanation;
    }
}
