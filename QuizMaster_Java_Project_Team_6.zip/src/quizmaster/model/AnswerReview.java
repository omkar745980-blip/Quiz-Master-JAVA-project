package quizmaster.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class AnswerReview {
    private final String prompt;
    private final List<String> options;
    private final int correctAnswer;
    private final Integer selectedAnswer;
    private final String explanation;
    private final String difficulty;

    public AnswerReview(String prompt, List<String> options, int correctAnswer, Integer selectedAnswer,
                        String explanation, String difficulty) {
        this.prompt = prompt;
        this.options = Collections.unmodifiableList(new ArrayList<>(options));
        this.correctAnswer = correctAnswer;
        this.selectedAnswer = selectedAnswer;
        this.explanation = explanation;
        this.difficulty = difficulty;
    }

    public String getPrompt() { return prompt; }
    public List<String> getOptions() { return options; }
    public int getCorrectAnswer() { return correctAnswer; }
    public Integer getSelectedAnswer() { return selectedAnswer; }
    public String getExplanation() { return explanation; }
    public String getDifficulty() { return difficulty; }
}
