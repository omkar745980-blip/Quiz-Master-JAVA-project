package quizmaster.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public final class ScoreRecord {
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("MMM d, yyyy  HH:mm");

    private final String id;
    private final String username;
    private final String category;
    private final int score;
    private final int total;
    private final boolean practice;
    private final LocalDateTime completedAt;
    private final int durationSeconds;
    private final List<AnswerReview> answerReviews;

    public ScoreRecord(String username, String category, int score, int total, boolean practice) {
        this(UUID.randomUUID().toString(), username, category, score, total, practice, LocalDateTime.now(),
                0, Collections.emptyList());
    }

    public ScoreRecord(String id, String username, String category, int score, int total,
                       boolean practice, LocalDateTime completedAt) {
        this(id, username, category, score, total, practice, completedAt, 0, Collections.emptyList());
    }

    public ScoreRecord(String username, String category, int score, int total, boolean practice,
                       int durationSeconds, List<AnswerReview> answerReviews) {
        this(UUID.randomUUID().toString(), username, category, score, total, practice, LocalDateTime.now(),
                durationSeconds, answerReviews);
    }

    public ScoreRecord(String id, String username, String category, int score, int total,
                       boolean practice, LocalDateTime completedAt, int durationSeconds,
                       List<AnswerReview> answerReviews) {
        this.id = id;
        this.username = username;
        this.category = category;
        this.score = score;
        this.total = total;
        this.practice = practice;
        this.completedAt = completedAt;
        this.durationSeconds = Math.max(0, durationSeconds);
        this.answerReviews = Collections.unmodifiableList(new ArrayList<>(answerReviews));
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getCategory() {
        return category;
    }

    public int getScore() {
        return score;
    }

    public int getTotal() {
        return total;
    }

    public boolean isPractice() {
        return practice;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public String getDisplayDate() {
        return completedAt.format(DISPLAY_DATE);
    }

    public int getPercentage() {
        return total == 0 ? 0 : (score * 100) / total;
    }

    public int getCorrectCount() { return score; }
    public int getIncorrectCount() {
        return answerReviews.isEmpty() ? Math.max(0, total - score)
                : Math.max(0, answerReviews.size() - score - getUnansweredCount());
    }
    public int getUnansweredCount() {
        if (answerReviews.isEmpty()) {
            return 0;
        }
        return (int) answerReviews.stream().filter(answer -> answer.getSelectedAnswer() == null).count();
    }
    public int getDurationSeconds() { return durationSeconds; }
    public List<AnswerReview> getAnswerReviews() { return answerReviews; }
}
