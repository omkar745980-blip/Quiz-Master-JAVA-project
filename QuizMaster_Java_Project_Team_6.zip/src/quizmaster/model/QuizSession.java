package quizmaster.model;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;
import quizmaster.exception.TimeUpException;

public final class QuizSession {
    private final List<Question> questions;
    private final Integer[] answers;
    private final boolean[] markedForReview;
    private final boolean practice;
    private final int durationSeconds;
    private final Instant startedAt;
    private int currentIndex;
    private boolean submitted;

    public QuizSession(List<Question> questions, boolean practice, int durationSeconds) {
        this.questions = Collections.unmodifiableList(new ArrayList<>(questions));
        this.answers = new Integer[questions.size()];
        this.markedForReview = new boolean[questions.size()];
        this.practice = practice;
        this.durationSeconds = durationSeconds;
        this.startedAt = Instant.now();
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public Question getCurrentQuestion() {
        return questions.get(currentIndex);
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public int getQuestionCount() {
        return questions.size();
    }

    public Integer getAnswer(int index) {
        return answers[index];
    }

    public Integer getCurrentAnswer() {
        return answers[currentIndex];
    }

    public boolean isMarkedForReview(int index) {
        return markedForReview[index];
    }

    public void toggleReview(int index) {
        if (index < 0 || index >= markedForReview.length) {
            throw new IndexOutOfBoundsException("Question number is out of range.");
        }
        markedForReview[index] = !markedForReview[index];
    }

    public int countAnswered() {
        int count = 0;
        for (Integer answer : answers) {
            if (answer != null) {
                count++;
            }
        }
        return count;
    }

    public int countUnanswered() {
        return answers.length - countAnswered();
    }

    public int countIncorrectAnswers() {
        return countAnswered() - countCorrectAnswers();
    }

    public Integer[] getAnswers() {
        return Arrays.copyOf(answers, answers.length);
    }

    public long elapsedSeconds() {
        return Math.max(0, Duration.between(startedAt, Instant.now()).getSeconds());
    }

    public boolean isPractice() {
        return practice;
    }

    public boolean isSubmitted() {
        return submitted;
    }

    public boolean isExpired() {
        return !practice && remainingSeconds() == 0;
    }

    public int remainingSeconds() {
        if (practice) {
            return 0;
        }
        long elapsed = Duration.between(startedAt, Instant.now()).getSeconds();
        return (int) Math.max(0, durationSeconds - elapsed);
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public void selectAnswer(int answer) throws TimeUpException {
        ensureActive();
        if (!questions.get(currentIndex).isValidAnswer(answer)) {
            throw new IllegalArgumentException("Select one of the available answer options.");
        }
        answers[currentIndex] = answer;
    }

    public void goTo(int index) throws TimeUpException {
        ensureActive();
        if (index < 0 || index >= questions.size()) {
            throw new IndexOutOfBoundsException("Question number is out of range.");
        }
        currentIndex = index;
    }

    public int countCorrectAnswers() {
        int correct = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (answers[i] != null && questions.get(i).isCorrectAnswer(answers[i])) {
                correct++;
            }
        }
        return correct;
    }

    public void markSubmitted() {
        submitted = true;
    }

    private void ensureActive() throws TimeUpException {
        if (submitted) {
            throw new IllegalStateException("This quiz has already been submitted.");
        }
        if (isExpired()) {
            throw new TimeUpException("Time is up. Your quiz is being submitted.");
        }
    }
}
