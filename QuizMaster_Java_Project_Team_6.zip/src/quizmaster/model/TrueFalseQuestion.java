package quizmaster.model;

import java.util.List;

public final class TrueFalseQuestion extends Question {
    private static final List<String> OPTIONS = List.of("True", "False", "", "");

    public TrueFalseQuestion(String category, String prompt, int correctAnswer) {
        this(category, prompt, correctAnswer, "Medium",
                "Explanation not available for this question.");
    }

    public TrueFalseQuestion(String id, String category, String prompt, int correctAnswer) {
        this(id, category, prompt, correctAnswer, "Medium",
                "Explanation not available for this question.");
    }

    public TrueFalseQuestion(String category, String prompt, int correctAnswer,
                             String difficulty, String explanation) {
        this(java.util.UUID.randomUUID().toString(), category, prompt, correctAnswer, difficulty, explanation);
    }

    public TrueFalseQuestion(String id, String category, String prompt, int correctAnswer,
                             String difficulty, String explanation) {
        super(id, category, prompt, OPTIONS, validateAnswer(correctAnswer), difficulty, explanation);
    }

    public TrueFalseQuestion(String id, String category, String prompt, List<String> options,
                             int correctAnswer, String difficulty, String explanation) {
        super(id, category, prompt, validateOptions(options), validateAnswer(correctAnswer),
                difficulty, explanation);
    }

    private static int validateAnswer(int correctAnswer) {
        if (correctAnswer < 0 || correctAnswer > 1) {
            throw new IllegalArgumentException("A true/false answer must be True (0) or False (1).");
        }
        return correctAnswer;
    }

    private static List<String> validateOptions(List<String> options) {
        if (!OPTIONS.equals(options)) {
            throw new IllegalArgumentException("A true/false question must store True and False options.");
        }
        return OPTIONS;
    }

    @Override
    public String getType() {
        return TRUE_FALSE_TYPE;
    }

    @Override
    public int getOptionCount() {
        return 2;
    }

    @Override
    public boolean isCorrectAnswer(int selectedAnswer) {
        return isValidAnswer(selectedAnswer) && selectedAnswer == getCorrectAnswer();
    }

    @Override
    public TrueFalseQuestion withCategory(String category) {
        return new TrueFalseQuestion(getId(), category, getPrompt(), getCorrectAnswer(),
                getDifficulty(), getExplanation());
    }
}
