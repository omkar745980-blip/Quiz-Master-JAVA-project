package quizmaster.exception;

@SuppressWarnings("serial")
public class TimeUpException extends Exception {
    public TimeUpException(String message) {
        super(message);
    }
}
