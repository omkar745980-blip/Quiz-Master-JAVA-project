package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class AboutPanel extends JPanel {
    public AboutPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        JPanel content = new JPanel(new BorderLayout(0, 18));
        content.setBackground(Theme.SURFACE);
        content.setBorder(BorderFactory.createEmptyBorder(36, 42, 36, 42));
        JLabel logo = new JLabel("◆  QUIZMASTER", SwingConstants.CENTER);
        logo.setForeground(Theme.PURPLE);
        logo.setFont(new Font("Segoe UI", Font.BOLD, 30));
        content.add(logo, BorderLayout.NORTH);
        JLabel details = new JLabel("<html><div style='text-align:center'>"
                + "<h2>Smart Quiz &amp; Exam Practice</h2>"
                + "<p>A focused desktop learning platform built with Java Swing.</p>"
                + "<p>Practice, timed exams, progress analytics, and local history.</p>"
                + "<p>Your accounts and activity are stored locally on this computer.</p>"
                + "</div></html>", SwingConstants.CENTER);
        details.setForeground(Theme.TEXT);
        details.setFont(Theme.BODY);
        content.add(details, BorderLayout.CENTER);
        add(content, BorderLayout.CENTER);
    }
}
