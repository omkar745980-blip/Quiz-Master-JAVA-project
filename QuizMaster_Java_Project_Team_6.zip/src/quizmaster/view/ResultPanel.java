package quizmaster.view;

import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import quizmaster.model.ScoreRecord;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class ResultPanel extends JPanel {
    public ResultPanel(ScoreRecord score, Runnable onHistory, Runnable onHome) {
        this(score, onHistory, onHome, () -> { });
    }

    public ResultPanel(ScoreRecord score, Runnable onHistory, Runnable onHome, Runnable onReview) {
        setLayout(new BorderLayout());
        setBackground(Theme.BACKGROUND);
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.SURFACE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(49, 59, 91)),
                BorderFactory.createEmptyBorder(38, 54, 38, 54)));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.insets = new Insets(0, 0, 12, 0);
        JLabel eyebrow = label("QUIZ COMPLETE", Theme.PURPLE, new Font("Segoe UI", Font.BOLD, 12));
        eyebrow.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(eyebrow, c);
        c.gridy++;
        JLabel title = label(score.getPercentage() >= 70 ? "Excellent work!" : "Keep building momentum.",
                Theme.TEXT, new Font("Segoe UI", Font.BOLD, 27));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(title, c);
        c.gridy++;
        JLabel scoreText = label(score.getScore() + " / " + score.getTotal(),
                Theme.PURPLE, new Font("Segoe UI", Font.BOLD, 54));
        scoreText.setHorizontalAlignment(SwingConstants.CENTER);
        c.insets = new Insets(18, 0, 4, 0);
        card.add(scoreText, c);
        c.gridy++;
        JLabel percentage = label(score.getPercentage() + "% correct", Theme.MUTED, Theme.BODY);
        percentage.setHorizontalAlignment(SwingConstants.CENTER);
        c.insets = new Insets(0, 0, 20, 0);
        card.add(percentage, c);
        c.gridy++;
        JLabel counts = label("Correct " + score.getCorrectCount() + "   ·   Incorrect "
                        + score.getIncorrectCount() + "   ·   Unanswered " + score.getUnansweredCount(),
                Theme.TEXT, Theme.BODY);
        counts.setHorizontalAlignment(SwingConstants.CENTER);
        c.insets = new Insets(0, 0, 12, 0);
        card.add(counts, c);
        c.gridy++;
        JLabel elapsed = label("Time taken: " + formatDuration(score.getDurationSeconds()),
                Theme.MUTED, Theme.BODY);
        elapsed.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(elapsed, c);
        c.gridy++;
        PerformanceChart chart = new PerformanceChart();
        Map<String, Integer> breakdown = new LinkedHashMap<>();
        if (score.getTotal() > 0) {
            breakdown.put("Correct", score.getCorrectCount() * 100 / score.getTotal());
            breakdown.put("Incorrect", score.getIncorrectCount() * 100 / score.getTotal());
            breakdown.put("Unanswered", score.getUnansweredCount() * 100 / score.getTotal());
        }
        chart.setValues(breakdown);
        card.add(chart, c);
        c.gridy++;
        String mode = score.isPractice() ? "Practice session" : "Timed exam";
        JLabel detail = label(score.getCategory() + "  ·  " + mode + "  ·  " + score.getDisplayDate(),
                Theme.MUTED, new Font("Segoe UI", Font.PLAIN, 12));
        detail.setHorizontalAlignment(SwingConstants.CENTER);
        c.insets = new Insets(0, 0, 24, 0);
        card.add(detail, c);
        c.gridy++;
        JPanel buttons = new JPanel(new java.awt.GridLayout(1, 3, 10, 0));
        buttons.setOpaque(false);
        JButton review = Theme.button("Review answers", false);
        review.addActionListener(event -> onReview.run());
        JButton history = Theme.button("View score history", false);
        history.addActionListener(event -> onHistory.run());
        JButton home = Theme.button("Back to dashboard", true);
        home.addActionListener(event -> onHome.run());
        buttons.add(review);
        buttons.add(history);
        buttons.add(home);
        card.add(buttons, c);
        JScrollPane scroll = new JScrollPane(card);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Theme.BACKGROUND);
        add(scroll, BorderLayout.CENTER);
    }

    private String formatDuration(int seconds) {
        return String.format("%d min %02d sec", seconds / 60, seconds % 60);
    }

    private JLabel label(String text, Color color, Font font) {
        JLabel label = new JLabel(text);
        label.setForeground(color);
        label.setFont(font);
        return label;
    }
}
