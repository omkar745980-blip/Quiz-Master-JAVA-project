package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.GridLayout;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.ButtonGroup;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.KeyStroke;
import quizmaster.controller.QuizController;
import quizmaster.exception.TimeUpException;
import quizmaster.model.Question;
import quizmaster.model.QuizSession;
import quizmaster.model.ScoreRecord;
import quizmaster.service.QuizTimerThread;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class ExamPanel extends JPanel {
    private final QuizController controller;
    private final Consumer<ScoreRecord> onComplete;
    private final QuizSession session;
    private final JRadioButton[] choices = new JRadioButton[4];
    private final ButtonGroup choiceGroup = new ButtonGroup();
    private final JLabel timerLabel = new JLabel();
    private final JLabel questionLabel = new JLabel();
    private final JLabel progressLabel = new JLabel();
    private final JLabel questionNumber = new JLabel();
    private final JLabel explanationLabel = new JLabel();
    private final JLabel answerStatusLabel = new JLabel();
    private final JButton reviewToggle = Theme.button("☆ Mark for review", false);
    private final JButton[] paletteButtons;
    private final JPanel optionList = new JPanel(new GridLayout(0, 1, 0, 12));
    private final QuizTimerThread timerThread;
    private final AtomicBoolean finished = new AtomicBoolean();
    private final AtomicBoolean fiveMinuteWarningShown = new AtomicBoolean();
    private final boolean showTimeWarning;

    public ExamPanel(QuizController controller, Consumer<ScoreRecord> onComplete) {
        this(controller, onComplete, true);
    }

    public ExamPanel(QuizController controller, Consumer<ScoreRecord> onComplete,
                     boolean showTimeWarning) {
        this.controller = controller;
        this.onComplete = onComplete;
        this.showTimeWarning = showTimeWarning;
        this.session = controller.getSession();
        this.paletteButtons = new JButton[session.getQuestionCount()];
        this.timerThread = session.isPractice() ? null
                : new QuizTimerThread(session, this::updateTimer, this::finish);
        setLayout(new BorderLayout(20, 18));
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(26, 38, 30, 38));
        build();
        renderQuestion();
        if (timerThread != null) {
            timerThread.startOnce();
        }
    }

    private void build() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JPanel left = new JPanel(new GridLayout(0, 1, 0, 6));
        left.setOpaque(false);
        JLabel brand = new JLabel("QUIZMASTER  /  " + session.getCurrentQuestion().getCategory().toUpperCase());
        brand.setForeground(Theme.PURPLE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 12));
        left.add(brand);
        progressLabel.setForeground(Theme.MUTED);
        progressLabel.setFont(Theme.BODY);
        left.add(progressLabel);
        header.add(left, BorderLayout.WEST);
        timerLabel.setForeground(Theme.TEXT);
        timerLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        header.add(timerLabel, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        JPanel questionCard = new JPanel(new BorderLayout(0, 22));
        questionCard.setBackground(Theme.SURFACE);
        questionCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(49, 59, 91)),
                BorderFactory.createEmptyBorder(30, 34, 30, 34)));
        questionNumber.setForeground(Theme.PURPLE);
        questionNumber.setFont(new Font("Segoe UI", Font.BOLD, 13));
        questionCard.add(questionNumber, BorderLayout.NORTH);
        JPanel center = new JPanel(new BorderLayout(0, 22));
        center.setOpaque(false);
        questionLabel.setForeground(Theme.TEXT);
        questionLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        questionLabel.setVerticalAlignment(SwingConstants.TOP);
        center.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent event) {
                updateQuestionPrompt(session.getCurrentQuestion());
            }
        });
        center.add(questionLabel, BorderLayout.NORTH);
        optionList.setOpaque(false);
        for (int i = 0; i < choices.length; i++) {
            final int answer = i;
            JRadioButton option = new JRadioButton();
            option.setForeground(Theme.TEXT);
            option.setBackground(Theme.SURFACE_LIGHT);
            option.setFont(Theme.BODY);
            option.setBorder(BorderFactory.createEmptyBorder(11, 14, 11, 14));
            option.setFocusPainted(false);
            option.addActionListener(event -> select(answer));
            choices[i] = option;
            choiceGroup.add(option);
        }
        center.add(optionList, BorderLayout.CENTER);
        explanationLabel.setForeground(Theme.MUTED);
        explanationLabel.setFont(Theme.BODY);
        center.add(explanationLabel, BorderLayout.SOUTH);
        questionCard.add(center, BorderLayout.CENTER);
        add(questionCard, BorderLayout.CENTER);
        add(createQuestionPalette(), BorderLayout.EAST);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        JLabel mode = new JLabel(session.isPractice() ? "PRACTICE MODE  ·  NO TIMER" : "TIMED EXAM  ·  10 MINUTES");
        mode.setForeground(Theme.MUTED);
        mode.setFont(new Font("Segoe UI", Font.BOLD, 11));
        footer.add(mode, BorderLayout.WEST);
        JPanel nav = new JPanel(new GridLayout(1, 4, 8, 0));
        nav.setOpaque(false);
        var previous = Theme.button("← Previous", false);
        previous.addActionListener(event -> navigate(-1));
        var next = Theme.button("Next →", true);
        next.addActionListener(event -> navigate(1));
        var submit = Theme.button("Submit quiz", false);
        submit.addActionListener(event -> confirmSubmit());
        reviewToggle.addActionListener(event -> toggleReview());
        nav.add(previous);
        nav.add(next);
        nav.add(reviewToggle);
        nav.add(submit);
        footer.add(nav, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);
        installKeyboardShortcuts();
    }

    private JPanel createQuestionPalette() {
        JPanel palette = new JPanel(new BorderLayout(0, 10));
        palette.setBackground(Theme.SURFACE);
        palette.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(49, 59, 91)),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));
        palette.setPreferredSize(new java.awt.Dimension(176, 0));
        JLabel title = new JLabel("QUESTION MAP", SwingConstants.CENTER);
        title.setForeground(Theme.TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 12));
        palette.add(title, BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(0, 4, 5, 5));
        grid.setOpaque(false);
        for (int i = 0; i < paletteButtons.length; i++) {
            final int questionIndex = i;
            JButton button = new JButton(Integer.toString(i + 1));
            button.setFont(new Font("Segoe UI", Font.BOLD, 11));
            button.setForeground(Theme.TEXT);
            button.setBackground(Theme.SURFACE_LIGHT);
            button.setOpaque(true);
            button.setFocusPainted(false);
            button.setBorderPainted(false);
            button.setToolTipText("Question " + (i + 1) + " (unanswered)");
            button.addActionListener(event -> {
                saveSelected();
                try {
                    controller.goTo(questionIndex);
                    renderQuestion();
                } catch (TimeUpException exception) {
                    finish();
                }
            });
            paletteButtons[i] = button;
            grid.add(button);
        }
        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        palette.add(scroll, BorderLayout.CENTER);
        JPanel footer = new JPanel(new GridLayout(0, 1, 0, 5));
        footer.setOpaque(false);
        answerStatusLabel.setForeground(Theme.MUTED);
        answerStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        footer.add(answerStatusLabel);
        footer.add(paletteLegend("● Answered", Theme.SUCCESS));
        footer.add(paletteLegend("● Unanswered", Theme.MUTED));
        footer.add(paletteLegend("● Review", new Color(249, 191, 74)));
        palette.add(footer, BorderLayout.SOUTH);
        return palette;
    }

    private JLabel paletteLegend(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setForeground(color);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        return label;
    }

    private void renderQuestion() {
        Question question = session.getCurrentQuestion();
        questionNumber.setText(String.format("QUESTION %02d  ·  %s",
                session.getCurrentIndex() + 1, question.getDifficulty().toUpperCase()));
        updateQuestionPrompt(question);
        progressLabel.setText("Question " + (session.getCurrentIndex() + 1) + " of " + session.getQuestionCount());
        choiceGroup.clearSelection();
        optionList.removeAll();
        for (int i = 0; i < choices.length; i++) {
            if (i < question.getOptionCount()) {
                choices[i].setText("<html><b>" + (char) ('A' + i) + "</b>&nbsp;&nbsp; "
                        + escape(question.getOptions().get(i)) + "</html>");
                choices[i].setSelected(session.getCurrentAnswer() != null && session.getCurrentAnswer() == i);
                optionList.add(choices[i]);
            }
        }
        updateExplanation(question);
        reviewToggle.setText(session.isMarkedForReview(session.getCurrentIndex())
                ? "★ Remove review mark" : "☆ Mark for review");
        refreshPalette();
        revalidate();
        repaint();
    }

    private void refreshPalette() {
        for (int i = 0; i < paletteButtons.length; i++) {
            JButton button = paletteButtons[i];
            boolean answered = session.getAnswer(i) != null;
            boolean review = session.isMarkedForReview(i);
            button.setText((review ? "★ " : "") + (i + 1));
            button.setBackground(i == session.getCurrentIndex() ? Theme.PURPLE
                    : review ? new Color(158, 95, 31)
                    : answered ? new Color(34, 111, 76) : Theme.SURFACE_LIGHT);
            String status = review ? "marked for review" : answered ? "answered" : "unanswered";
            button.setToolTipText("Question " + (i + 1) + " (" + status + ")");
        }
        answerStatusLabel.setText(session.countAnswered() + " answered · "
                + session.countUnanswered() + " unanswered");
    }

    private void updateQuestionPrompt(Question question) {
        int width = questionLabel.getParent() == null ? 640 : questionLabel.getParent().getWidth() - 8;
        if (width <= 0) {
            width = 640;
        }
        questionLabel.setText("<html><div style='width:" + width + "px'>"
                + escape(question.getPrompt()) + "</div></html>");
    }

    private void toggleReview() {
        session.toggleReview(session.getCurrentIndex());
        refreshPalette();
        reviewToggle.setText(session.isMarkedForReview(session.getCurrentIndex())
                ? "★ Remove review mark" : "☆ Mark for review");
    }

    private void installKeyboardShortcuts() {
        InputMap input = getInputMap(WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        ActionMap actions = getActionMap();
        bind(input, actions, KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "previous",
                () -> navigate(-1));
        bind(input, actions, KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "next",
                () -> navigate(1));
        bind(input, actions, KeyStroke.getKeyStroke(KeyEvent.VK_R, 0), "review", this::toggleReview);
        bind(input, actions, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, KeyEvent.CTRL_DOWN_MASK),
                "submit", this::confirmSubmit);
    }

    private void bind(InputMap input, ActionMap actions, KeyStroke key, String name, Runnable callback) {
        input.put(key, name);
        actions.put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent event) {
                callback.run();
            }
        });
    }

    private void updateExplanation(Question question) {
        boolean answeredInPractice = session.isPractice() && session.getCurrentAnswer() != null;
        explanationLabel.setText(answeredInPractice
                ? "<html><b>Explanation:</b> " + escape(question.getExplanation()) + "</html>" : "");
        explanationLabel.setVisible(answeredInPractice);
    }

    private String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private void select(int answer) {
        try {
            controller.selectAnswer(answer);
            updateExplanation(session.getCurrentQuestion());
            refreshPalette();
        } catch (TimeUpException exception) {
            finish();
        }
    }

    private void navigate(int direction) {
        saveSelected();
        int target = session.getCurrentIndex() + direction;
        if (target < 0 || target >= session.getQuestionCount()) {
            return;
        }
        try {
            controller.goTo(target);
            renderQuestion();
        } catch (TimeUpException exception) {
            finish();
        }
    }

    private void saveSelected() {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i].isSelected()) {
                try {
                    controller.selectAnswer(i);
                } catch (TimeUpException exception) {
                    finish();
                }
                return;
            }
        }
    }

    private void confirmSubmit() {
        saveSelected();
        if (finished.get()) {
            return;
        }
        int answer = Theme.showConfirmDialog(this,
                "Submit this quiz?\n\nAnswered: " + session.countAnswered()
                        + "\nUnanswered: " + session.countUnanswered()
                        + "\nMarked for review: " + markedCount(),
                "Finish quiz", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (answer == JOptionPane.YES_OPTION) {
            finish();
        }
    }

    private void updateTimer(int remaining) {
        if (finished.get()) {
            return;
        }
        if (session.isExpired()) {
            finish();
            return;
        }
        if (showTimeWarning && remaining <= 5 * 60
                && fiveMinuteWarningShown.compareAndSet(false, true)) {
            Theme.showMessageDialog(this, "Five minutes remain in your timed exam.",
                    "Time warning", JOptionPane.WARNING_MESSAGE);
        }
        timerLabel.setText(String.format("⏱  %02d:%02d", remaining / 60, remaining % 60));
        timerLabel.setForeground(remaining <= 5 * 60 ? Theme.DANGER : Theme.TEXT);
    }

    private int markedCount() {
        int marked = 0;
        for (int i = 0; i < session.getQuestionCount(); i++) {
            if (session.isMarkedForReview(i)) {
                marked++;
            }
        }
        return marked;
    }

    private void finish() {
        if (!finished.compareAndSet(false, true)) {
            return;
        }
        saveCurrentWithoutExpirationCheck();
        try {
            ScoreRecord score = controller.submit();
            if (timerThread != null) {
                timerThread.cancelTimer();
            }
            onComplete.accept(score);
        } catch (IOException exception) {
            finished.set(false);
            Theme.showMessageDialog(this, "Could not save your score.\n" + exception.getMessage(),
                    "Storage error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveCurrentWithoutExpirationCheck() {
        for (int i = 0; i < choices.length; i++) {
            if (choices[i].isSelected()) {
                try {
                    session.selectAnswer(i);
                } catch (TimeUpException ignored) {
                    return;
                }
                return;
            }
        }
    }

    @Override
    public void removeNotify() {
        if (timerThread != null) {
            timerThread.cancelTimer();
        }
        super.removeNotify();
    }
}
