package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import quizmaster.model.User;
import quizmaster.service.SettingsService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class SettingsPanel extends JPanel {
    private static final Color BACKGROUND = new Color(0x11, 0x16, 0x2B);
    private static final Color CARD = new Color(0x1B, 0x24, 0x40);
    private static final Color INNER = new Color(0x25, 0x2D, 0x49);
    private static final Color PURPLE = new Color(0x75, 0x45, 0xD6);
    private static final Color POPUP_NAVY = new Color(0x19, 0x1F, 0x38);
    private static final Color SECONDARY_TEXT = new Color(0xAA, 0xB5, 0xD1);

    public SettingsPanel(User user, SettingsService settings) {
        setLayout(new BorderLayout(0, 20));
        setBackground(BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(28, 36, 28, 36));

        JLabel heading = new JLabel("Settings");
        heading.setFont(Theme.TITLE);
        heading.setForeground(Color.WHITE);
        heading.setBorder(BorderFactory.createEmptyBorder(0, 0, 18, 0));
        add(heading, BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new javax.swing.BoxLayout(content, javax.swing.BoxLayout.Y_AXIS));
        JComboBox<Integer> count = new JComboBox<>(new Integer[]{10, 20});
        styleDropdown(count);
        JCheckBox notifications = createNotificationsCheckbox();
        content.add(createPreferencesCard(count));
        content.add(javax.swing.Box.createVerticalStrut(16));
        content.add(createNotificationsCard(notifications));
        content.add(javax.swing.Box.createVerticalStrut(14));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        actions.setOpaque(false);
        JButton save = new JButton("Save Settings");
        save.setFont(Theme.LABEL);
        save.setForeground(Color.WHITE);
        save.setBackground(PURPLE);
        save.setFocusPainted(false);
        save.setBorderPainted(false);
        save.setOpaque(true);
        save.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        save.setPreferredSize(new Dimension(154, 42));
        actions.add(save);
        actions.setAlignmentX(LEFT_ALIGNMENT);
        content.add(actions);
        content.add(javax.swing.Box.createVerticalGlue());
        add(content, BorderLayout.CENTER);

        try {
            count.setSelectedItem(settings.getDefaultQuestionCount(user.getUsername()));
            notifications.setSelected(settings.areNotificationsEnabled(user.getUsername()));
        } catch (IOException exception) {
            Theme.showMessageDialog(this, exception.getMessage(),
                    "Settings could not be loaded", JOptionPane.ERROR_MESSAGE);
        }
        save.addActionListener(event -> {
            try {
                settings.set(user.getUsername(), "questionCount", count.getSelectedItem().toString());
                settings.set(user.getUsername(), "notifications",
                        Boolean.toString(notifications.isSelected()));
                Theme.showMessageDialog(this, "Your settings have been saved.",
                        "Settings", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException exception) {
                Theme.showMessageDialog(this, exception.getMessage(),
                        "Settings could not be saved", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JPanel createPreferencesCard(JComboBox<Integer> count) {
        RoundedPanel card = createCard();
        card.setLayout(new BorderLayout(0, 14));
        card.add(cardHeading("Quiz Preferences"), BorderLayout.NORTH);

        JPanel fields = new JPanel(new BorderLayout(16, 0));
        fields.setOpaque(true);
        fields.setBackground(INNER);
        fields.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        JLabel label = new JLabel("Default Quiz Length");
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        fields.add(label, BorderLayout.CENTER);
        fields.add(count, BorderLayout.EAST);
        card.add(fields, BorderLayout.CENTER);
        card.setAlignmentX(LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        return card;
    }

    private JPanel createNotificationsCard(JCheckBox notifications) {
        RoundedPanel card = createCard();
        card.setLayout(new BorderLayout(0, 14));
        card.add(cardHeading("Notifications"), BorderLayout.NORTH);

        JPanel section = new JPanel(new BorderLayout(0, 5));
        section.setOpaque(true);
        section.setBackground(INNER);
        section.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        section.add(notifications, BorderLayout.NORTH);
        JLabel description = new JLabel("Show helpful alerts during your quiz sessions and while using the app.");
        description.setForeground(SECONDARY_TEXT);
        description.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        description.setBorder(BorderFactory.createEmptyBorder(5, 28, 0, 0));
        section.add(description, BorderLayout.CENTER);
        card.add(section, BorderLayout.CENTER);
        card.setAlignmentX(LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 138));
        return card;
    }

    private JCheckBox createNotificationsCheckbox() {
        JCheckBox checkbox = new JCheckBox("Application notifications");
        checkbox.setOpaque(false);
        checkbox.setForeground(Color.WHITE);
        checkbox.setFont(new Font("Segoe UI", Font.BOLD, 14));
        checkbox.setIcon(new CheckIcon(false));
        checkbox.setSelectedIcon(new CheckIcon(true));
        checkbox.setIconTextGap(10);
        return checkbox;
    }

    private RoundedPanel createCard() {
        RoundedPanel card = new RoundedPanel(CARD, 16);
        card.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        return card;
    }

    private JLabel cardHeading(String text) {
        JLabel heading = new JLabel(text);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 16));
        return heading;
    }

    private void styleDropdown(JComboBox<Integer> combo) {
        combo.setEditable(false);
        combo.setUI(new PurpleComboBoxUI());
        combo.setBackground(PURPLE);
        combo.setForeground(Color.WHITE);
        combo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        combo.setOpaque(true);
        combo.setPreferredSize(new Dimension(118, 36));
        combo.setBorder(BorderFactory.createLineBorder(new Color(0x62, 0x47, 0xA0)));
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                                    boolean selected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(
                        list, value, index, selected, cellHasFocus);
                boolean currentValue = index < 0;
                label.setOpaque(true);
                label.setBackground(currentValue || selected ? PURPLE : POPUP_NAVY);
                label.setForeground(Color.WHITE);
                label.setFont(combo.getFont());
                label.setBorder(BorderFactory.createEmptyBorder(4, 9, 4, 9));
                return label;
            }
        });
    }

    private static final class PurpleComboBoxUI extends BasicComboBoxUI {
        @Override
        protected JButton createArrowButton() {
            BasicArrowButton button = new BasicArrowButton(SwingConstants.SOUTH, PURPLE,
                    PURPLE, Color.WHITE, PURPLE);
            button.setBackground(PURPLE);
            button.setForeground(Color.WHITE);
            button.setOpaque(true);
            button.setBorderPainted(false);
            button.setContentAreaFilled(true);
            return button;
        }

        @Override
        public void paintCurrentValueBackground(Graphics graphics, Rectangle bounds, boolean hasFocus) {
            graphics.setColor(PURPLE);
            graphics.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
        }
    }

    private static final class CheckIcon implements javax.swing.Icon {
        private final boolean checked;

        private CheckIcon(boolean checked) {
            this.checked = checked;
        }

        @Override
        public int getIconWidth() {
            return 18;
        }

        @Override
        public int getIconHeight() {
            return 18;
        }

        @Override
        public void paintIcon(java.awt.Component component, Graphics graphics, int x, int y) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setColor(checked ? PURPLE : POPUP_NAVY);
            g.fillRoundRect(x, y, 17, 17, 4, 4);
            g.setColor(checked ? Color.WHITE : SECONDARY_TEXT);
            g.drawRoundRect(x, y, 17, 17, 4, 4);
            if (checked) {
                g.setStroke(new java.awt.BasicStroke(2f));
                g.drawLine(x + 4, y + 9, x + 7, y + 12);
                g.drawLine(x + 7, y + 12, x + 13, y + 5);
            }
            g.dispose();
        }
    }

    private static final class RoundedPanel extends JPanel {
        private final Color background;
        private final int radius;

        private RoundedPanel(Color background, int radius) {
            this.background = background;
            this.radius = radius;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(background);
            g.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g.dispose();
            super.paintComponent(graphics);
        }
    }
}
