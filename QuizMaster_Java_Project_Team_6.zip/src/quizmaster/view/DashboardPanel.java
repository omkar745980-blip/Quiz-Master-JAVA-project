package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import quizmaster.model.ScoreRecord;
import quizmaster.model.User;
import quizmaster.service.QuestionService;
import quizmaster.service.ScoreService;
import quizmaster.service.SettingsService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class DashboardPanel extends JPanel {
    private static final Color DROPDOWN_PURPLE = new Color(0x75, 0x45, 0xD6);
    private static final Color DROPDOWN_NAVY = new Color(0x19, 0x1F, 0x38);

    @FunctionalInterface
    public interface QuizStarter {
        void start(String category, boolean practice, int questionCount);
    }

    public DashboardPanel(User user, QuestionService questionService, QuizStarter onStart,
                          Runnable onHistory, Runnable onAdmin, Runnable onLogout) {
        this(user, questionService, null, null, onStart, onHistory, onAdmin, onLogout);
    }

    public DashboardPanel(User user, QuestionService questionService, ScoreService scoreService,
                          SettingsService settingsService, QuizStarter onStart,
                          Runnable onHistory, Runnable onAdmin, Runnable onLogout) {
        setLayout(new BorderLayout(24, 24));
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(28, 38, 32, 38));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel brand = new JLabel("QUIZMASTER");
        brand.setForeground(Theme.PURPLE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 13));
        top.add(brand, BorderLayout.WEST);
        JPanel userMenu = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        userMenu.setOpaque(false);
        JLabel greeting = new JLabel("Welcome, " + user.getDisplayName());
        greeting.setForeground(Theme.TEXT);
        greeting.setFont(Theme.LABEL);
        userMenu.add(greeting);
        JButton history = Theme.button("My results", false);
        history.addActionListener(event -> onHistory.run());
        userMenu.add(history);
        if (user.getRole() == User.Role.ADMIN) {
            JButton admin = Theme.button("Admin panel", false);
            admin.addActionListener(event -> onAdmin.run());
            userMenu.add(admin);
        }
        JButton logout = Theme.button("Log out", false);
        logout.addActionListener(event -> onLogout.run());
        userMenu.add(logout);
        top.add(userMenu, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 20));
        center.setOpaque(false);
        JPanel welcome = new JPanel(new BorderLayout(0, 10));
        welcome.setOpaque(false);
        JLabel title = new JLabel("Ready to level up?");
        title.setForeground(Theme.TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 34));
        welcome.add(title, BorderLayout.NORTH);
        JLabel description = new JLabel("Choose a subject and make every question count.");
        description.setForeground(Theme.MUTED);
        description.setFont(Theme.BODY);
        welcome.add(description, BorderLayout.CENTER);
        center.add(welcome, BorderLayout.NORTH);

        JPanel dashboardContent = new JPanel();
        dashboardContent.setOpaque(false);
        dashboardContent.setLayout(new javax.swing.BoxLayout(dashboardContent, javax.swing.BoxLayout.Y_AXIS));
        List<ScoreRecord> records = loadRecords(user, scoreService);
        dashboardContent.add(createStatistics(records));
        JPanel body = new JPanel(new GridLayout(1, 2, 22, 0));
        body.setOpaque(false);
        body.add(createQuizCard(user, questionService, settingsService, onStart));
        body.add(createActivityCard(records, onHistory));
        dashboardContent.add(body);
        dashboardContent.add(createCategoryChart(records));
        JScrollPane scroll = new JScrollPane(dashboardContent);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JLabel bottom = new JLabel("Small steps. Strong knowledge. Great results.");
        bottom.setForeground(new Color(109, 120, 151));
        bottom.setFont(Theme.BODY);
        add(bottom, BorderLayout.SOUTH);
    }

    private JPanel createQuizCard(User user, QuestionService service, SettingsService settings,
                                  QuizStarter onStart) {
        JPanel card = card();
        card.setLayout(new BorderLayout(0, 18));
        JLabel heading = new JLabel("Start a quiz");
        heading.setForeground(Theme.TEXT);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        card.add(heading, BorderLayout.NORTH);
        JPanel form = new JPanel(new GridLayout(0, 1, 0, 11));
        form.setOpaque(false);
        JLabel selectLabel = new JLabel("SUBJECT");
        selectLabel.setForeground(Theme.MUTED);
        selectLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        form.add(selectLabel);
        JComboBox<String> categories = new JComboBox<>();
        categories.setFont(Theme.BODY);
        categories.setPreferredSize(new Dimension(280, 42));
        styleDropdown(categories);
        try {
            List<String> values = service.getCategories();
            for (String value : values) {
                categories.addItem(value);
            }
        } catch (IOException exception) {
            Theme.showMessageDialog(this, "Could not load quiz categories.\n" + exception.getMessage(),
                    "Storage error", JOptionPane.ERROR_MESSAGE);
        }
        form.add(categories);
        JLabel countLabel = new JLabel("NUMBER OF QUESTIONS");
        countLabel.setForeground(Theme.MUTED);
        countLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        form.add(countLabel);
        JComboBox<Integer> questionCount = new JComboBox<>(new Integer[]{10, 20});
        questionCount.setFont(Theme.BODY);
        questionCount.setPreferredSize(new Dimension(280, 42));
        styleDropdown(questionCount);
        if (settings != null) {
            try {
                questionCount.setSelectedItem(settings.getDefaultQuestionCount(user.getUsername()));
            } catch (IOException exception) {
                Theme.showMessageDialog(this, exception.getMessage(),
                        "Could not load settings", JOptionPane.ERROR_MESSAGE);
            }
        }
        form.add(questionCount);
        JLabel helper = new JLabel("Questions are shuffled every time.");
        helper.setForeground(Theme.MUTED);
        helper.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        form.add(helper);
        JPanel actions = new JPanel(new GridLayout(1, 2, 10, 0));
        actions.setOpaque(false);
        JButton timed = Theme.button("Timed exam", true);
        timed.addActionListener(event -> start(categories, questionCount, onStart, false));
        JButton practice = Theme.button("Practice mode", false);
        practice.addActionListener(event -> start(categories, questionCount, onStart, true));
        actions.add(timed);
        actions.add(practice);
        form.add(actions);
        card.add(form, BorderLayout.CENTER);
        return card;
    }

    private JPanel createStatistics(List<ScoreRecord> records) {
        int average = records.isEmpty() ? 0
                : (int) records.stream().mapToInt(ScoreRecord::getPercentage).average().orElse(0);
        int highest = records.stream().mapToInt(ScoreRecord::getPercentage).max().orElse(0);
        JPanel cards = new JPanel(new GridLayout(1, 3, 14, 0));
        cards.setOpaque(false);
        cards.add(statCard("TOTAL QUIZZES", Integer.toString(records.size()), "Completed attempts"));
        cards.add(statCard("AVERAGE SCORE", average + "%", "Across all attempts"));
        cards.add(statCard("HIGHEST SCORE", highest + "%", "Personal best"));
        cards.setBorder(BorderFactory.createEmptyBorder(0, 0, 18, 0));
        return cards;
    }

    private JPanel statCard(String title, String value, String detail) {
        JPanel panel = card();
        panel.setLayout(new BorderLayout(0, 7));
        JLabel heading = new JLabel(title);
        heading.setForeground(Theme.MUTED);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 11));
        JLabel metric = new JLabel(value);
        metric.setForeground(Theme.PURPLE);
        metric.setFont(new Font("Segoe UI", Font.BOLD, 28));
        JLabel caption = new JLabel(detail);
        caption.setForeground(Theme.MUTED);
        caption.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        panel.add(heading, BorderLayout.NORTH);
        panel.add(metric, BorderLayout.CENTER);
        panel.add(caption, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createActivityCard(List<ScoreRecord> records, Runnable onHistory) {
        JPanel panel = card();
        panel.setLayout(new BorderLayout(0, 11));
        JLabel heading = new JLabel("Recent quiz activity");
        heading.setForeground(Theme.TEXT);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 18));
        panel.add(heading, BorderLayout.NORTH);
        JPanel rows = new JPanel(new GridLayout(0, 1, 0, 6));
        rows.setOpaque(false);
        for (int i = 0; i < Math.min(5, records.size()); i++) {
            ScoreRecord record = records.get(i);
            JLabel row = new JLabel(record.getCategory() + "   ·   " + record.getPercentage()
                    + "%   ·   " + record.getDisplayDate());
            row.setForeground(Theme.MUTED);
            row.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            rows.add(row);
        }
        if (records.isEmpty()) {
            JLabel empty = new JLabel("Completed quizzes appear here.");
            empty.setForeground(Theme.MUTED);
            rows.add(empty);
        }
        panel.add(rows, BorderLayout.CENTER);
        JButton all = Theme.button("View all activity", false);
        all.addActionListener(event -> onHistory.run());
        panel.add(all, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createCategoryChart(List<ScoreRecord> records) {
        JPanel panel = card();
        panel.setLayout(new BorderLayout(0, 10));
        JLabel heading = new JLabel("Category performance");
        heading.setForeground(Theme.TEXT);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 18));
        panel.add(heading, BorderLayout.NORTH);
        PerformanceChart chart = new PerformanceChart();
        Map<String, int[]> aggregates = new LinkedHashMap<>();
        for (ScoreRecord record : records) {
            int[] aggregate = aggregates.computeIfAbsent(record.getCategory(), key -> new int[2]);
            aggregate[0] += record.getPercentage();
            aggregate[1]++;
        }
        Map<String, Integer> averages = new LinkedHashMap<>();
        aggregates.forEach((category, aggregate) -> averages.put(category, aggregate[0] / aggregate[1]));
        chart.setValues(averages);
        panel.add(chart, BorderLayout.CENTER);
        return panel;
    }

    private List<ScoreRecord> loadRecords(User user, ScoreService scores) {
        if (scores == null) {
            return new ArrayList<>();
        }
        try {
            return scores.getForUser(user.getUsername());
        } catch (IOException exception) {
            Theme.showMessageDialog(this, exception.getMessage(),
                    "Could not load quiz activity", JOptionPane.ERROR_MESSAGE);
            return new ArrayList<>();
        }
    }

    private void styleDropdown(JComboBox<?> combo) {
        combo.setEditable(false);
        combo.setUI(new PurpleComboBoxUI());
        combo.setBackground(DROPDOWN_PURPLE);
        combo.setForeground(Color.WHITE);
        combo.setFont(combo.getFont().deriveFont(Font.BOLD));
        combo.setOpaque(true);
        combo.setBorder(BorderFactory.createLineBorder(new Color(62, 72, 108)));
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                                    boolean selected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(
                        list, value, index, selected, cellHasFocus);
                label.setOpaque(true);
                boolean selectedValue = index < 0 || selected;
                label.setBackground(selectedValue ? DROPDOWN_PURPLE : DROPDOWN_NAVY);
                label.setForeground(Color.WHITE);
                label.setFont(combo.getFont().deriveFont(index < 0 ? Font.BOLD : Font.PLAIN));
                label.setBorder(BorderFactory.createEmptyBorder(5, 9, 5, 9));
                return label;
            }
        });
    }

    @SuppressWarnings("serial")
    private static final class PurpleComboBoxUI extends BasicComboBoxUI {
        @Override
        protected JButton createArrowButton() {
            BasicArrowButton button = new BasicArrowButton(SwingConstants.SOUTH, DROPDOWN_PURPLE,
                    DROPDOWN_PURPLE, Color.WHITE, DROPDOWN_PURPLE);
            button.setBackground(DROPDOWN_PURPLE);
            button.setForeground(Color.WHITE);
            button.setOpaque(true);
            button.setBorderPainted(false);
            button.setContentAreaFilled(true);
            return button;
        }

        @Override
        public void paintCurrentValueBackground(Graphics graphics, Rectangle bounds, boolean hasFocus) {
            graphics.setColor(DROPDOWN_PURPLE);
            graphics.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
        }
    }

    private void start(JComboBox<String> categories, JComboBox<Integer> questionCount,
                       QuizStarter onStart, boolean practice) {
        Object category = categories.getSelectedItem();
        if (category == null) {
            Theme.showMessageDialog(this, "No quiz categories are available yet.",
                    "No categories", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        onStart.start(category.toString(), practice, (Integer) questionCount.getSelectedItem());
    }

    private JPanel createInfoCard() {
        JPanel card = card();
        card.setLayout(new BorderLayout(0, 18));
        JLabel heading = new JLabel("Your study space");
        heading.setForeground(Theme.TEXT);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        card.add(heading, BorderLayout.NORTH);
        JPanel details = new JPanel(new GridLayout(0, 1, 0, 13));
        details.setOpaque(false);
        details.add(info("01", "Stay focused", "Timed exams help you build confidence under pressure."));
        details.add(info("02", "Learn at your pace", "Practice mode lets you explore without a countdown."));
        details.add(info("03", "Track your progress", "Every completed quiz is saved to your results history."));
        card.add(details, BorderLayout.CENTER);
        return card;
    }

    private JPanel info(String number, String title, String detail) {
        JPanel row = new JPanel(new BorderLayout(12, 3));
        row.setOpaque(false);
        JLabel badge = new JLabel(number, SwingConstants.CENTER);
        badge.setForeground(Theme.PURPLE);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 14));
        badge.setBackground(Theme.SURFACE_LIGHT);
        badge.setOpaque(true);
        badge.setPreferredSize(new Dimension(42, 42));
        row.add(badge, BorderLayout.WEST);
        JPanel text = new JPanel(new BorderLayout(0, 4));
        text.setOpaque(false);
        JLabel name = new JLabel(title);
        name.setForeground(Theme.TEXT);
        name.setFont(Theme.LABEL);
        JLabel desc = new JLabel("<html>" + detail + "</html>");
        desc.setForeground(Theme.MUTED);
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        text.add(name, BorderLayout.NORTH);
        text.add(desc, BorderLayout.CENTER);
        row.add(text, BorderLayout.CENTER);
        return row;
    }

    private JPanel card() {
        JPanel panel = new JPanel();
        panel.setBackground(Theme.SURFACE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(49, 59, 91)),
                BorderFactory.createEmptyBorder(26, 26, 26, 26)));
        return panel;
    }
}
