package quizmaster.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JPanel;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
final class PerformanceChart extends JPanel {
    private Map<String, Integer> values = Map.of();

    PerformanceChart() {
        setOpaque(false);
        setPreferredSize(new java.awt.Dimension(380, 180));
    }

    void setValues(Map<String, Integer> values) {
        this.values = new LinkedHashMap<>(values);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int left = 12;
        int bottom = getHeight() - 34;
        int chartHeight = Math.max(1, getHeight() - 62);
        int gap = 12;
        int count = Math.max(1, values.size());
        int barWidth = Math.max(8, (getWidth() - left - 12 - gap * (count - 1)) / count);
        g.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        int index = 0;
        for (Map.Entry<String, Integer> entry : values.entrySet()) {
            int percent = Math.max(0, Math.min(100, entry.getValue()));
            int barHeight = (chartHeight * percent) / 100;
            int x = left + index * (barWidth + gap);
            int y = bottom - barHeight;
            g.setColor(Theme.SURFACE_LIGHT);
            g.fillRoundRect(x, bottom - chartHeight, barWidth, chartHeight, 8, 8);
            g.setColor(Theme.PURPLE);
            g.fillRoundRect(x, y, barWidth, barHeight, 8, 8);
            g.setColor(Theme.TEXT);
            g.drawString(percent + "%", x, Math.max(12, y - 5));
            g.setColor(Theme.MUTED);
            String label = entry.getKey();
            int maxChars = Math.max(4, barWidth / 6);
            if (label.length() > maxChars) {
                label = label.substring(0, Math.max(1, maxChars - 1)) + "…";
            }
            g.drawString(label, x, bottom + 16);
            index++;
        }
        if (values.isEmpty()) {
            g.setColor(Color.WHITE);
            g.drawString("Complete quizzes to see your performance.", 12, Math.max(18, getHeight() / 2));
        }
        g.dispose();
    }
}
