package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import quizmaster.model.Question;
import quizmaster.model.ScoreRecord;
import quizmaster.model.User;
import quizmaster.service.AuthService;
import quizmaster.service.QuestionService;
import quizmaster.service.ScoreService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class AdminPanel extends JPanel {
    private final QuestionService service;
    private final AuthService authService;
    private final ScoreService scoreService;
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "CATEGORY", "QUESTION", "DIFFICULTY", "CORRECT OPTION", "EXPLANATION"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(model);
    private List<Question> questions;

    public AdminPanel(QuestionService service, Runnable onBack) {
        this(service, null, null, onBack);
    }

    public AdminPanel(QuestionService service, AuthService authService, ScoreService scoreService,
                      Runnable onBack) {
        this.service = service;
        this.authService = authService;
        this.scoreService = scoreService;
        setLayout(new BorderLayout(0, 20));
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(28, 38, 30, 38));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JPanel titles = new JPanel(new BorderLayout(0, 5));
        titles.setOpaque(false);
        JLabel title = new JLabel("Question management");
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.TITLE);
        JLabel subtitle = new JLabel("Add, edit, and remove quiz questions.");
        subtitle.setForeground(Theme.MUTED);
        subtitle.setFont(Theme.BODY);
        titles.add(title, BorderLayout.NORTH);
        titles.add(subtitle, BorderLayout.SOUTH);
        if (authService != null && scoreService != null) {
            try {
                subtitle.setText(authService.getStudents().size() + " students   ·   "
                        + service.getAll().size() + " questions   ·   "
                        + scoreService.getAll().size() + " quiz attempts");
            } catch (IOException exception) {
                showError(exception);
            }
        }
        header.add(titles, BorderLayout.WEST);
        JButton back = Theme.button("← Dashboard", false);
        back.addActionListener(event -> onBack.run());
        header.add(back, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        styleTable();
        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(Theme.SURFACE);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(49, 59, 91)));
        add(scroll, BorderLayout.CENTER);
        JPanel actions = new JPanel(new java.awt.GridLayout(
                authService == null ? 1 : 2, authService == null ? 3 : 3, 8, 8));
        actions.setOpaque(false);
        JButton add = Theme.button("+ Add question", true);
        add.addActionListener(event -> editQuestion(null));
        JButton edit = Theme.button("Edit selected", false);
        edit.addActionListener(event -> editSelected());
        JButton delete = Theme.button("Delete selected", false);
        delete.addActionListener(event -> deleteSelected());
        actions.add(add);
        actions.add(edit);
        actions.add(delete);
        if (authService != null && scoreService != null) {
            JButton categories = Theme.button("Manage categories", false);
            categories.addActionListener(event -> manageCategories());
            JButton students = Theme.button("Student performance", false);
            students.addActionListener(event -> viewStudentPerformance());
            JButton history = Theme.button("Quiz history", false);
            history.addActionListener(event -> viewQuizHistory());
            actions.add(categories);
            actions.add(students);
            actions.add(history);
        }
        add(actions, BorderLayout.SOUTH);
        refresh();
    }

    private void styleTable() {
        table.setRowHeight(38);
        table.setFont(Theme.BODY);
        table.setForeground(Theme.TEXT);
        table.setBackground(Theme.SURFACE);
        table.setGridColor(new Color(49, 59, 91));
        table.setSelectionBackground(Theme.SURFACE_LIGHT);
        table.setSelectionForeground(Theme.TEXT);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
        table.getTableHeader().setForeground(Theme.MUTED);
        table.getTableHeader().setBackground(Theme.SURFACE_LIGHT);
        table.getTableHeader().setReorderingAllowed(false);
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
    }

    private void refresh() {
        try {
            questions = service.getAll();
            model.setRowCount(0);
            for (Question question : questions) {
                model.addRow(new Object[]{question.getId(), question.getCategory(), question.getPrompt(),
                        question.getDifficulty(), (char) ('A' + question.getCorrectAnswer()),
                        question.getExplanation()});
            }
        } catch (IOException exception) {
            showError(exception);
        }
    }

    private void editSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showMessageDialog(this, "Select a question to edit.", "No selection",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        editQuestion(questions.get(table.convertRowIndexToModel(row)));
    }

    private void editQuestion(Question existing) {
        QuestionDialog dialog = new QuestionDialog(
                javax.swing.SwingUtilities.getWindowAncestor(this), existing);
        dialog.setVisible(true);
        if (dialog.getQuestion() == null) {
            return;
        }
        try {
            if (existing == null) {
                service.add(dialog.getQuestion());
            } else {
                service.update(dialog.getQuestion());
            }
            refresh();
        } catch (IOException | IllegalArgumentException exception) {
            showError(exception);
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Theme.showMessageDialog(this, "Select a question to delete.", "No selection",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Question selected = questions.get(table.convertRowIndexToModel(row));
        int confirm = Theme.showConfirmDialog(this,
                "Delete this question?\n\n" + selected.getPrompt(),
                "Confirm deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            service.delete(selected.getId());
            refresh();
        } catch (IOException | IllegalArgumentException exception) {
            showError(exception);
        }
    }

    private void showError(Exception exception) {
        Theme.showMessageDialog(this, exception.getMessage(), "Question error", JOptionPane.ERROR_MESSAGE);
    }

    private void manageCategories() {
        Object[] actions = {"Add", "Rename", "Delete", "Close"};
        int selected = Theme.showOptionDialog(this, "Choose a category action.",
                "Manage categories", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, actions, actions[0]);
        try {
            if (selected == 0) {
                String name = Theme.showInputDialog(this, "New category name:");
                if (name != null) {
                    service.addCategory(name);
                }
            } else if (selected == 1) {
                String current = selectCategory();
                if (current != null) {
                    String replacement = Theme.showInputDialog(this, "New category name:", current);
                    if (replacement != null) {
                        service.renameCategory(current, replacement);
                    }
                }
            } else if (selected == 2) {
                String current = selectCategory();
                if (current != null && Theme.showConfirmDialog(this,
                        "Delete category " + current + "? Empty categories only.",
                        "Confirm deletion", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    service.deleteCategory(current);
                }
            }
        } catch (IOException | IllegalArgumentException exception) {
            showError(exception);
        }
    }

    private String selectCategory() throws IOException {
        List<String> categories = service.getCategories();
        if (categories.isEmpty()) {
            Theme.showMessageDialog(this, "There are no categories to manage.");
            return null;
        }
        Object value = Theme.showInputDialog(this, "Select a category:", "Manage categories",
                JOptionPane.PLAIN_MESSAGE, null, categories.toArray(), categories.get(0));
        return value == null ? null : value.toString();
    }

    private void viewStudentPerformance() {
        try {
            List<User> students = authService.getStudents();
            List<ScoreRecord> records = scoreService.getAll();
            DefaultTableModel studentsModel = new DefaultTableModel(
                    new Object[]{"NAME", "USERNAME", "QUIZZES", "AVERAGE", "BEST"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) { return false; }
            };
            for (User student : students) {
                List<ScoreRecord> attempts = records.stream()
                        .filter(record -> record.getUsername().equalsIgnoreCase(student.getUsername())).toList();
                int average = attempts.isEmpty() ? 0
                        : (int) attempts.stream().mapToInt(ScoreRecord::getPercentage).average().orElse(0);
                int best = attempts.stream().mapToInt(ScoreRecord::getPercentage).max().orElse(0);
                studentsModel.addRow(new Object[]{student.getDisplayName(), student.getUsername(),
                        attempts.size(), average + "%", best + "%"});
            }
            showTable("Student performance", studentsModel);
        } catch (IOException exception) {
            showError(exception);
        }
    }

    private void viewQuizHistory() {
        try {
            DefaultTableModel history = new DefaultTableModel(
                    new Object[]{"COMPLETED", "STUDENT", "CATEGORY", "SCORE", "MODE"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) { return false; }
            };
            for (ScoreRecord record : scoreService.getAll()) {
                history.addRow(new Object[]{record.getDisplayDate(), record.getUsername(), record.getCategory(),
                        record.getScore() + " / " + record.getTotal(),
                        record.isPractice() ? "Practice" : "Timed exam"});
            }
            showTable("All quiz history", history);
        } catch (IOException exception) {
            showError(exception);
        }
    }

    private void showTable(String title, DefaultTableModel tableModel) {
        JTable results = new JTable(tableModel);
        results.setRowHeight(30);
        results.setForeground(Theme.TEXT);
        results.setBackground(Theme.SURFACE);
        results.setSelectionBackground(Theme.PURPLE_DARK);
        results.setSelectionForeground(Theme.TEXT);
        JScrollPane pane = new JScrollPane(results);
        pane.setPreferredSize(new java.awt.Dimension(700, 380));
        Theme.showMessageDialog(this, pane, title, JOptionPane.PLAIN_MESSAGE);
    }
}
