package quizmaster.view;

import java.awt.GridLayout;
import java.awt.Window;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import quizmaster.model.MCQQuestion;
import quizmaster.model.TrueFalseQuestion;
import quizmaster.model.Question;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
final class QuestionDialog extends JOptionPane {
    private Question question;

    QuestionDialog(Window owner, Question existing) {
        JTextField category = new JTextField(existing == null ? "" : existing.getCategory());
        JTextField prompt = new JTextField(existing == null ? "" : existing.getPrompt());
        JTextField[] optionFields = new JTextField[4];
        JPanel fields = new JPanel(new GridLayout(0, 1, 0, 7));
        fields.setBorder(BorderFactory.createEmptyBorder(8, 4, 8, 4));
        fields.setBackground(Theme.DIALOG_BACKGROUND);
        fields.add(label("Category"));
        fields.add(category);
        fields.add(label("Question"));
        fields.add(prompt);
        for (int i = 0; i < optionFields.length; i++) {
            fields.add(label("Option " + (char) ('A' + i)));
            optionFields[i] = new JTextField(existing == null ? "" : existing.getOptions().get(i));
            fields.add(optionFields[i]);
        }
        fields.add(label("Difficulty"));
        JComboBox<String> difficulty = new JComboBox<>(new String[]{"Easy", "Medium", "Hard"});
        if (existing != null) {
            difficulty.setSelectedItem(existing.getDifficulty());
        }
        fields.add(difficulty);
        fields.add(label("Short explanation"));
        JTextField explanation = new JTextField(existing == null ? "" : existing.getExplanation());
        fields.add(explanation);
        fields.add(label("Correct answer"));
        JComboBox<String> correct = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        if (existing != null) {
            correct.setSelectedIndex(existing.getCorrectAnswer());
        }
        fields.add(correct);
        setMessage(fields);
        setMessageType(PLAIN_MESSAGE);
        setOptionType(OK_CANCEL_OPTION);
        javax.swing.JDialog dialog = createDialog(owner, existing == null ? "Add question" : "Edit question");
        dialog.getContentPane().setBackground(Theme.DIALOG_BACKGROUND);
        dialog.pack();
        Theme.styleDialogButtons(dialog.getContentPane());
        dialog.setVisible(true);
        if (getValue() instanceof Integer && (Integer) getValue() == OK_OPTION) {
            try {
                String[] values = new String[4];
                for (int i = 0; i < values.length; i++) {
                    values[i] = optionFields[i].getText().trim();
                }
                if (existing == null) {
                    if (isTrueFalseOptions(values)) {
                        question = new TrueFalseQuestion(category.getText(), prompt.getText(),
                                correct.getSelectedIndex(), difficulty.getSelectedItem().toString(),
                                explanation.getText());
                    } else {
                        question = new MCQQuestion(category.getText(), prompt.getText(),
                                Arrays.asList(values), correct.getSelectedIndex(),
                                difficulty.getSelectedItem().toString(), explanation.getText());
                    }
                } else if (existing instanceof TrueFalseQuestion) {
                    question = new TrueFalseQuestion(existing.getId(), category.getText(), prompt.getText(),
                            correct.getSelectedIndex(), difficulty.getSelectedItem().toString(),
                            explanation.getText());
                } else {
                    question = new MCQQuestion(existing.getId(), category.getText(), prompt.getText(),
                            Arrays.asList(values), correct.getSelectedIndex(),
                            difficulty.getSelectedItem().toString(), explanation.getText());
                }
                if (question.getCategory().isEmpty() || question.getPrompt().isEmpty()) {
                    throw new IllegalArgumentException("Category and question text are required.");
                }
                for (int i = 0; i < question.getOptionCount(); i++) {
                    if (question.getOptions().get(i).isEmpty()) {
                        throw new IllegalArgumentException("All question answer options are required.");
                    }
                }
            } catch (IllegalArgumentException exception) {
                Theme.showMessageDialog(owner, exception.getMessage(), "Invalid question",
                        JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    Question getQuestion() {
        return question;
    }

    private JLabel label(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Theme.TEXT);
        label.setFont(Theme.LABEL);
        return label;
    }

    private boolean isTrueFalseOptions(String[] options) {
        return "True".equalsIgnoreCase(options[0]) && "False".equalsIgnoreCase(options[1])
                && options[2].isEmpty() && options[3].isEmpty();
    }
}
