package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import quizmaster.controller.QuizController;
import quizmaster.model.ScoreRecord;
import quizmaster.model.User;
import quizmaster.service.QuestionService;
import quizmaster.service.QuizService;
import quizmaster.service.ScoreService;
import quizmaster.service.AuthService;
import quizmaster.service.SettingsService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class MainFrame extends JFrame {
    private final User user;
    private final QuestionService questionService;
    private final ScoreService scoreService;
    private final AuthService authService;
    private final SettingsService settingsService;
    private final Runnable onLogout;
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final Map<String, SidebarButton> navigationButtons = new LinkedHashMap<>();
    private String activeNavigationPage;

    private static final Color SIDEBAR_BACKGROUND = new Color(0x11, 0x16, 0x2B);
    private static final Color NAVIGATION_BACKGROUND = new Color(0x25, 0x2D, 0x49);
    private static final Color NAVIGATION_FOREGROUND = new Color(0xE2, 0xE8, 0xF0);
    private static final Color NAVIGATION_ACTIVE = new Color(0x75, 0x45, 0xD6);
    private static final Color NAVIGATION_HOVER = new Color(0x49, 0x31, 0x6F);

    public MainFrame(User user, QuestionService questionService, ScoreService scoreService,
                     AuthService authService, SettingsService settingsService, Runnable onLogout) {
        this.user = user;
        this.questionService = questionService;
        this.scoreService = scoreService;
        this.authService = authService;
        this.settingsService = settingsService;
        this.onLogout = onLogout;
        setTitle("QuizMaster | " + user.getUsername());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 740);
        setMinimumSize(new Dimension(900, 640));
        setLocationRelativeTo(null);
        getContentPane().setBackground(Theme.BACKGROUND);
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BACKGROUND);
        root.add(createSidebar(), BorderLayout.WEST);
        root.add(content, BorderLayout.CENTER);
        add(root, BorderLayout.CENTER);
        installShortcuts();
        showDashboard();
    }

    private void showDashboard() {
        DashboardPanel dashboard = new DashboardPanel(user, questionService, scoreService, settingsService,
                (category, practice, questionCount) -> startQuiz(category, practice, questionCount),
                this::showHistory, this::showAdmin, this::logout);
        setScreen(dashboard, "dashboard");
    }

    private void startQuiz(String category, boolean practice, int questionCount) {
        try {
            QuizController controller = new QuizController(
                    new QuizService(questionService, scoreService), user, category, practice, questionCount);
            ExamPanel exam = new ExamPanel(controller, this::showResult,
                    settingsService.areNotificationsEnabled(user.getUsername()));
            setScreen(exam, "exam");
        } catch (IOException | IllegalArgumentException exception) {
            showError(exception);
        }
    }

    private void showResult(ScoreRecord score) {
        setScreen(new ResultPanel(score, this::showHistory, this::showDashboard,
                () -> showReview(score)), "result");
    }

    private void showReview(ScoreRecord score) {
        setScreen(new AnswerReviewPanel(score, () -> showResult(score)), "review");
    }

    private void showHistory() {
        try {
            setScreen(new HistoryPanel(user, scoreService, this::showDashboard), "history");
        } catch (IOException exception) {
            showError(exception);
        }
    }

    private void showProfile() {
        setScreen(new ProfilePanel(user, authService), "profile");
    }

    private void showSettings() {
        setScreen(new SettingsPanel(user, settingsService), "settings");
    }

    private void showAbout() {
        setScreen(new AboutPanel(), "about");
    }

    private void showAdmin() {
        if (user.getRole() != User.Role.ADMIN) {
            return;
        }
        setScreen(new AdminPanel(questionService, authService, scoreService, this::showDashboard), "admin");
    }

    private void logout() {
        dispose();
        onLogout.run();
    }

    private void setScreen(java.awt.Component screen, String name) {
        content.removeAll();
        content.add(screen, name);
        cards.show(content, name);
        updateActiveNavigation(name);
        content.revalidate();
        content.repaint();
    }

    private void updateActiveNavigation(String screenName) {
        String page = switch (screenName) {
            case "exam", "result", "review" -> "dashboard";
            default -> screenName;
        };
        if (!navigationButtons.containsKey(page)) {
            page = null;
        }
        activeNavigationPage = page;
        String selectedPage = activeNavigationPage;
        navigationButtons.forEach((name, button) -> button.setActive(name.equals(selectedPage)));
    }

    private void showError(Exception exception) {
        Theme.showMessageDialog(this, exception.getMessage(), "QuizMaster", JOptionPane.ERROR_MESSAGE);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new javax.swing.BoxLayout(sidebar, javax.swing.BoxLayout.Y_AXIS));
        sidebar.setBackground(SIDEBAR_BACKGROUND);
        sidebar.setBorder(BorderFactory.createEmptyBorder(22, 14, 22, 14));
        sidebar.setPreferredSize(new Dimension(205, 0));
        JLabel brand = new JLabel("◆  QUIZMASTER");
        brand.setForeground(Theme.PURPLE);
        brand.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18));
        brand.setBorder(BorderFactory.createEmptyBorder(0, 4, 24, 0));
        sidebar.add(brand);
        addNavigationButton(sidebar, "dashboard", "⌂   Dashboard", this::showDashboard);
        addNavigationButton(sidebar, "history", "▤   Quiz history", this::showHistory);
        addNavigationButton(sidebar, "profile", "◉   My profile", this::showProfile);
        addNavigationButton(sidebar, "settings", "⚙   Settings", this::showSettings);
        if (user.getRole() == User.Role.ADMIN) {
            addNavigationButton(sidebar, "admin", "◆   Administration", this::showAdmin);
        }
        addNavigationButton(sidebar, "about", "ⓘ   About", this::showAbout);
        sidebar.add(javax.swing.Box.createVerticalGlue());
        String shortcuts = "<html>Shortcuts<br>Ctrl+1 Dashboard<br>Ctrl+2 History<br>"
                + "Ctrl+3 Profile<br>Ctrl+4 Settings"
                + (user.getRole() == User.Role.ADMIN ? "<br>Ctrl+5 Admin" : "")
                + "<br>Ctrl+L Log out</html>";
        JLabel shortcutHint = new JLabel(shortcuts);
        shortcutHint.setForeground(Theme.MUTED);
        shortcutHint.setBorder(BorderFactory.createEmptyBorder(14, 4, 14, 4));
        sidebar.add(shortcutHint);
        addNavigationButton(sidebar, null, "⇥   Log out", this::logout);
        return sidebar;
    }

    private void addNavigationButton(JPanel sidebar, String page, String title, Runnable action) {
        SidebarButton button = new SidebarButton(title);
        button.addActionListener(event -> action.run());
        button.setAlignmentX(LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        sidebar.add(button);
        if (page != null) {
            navigationButtons.put(page, button);
        }
        sidebar.add(javax.swing.Box.createVerticalStrut(7));
    }

    private static final class SidebarButton extends JButton {
        private boolean active;
        private boolean hovered;

        private SidebarButton(String text) {
            super(text);
            setHorizontalAlignment(JButton.LEFT);
            setFont(Theme.BODY);
            setForeground(NAVIGATION_FOREGROUND);
            setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 10));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent event) {
                    hovered = true;
                    updateAppearance();
                }

                @Override
                public void mouseExited(MouseEvent event) {
                    hovered = false;
                    updateAppearance();
                }
            });
        }

        private void setActive(boolean active) {
            this.active = active;
            updateAppearance();
        }

        private void updateAppearance() {
            setForeground(active || hovered ? Color.WHITE : NAVIGATION_FOREGROUND);
            setFont(active ? Theme.LABEL : Theme.BODY);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(active ? NAVIGATION_ACTIVE : hovered ? NAVIGATION_HOVER : NAVIGATION_BACKGROUND);
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g.dispose();
            super.paintComponent(graphics);
        }
    }

    private void installShortcuts() {
        InputMap input = getRootPane().getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actions = getRootPane().getActionMap();
        bind(input, actions, "ctrl 1", "dashboard", this::showDashboard);
        bind(input, actions, "ctrl 2", "history", this::showHistory);
        bind(input, actions, "ctrl 3", "profile", this::showProfile);
        bind(input, actions, "ctrl 4", "settings", this::showSettings);
        bind(input, actions, "ctrl L", "logout", this::logout);
        if (user.getRole() == User.Role.ADMIN) {
            bind(input, actions, "ctrl 5", "admin", this::showAdmin);
        }
    }

    private void bind(InputMap input, ActionMap actions, String key, String name, Runnable callback) {
        input.put(KeyStroke.getKeyStroke(key), name);
        actions.put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent event) {
                callback.run();
            }
        });
    }
}
