package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import quizmaster.model.AnswerReview;
import quizmaster.model.ScoreRecord;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class AnswerReviewPanel extends JPanel {
    public AnswerReviewPanel(ScoreRecord score, Runnable onBack) {
        setLayout(new BorderLayout(0, 20));
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(28, 38, 30, 38));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("Answer review · " + score.getCategory());
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.TITLE);
        header.add(title, BorderLayout.WEST);
        JButton back = Theme.button("← Results", false);
        back.addActionListener(event -> onBack.run());
        header.add(back, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        JPanel answers = new JPanel(new GridLayout(0, 1, 0, 12));
        answers.setOpaque(false);
        List<AnswerReview> reviews = score.getAnswerReviews();
        if (reviews.isEmpty()) {
            JLabel unavailable = new JLabel("Detailed review is unavailable for attempts saved before this update.");
            unavailable.setForeground(Theme.MUTED);
            answers.add(unavailable);
        }
        for (int i = 0; i < reviews.size(); i++) {
            AnswerReview review = reviews.get(i);
            JPanel card = new JPanel(new GridLayout(0, 1, 0, 6));
            card.setBackground(Theme.SURFACE);
            card.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
            JLabel prompt = new JLabel((i + 1) + ". " + review.getPrompt());
            prompt.setForeground(Theme.TEXT);
            prompt.setFont(Theme.LABEL);
            card.add(prompt);
            for (int option = 0; option < review.getOptions().size(); option++) {
                if (review.getOptions().get(option).isEmpty()) {
                    continue;
                }
                boolean correct = option == review.getCorrectAnswer();
                boolean selected = review.getSelectedAnswer() != null
                        && option == review.getSelectedAnswer();
                String state = correct ? "  ✓ Correct answer" : selected ? "  ✕ Your answer" : "";
                JLabel choice = new JLabel("   " + (char) ('A' + option) + ". "
                        + review.getOptions().get(option) + state);
                choice.setForeground(correct ? Theme.SUCCESS : selected ? Theme.DANGER : Theme.MUTED);
                card.add(choice);
            }
            JLabel explanation = new JLabel("<html><b>Explanation:</b> "
                    + escape(review.getExplanation()) + "</html>");
            explanation.setForeground(Theme.MUTED);
            card.add(explanation);
            answers.add(card);
        }
        JScrollPane scroll = new JScrollPane(answers);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Theme.BACKGROUND);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        add(scroll, BorderLayout.CENTER);
    }

    private String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
