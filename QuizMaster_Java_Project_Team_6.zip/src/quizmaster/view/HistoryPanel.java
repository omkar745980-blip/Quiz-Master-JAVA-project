package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import quizmaster.model.ScoreRecord;
import quizmaster.model.User;
import quizmaster.service.ScoreService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class HistoryPanel extends JPanel {
    public HistoryPanel(User user, ScoreService scoreService, Runnable onBack) throws IOException {
        setLayout(new BorderLayout(0, 24));
        setBackground(Theme.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(30, 38, 32, 38));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("Your score history");
        title.setForeground(Theme.TEXT);
        title.setFont(Theme.TITLE);
        header.add(title, BorderLayout.WEST);
        JButton back = Theme.button("← Dashboard", false);
        back.addActionListener(event -> onBack.run());
        header.add(back, BorderLayout.EAST);
        JButton export = Theme.button("Export CSV", true);
        export.addActionListener(event -> exportCsv(user, scoreService));
        JPanel headerActions = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
        headerActions.setOpaque(false);
        headerActions.add(export);
        headerActions.add(back);
        header.add(headerActions, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        List<ScoreRecord> records = scoreService.getForUser(user.getUsername());
        String[] columns = {"COMPLETED", "SUBJECT", "MODE", "SCORE", "RESULT"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        for (ScoreRecord record : records) {
            model.addRow(new Object[]{record.getDisplayDate(), record.getCategory(),
                    record.isPractice() ? "Practice" : "Timed exam",
                    record.getScore() + " / " + record.getTotal(), record.getPercentage() + "%"});
        }
        JTable table = new JTable(model);
        table.setRowHeight(42);
        table.setFont(Theme.BODY);
        table.setForeground(Theme.TEXT);
        table.setBackground(Theme.SURFACE);
        table.setGridColor(new Color(49, 59, 91));
        table.setSelectionBackground(Theme.SURFACE_LIGHT);
        table.setSelectionForeground(Theme.TEXT);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
        table.getTableHeader().setForeground(Theme.MUTED);
        table.getTableHeader().setBackground(Theme.SURFACE_LIGHT);
        table.getTableHeader().setReorderingAllowed(false);
        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(Theme.SURFACE);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(49, 59, 91)));
        add(scroll, BorderLayout.CENTER);
        JButton review = Theme.button("Review selected quiz", true);
        review.addActionListener(event -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                Theme.showMessageDialog(this, "Select a quiz attempt first.",
                        "No selection", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            int modelRow = table.convertRowIndexToModel(row);
            new AnswerReviewDialog(javax.swing.SwingUtilities.getWindowAncestor(this),
                    records.get(modelRow)).setVisible(true);
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2 && table.getSelectedRow() >= 0) {
                    int modelRow = table.convertRowIndexToModel(table.getSelectedRow());
                    new AnswerReviewDialog(javax.swing.SwingUtilities.getWindowAncestor(HistoryPanel.this),
                            records.get(modelRow)).setVisible(true);
                }
            }
        });
        JPanel footer = new JPanel(new java.awt.BorderLayout());
        footer.setOpaque(false);
        if (records.isEmpty()) {
            JLabel empty = new JLabel("No completed quizzes yet. Your results will appear here.",
                    JLabel.CENTER);
            empty.setForeground(Theme.MUTED);
            empty.setFont(Theme.BODY);
            footer.add(empty, BorderLayout.CENTER);
            review.setEnabled(false);
        }
        footer.add(review, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);
    }

    private void exportCsv(User user, ScoreService scoreService) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export quiz history");
        chooser.setSelectedFile(new java.io.File("quiz-history.csv"));
        Theme.styleDialogButtons(chooser);
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try {
            scoreService.exportCsv(chooser.getSelectedFile().toPath(), user.getUsername());
            Theme.showMessageDialog(this, "Quiz history exported successfully.",
                    "Export complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException exception) {
            Theme.showMessageDialog(this, exception.getMessage(),
                    "Export failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("serial")
    private static final class AnswerReviewDialog extends javax.swing.JDialog {
        AnswerReviewDialog(java.awt.Window owner, ScoreRecord record) {
            super(owner, "Review · " + record.getCategory(), ModalityType.APPLICATION_MODAL);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            setSize(780, 600);
            setLocationRelativeTo(owner);
            setContentPane(new AnswerReviewPanel(record, this::dispose));
            Theme.styleDialogButtons(getContentPane());
        }
    }
}
