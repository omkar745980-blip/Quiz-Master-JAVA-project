package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import quizmaster.model.User;
import quizmaster.service.AuthService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class LoginFrame extends JFrame {
    private final AuthService authService;
    private final Consumer<User> onAuthenticated;
    private final CardLayout formLayout = new CardLayout();
    private final JPanel formCards = new JPanel(formLayout);
    private JTextField loginUsername;
    private JPasswordField loginPassword;
    private JTextField registerName;
    private JTextField registerUsername;
    private JPasswordField registerPassword;

    public LoginFrame(AuthService authService, Consumer<User> onAuthenticated) {
        this.authService = authService;
        this.onAuthenticated = onAuthenticated;
        setTitle("QuizMaster | Smart Quiz & Exam Practice");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(950, 620);
        setMinimumSize(new Dimension(820, 560));
        setLocationRelativeTo(null);
        getContentPane().setBackground(Theme.BACKGROUND);
        build();
    }

    private void build() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Theme.BACKGROUND);
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.SURFACE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(54, 63, 96)),
                BorderFactory.createEmptyBorder(42, 48, 42, 48)));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.insets = new Insets(0, 0, 10, 0);

        JLabel brand = new JLabel("QUIZMASTER");
        brand.setForeground(Theme.PURPLE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 13));
        brand.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(brand, c);
        c.gridy++;
        JLabel title = new JLabel("Learn. Practice. Excel.");
        title.setForeground(Theme.TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(title, c);
        c.gridy++;
        JLabel subtitle = new JLabel("Your next great result starts here.");
        subtitle.setForeground(Theme.MUTED);
        subtitle.setFont(Theme.BODY);
        subtitle.setHorizontalAlignment(SwingConstants.CENTER);
        c.insets = new Insets(0, 0, 28, 0);
        card.add(subtitle, c);

        formCards.setOpaque(false);
        formCards.add(createLoginForm(), "login");
        formCards.add(createRegisterForm(), "register");
        c.gridy++;
        c.insets = new Insets(0, 0, 0, 0);
        card.add(formCards, c);
        root.add(card);
        add(root, BorderLayout.CENTER);

        JLabel footer = new JLabel("SMART QUIZ & EXAM PRACTICE SYSTEM", SwingConstants.CENTER);
        footer.setForeground(new Color(109, 120, 151));
        footer.setFont(new Font("Segoe UI", Font.BOLD, 10));
        footer.setBorder(BorderFactory.createEmptyBorder(0, 0, 22, 0));
        add(footer, BorderLayout.SOUTH);
    }

    private JPanel createLoginForm() {
        JPanel panel = formPanel();
        GridBagConstraints c = constraints();
        loginUsername = addField(panel, c, "Username", false);
        loginPassword = (JPasswordField) addField(panel, c, "Password", true);
        JButton signIn = Theme.button("Sign in", true);
        signIn.setPreferredSize(new Dimension(300, 44));
        signIn.addActionListener(event -> login());
        addRow(panel, c, signIn, 16);
        JButton switchButton = linkButton("New to QuizMaster?  Create an account");
        switchButton.addActionListener(event -> formLayout.show(formCards, "register"));
        addRow(panel, c, switchButton, 6);
        JLabel adminHint = new JLabel("Admin demo:  admin  /  admin123", SwingConstants.CENTER);
        adminHint.setForeground(Theme.MUTED);
        adminHint.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        addRow(panel, c, adminHint, 0);
        return panel;
    }

    private JPanel createRegisterForm() {
        JPanel panel = formPanel();
        GridBagConstraints c = constraints();
        registerName = addField(panel, c, "Your name", false);
        registerUsername = addField(panel, c, "Choose a username", false);
        registerPassword = (JPasswordField) addField(panel, c, "Password (6+ characters)", true);
        JButton create = Theme.button("Create account", true);
        create.setPreferredSize(new Dimension(300, 44));
        create.addActionListener(event -> register());
        addRow(panel, c, create, 16);
        JButton switchButton = linkButton("Already have an account?  Sign in");
        switchButton.addActionListener(event -> formLayout.show(formCards, "login"));
        addRow(panel, c, switchButton, 0);
        return panel;
    }

    private JPanel formPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        return panel;
    }

    private GridBagConstraints constraints() {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 0, 12, 0);
        return c;
    }

    private JTextField addField(JPanel panel, GridBagConstraints c, String label, boolean password) {
        JLabel fieldLabel = new JLabel(label);
        fieldLabel.setForeground(Theme.MUTED);
        fieldLabel.setFont(Theme.LABEL);
        panel.add(fieldLabel, c);
        c.gridy++;
        JTextField field = password ? new JPasswordField() : new JTextField();
        field.setFont(Theme.BODY);
        field.setForeground(Theme.TEXT);
        field.setCaretColor(Theme.TEXT);
        field.setBackground(Theme.SURFACE_LIGHT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(62, 72, 108)),
                BorderFactory.createEmptyBorder(9, 12, 9, 12)));
        field.setPreferredSize(new Dimension(300, 42));
        panel.add(field, c);
        c.gridy++;
        return field;
    }

    private void addRow(JPanel panel, GridBagConstraints c, java.awt.Component component, int top) {
        c.insets = new Insets(top, 0, 8, 0);
        panel.add(component, c);
        c.gridy++;
    }

    private JButton linkButton(String text) {
        JButton button = new JButton(text);
        button.setForeground(Theme.MUTED);
        button.setBackground(Theme.SURFACE);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        return button;
    }

    private void login() {
        authenticate(() -> authService.login(loginUsername.getText(), new String(loginPassword.getPassword())));
    }

    private void register() {
        authenticate(() -> authService.register(registerUsername.getText(), registerName.getText(),
                new String(registerPassword.getPassword())));
    }

    private void authenticate(AuthAction action) {
        try {
            onAuthenticated.accept(action.run());
        } catch (IllegalArgumentException exception) {
            Theme.showMessageDialog(this, exception.getMessage(), "Please check your details",
                    JOptionPane.WARNING_MESSAGE);
        } catch (IOException exception) {
            Theme.showMessageDialog(this, "Could not save or read your account.\n" + exception.getMessage(),
                    "Storage error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @FunctionalInterface
    private interface AuthAction {
        User run() throws IOException;
    }
}
