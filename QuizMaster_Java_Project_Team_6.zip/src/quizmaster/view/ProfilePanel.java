package quizmaster.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import quizmaster.model.User;
import quizmaster.service.AuthService;
import quizmaster.util.Theme;

@SuppressWarnings("serial")
public final class ProfilePanel extends JPanel {
    private static final Color BACKGROUND = new Color(0x11, 0x16, 0x2B);
    private static final Color CARD = new Color(0x1B, 0x24, 0x40);
    private static final Color INNER = new Color(0x25, 0x2D, 0x49);
    private static final Color ACCENT = new Color(0x75, 0x45, 0xD6);
    private static final Color MAIN_TEXT = Color.WHITE;
    private static final Color SECONDARY_TEXT = new Color(0xAA, 0xB5, 0xD1);

    public ProfilePanel(User user, AuthService authService) {
        setLayout(new BorderLayout(0, 20));
        setBackground(BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(28, 36, 28, 36));

        JLabel heading = new JLabel("My Profile");
        heading.setFont(Theme.TITLE);
        heading.setForeground(MAIN_TEXT);
        heading.setBorder(BorderFactory.createEmptyBorder(0, 0, 18, 0));
        add(heading, BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new javax.swing.BoxLayout(content, javax.swing.BoxLayout.Y_AXIS));
        content.add(createProfileHeader(user));
        content.add(javax.swing.Box.createVerticalStrut(18));
        content.add(createInformationCard(user));
        content.add(javax.swing.Box.createVerticalStrut(16));
        content.add(createSecurityCard(user, authService));
        content.add(javax.swing.Box.createVerticalGlue());
        add(content, BorderLayout.CENTER);
    }

    private JPanel createProfileHeader(User user) {
        RoundedPanel header = new RoundedPanel(CARD, 18);
        header.setLayout(new BorderLayout(18, 0));
        header.setBorder(BorderFactory.createEmptyBorder(20, 22, 20, 22));
        header.add(new Avatar(user.getDisplayName()), BorderLayout.WEST);

        JPanel identity = new JPanel();
        identity.setOpaque(false);
        identity.setLayout(new javax.swing.BoxLayout(identity, javax.swing.BoxLayout.Y_AXIS));
        JLabel name = new JLabel(user.getDisplayName());
        name.setForeground(MAIN_TEXT);
        name.setFont(new Font("Segoe UI", Font.BOLD, 22));
        JLabel username = new JLabel("@" + user.getUsername());
        username.setForeground(SECONDARY_TEXT);
        username.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        identity.add(name);
        identity.add(javax.swing.Box.createVerticalStrut(4));
        identity.add(username);

        JPanel badges = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        badges.setOpaque(false);
        badges.add(createBadge(user.getRole().name(), ACCENT, MAIN_TEXT));
        badges.add(createBadge("Active", INNER, SECONDARY_TEXT));
        identity.add(javax.swing.Box.createVerticalStrut(11));
        identity.add(badges);
        header.add(identity, BorderLayout.CENTER);
        header.setAlignmentX(LEFT_ALIGNMENT);
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        return header;
    }

    private JPanel createInformationCard(User user) {
        RoundedPanel card = createCard();
        card.setLayout(new BorderLayout(0, 14));
        card.add(createCardHeading("Personal Information", null), BorderLayout.NORTH);

        JPanel rows = new JPanel(new GridLayout(3, 1, 0, 8));
        rows.setOpaque(false);
        rows.add(createInformationRow("Full Name", user.getDisplayName()));
        rows.add(createInformationRow("Username", user.getUsername()));
        rows.add(createInformationRow("Account Type", formatRole(user.getRole())));
        card.add(rows, BorderLayout.CENTER);
        card.setAlignmentX(LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 208));
        return card;
    }

    private JPanel createInformationRow(String labelText, String valueText) {
        JPanel row = new JPanel(new BorderLayout(16, 0));
        row.setOpaque(true);
        row.setBackground(INNER);
        row.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        JLabel label = new JLabel(labelText);
        label.setForeground(SECONDARY_TEXT);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JLabel value = new JLabel(valueText, SwingConstants.RIGHT);
        value.setForeground(MAIN_TEXT);
        value.setFont(new Font("Segoe UI", Font.BOLD, 14));
        row.add(label, BorderLayout.WEST);
        row.add(value, BorderLayout.CENTER);
        return row;
    }

    private JPanel createSecurityCard(User user, AuthService authService) {
        RoundedPanel card = createCard();
        card.setLayout(new BorderLayout(0, 12));
        card.add(createCardHeading("Password & Security", "🔒"), BorderLayout.NORTH);

        JPanel details = new JPanel();
        details.setOpaque(false);
        details.setLayout(new javax.swing.BoxLayout(details, javax.swing.BoxLayout.Y_AXIS));
        JLabel description = new JLabel("Keep your account secure by updating your password regularly.");
        description.setForeground(SECONDARY_TEXT);
        description.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        description.setAlignmentX(LEFT_ALIGNMENT);

        JButton changePassword = new JButton("Change Password");
        changePassword.setFont(Theme.LABEL);
        changePassword.setForeground(MAIN_TEXT);
        changePassword.setBackground(ACCENT);
        changePassword.setFocusPainted(false);
        changePassword.setBorderPainted(false);
        changePassword.setOpaque(true);
        changePassword.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        changePassword.setPreferredSize(new Dimension(174, 40));
        changePassword.setMaximumSize(new Dimension(174, 40));
        changePassword.setAlignmentX(LEFT_ALIGNMENT);
        changePassword.addActionListener(event -> changePassword(user, authService));
        details.add(description);
        details.add(javax.swing.Box.createVerticalStrut(14));
        details.add(changePassword);
        card.add(details, BorderLayout.CENTER);
        card.setAlignmentX(LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 152));
        return card;
    }

    private JPanel createCardHeading(String text, String icon) {
        JPanel heading = new JPanel(new BorderLayout(10, 0));
        heading.setOpaque(false);
        JLabel title = new JLabel((icon == null ? "" : icon + "   ") + text);
        title.setForeground(MAIN_TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        heading.add(title, BorderLayout.CENTER);
        return heading;
    }

    private RoundedPanel createCard() {
        RoundedPanel card = new RoundedPanel(CARD, 16);
        card.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        return card;
    }

    private JLabel createBadge(String text, Color background, Color foreground) {
        JLabel badge = new JLabel(text);
        badge.setOpaque(true);
        badge.setBackground(background);
        badge.setForeground(foreground);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badge.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        return badge;
    }

    private String formatRole(User.Role role) {
        String roleName = role.name().toLowerCase(java.util.Locale.ROOT);
        return Character.toUpperCase(roleName.charAt(0)) + roleName.substring(1);
    }

    private void changePassword(User user, AuthService authService) {
        JPasswordField current = new JPasswordField(20);
        JPasswordField next = new JPasswordField(20);
        JPasswordField confirm = new JPasswordField(20);
        JPanel fields = new JPanel(new GridLayout(0, 1, 0, 6));
        fields.setBackground(CARD);
        fields.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        fields.add(dialogLabel("Current password"));
        fields.add(current);
        fields.add(dialogLabel("New password (at least 6 characters)"));
        fields.add(next);
        fields.add(dialogLabel("Confirm new password"));
        fields.add(confirm);
        int choice = Theme.showConfirmDialog(this, fields, "Change password",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }
        if (!java.util.Arrays.equals(next.getPassword(), confirm.getPassword())) {
            Theme.showMessageDialog(this, "The new passwords do not match.",
                    "Password not changed", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            authService.changePassword(user.getUsername(), new String(current.getPassword()),
                    new String(next.getPassword()));
            Theme.showMessageDialog(this, "Your password was changed.",
                    "Password updated", JOptionPane.INFORMATION_MESSAGE);
        } catch (IllegalArgumentException | IOException exception) {
            Theme.showMessageDialog(this, exception.getMessage(),
                    "Password not changed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JLabel dialogLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(MAIN_TEXT);
        return label;
    }

    private static final class Avatar extends JComponent {
        private final String initial;

        private Avatar(String name) {
            String trimmed = name.trim();
            initial = trimmed.isEmpty() ? "?" : trimmed.substring(0, 1).toUpperCase(java.util.Locale.ROOT);
            setPreferredSize(new Dimension(76, 76));
            setMinimumSize(getPreferredSize());
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int diameter = Math.min(getWidth(), getHeight());
            g.setColor(ACCENT);
            g.fillOval(0, 0, diameter, diameter);
            g.setColor(MAIN_TEXT);
            g.setFont(new Font("Segoe UI", Font.BOLD, 28));
            java.awt.FontMetrics metrics = g.getFontMetrics();
            int x = (diameter - metrics.stringWidth(initial)) / 2;
            int y = (diameter - metrics.getHeight()) / 2 + metrics.getAscent();
            g.drawString(initial, x, y);
            g.dispose();
        }
    }

    private static final class RoundedPanel extends JPanel {
        private final Color background;
        private final int radius;

        private RoundedPanel(Color background, int radius) {
            this.background = background;
            this.radius = radius;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(background);
            g.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g.dispose();
            super.paintComponent(graphics);
        }
    }
}
