Option Explicit

Const ForAppending = 8
Const TristateFalse = 0

Dim shell, fileSystem, scriptDirectory, logDirectory, logPath
Dim command, exitCode, quote, errorMessage, runnerPath

On Error Resume Next
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")
If Err.Number <> 0 Then
    errorMessage = Err.Description
    On Error GoTo 0
    MsgBox "QuizMaster could not initialize its Windows launcher." & vbCrLf & errorMessage, _
        vbCritical, "QuizMaster startup error"
    WScript.Quit 1
End If
On Error GoTo 0

scriptDirectory = fileSystem.GetParentFolderName(WScript.ScriptFullName)
logDirectory = fileSystem.BuildPath(scriptDirectory, "logs")
runnerPath = fileSystem.BuildPath(scriptDirectory, "run-hidden.cmd")

On Error Resume Next
If Not fileSystem.FolderExists(logDirectory) Then
    fileSystem.CreateFolder logDirectory
End If
If Err.Number <> 0 Then
    errorMessage = Err.Description
    On Error GoTo 0
    MsgBox "QuizMaster could not create its launch log folder:" & vbCrLf & _
        logDirectory & vbCrLf & errorMessage, _
        vbCritical, "QuizMaster startup error"
    WScript.Quit 1
End If
On Error GoTo 0
logPath = fileSystem.BuildPath(logDirectory, "quizmaster-launch.log")

If Not fileSystem.FileExists(runnerPath) Then
    AppendLog fileSystem, logPath, "Launcher script not found: " & runnerPath
    MsgBox "QuizMaster launcher file is missing:" & vbCrLf & runnerPath & vbCrLf & _
        "Details were saved to:" & vbCrLf & logPath, _
        vbCritical, "QuizMaster startup error"
    WScript.Quit 1
End If

quote = Chr(34)
command = quote & shell.ExpandEnvironmentStrings("%ComSpec%") & quote
command = command & " /d /c " & quote & quote & runnerPath & quote & quote

On Error Resume Next
exitCode = shell.Run(command, 0, True)
If Err.Number <> 0 Then
    errorMessage = Err.Description
    AppendLog fileSystem, logPath, "Launcher error " & Err.Number & ": " & errorMessage
    On Error GoTo 0
    MsgBox "QuizMaster could not be launched." & vbCrLf & _
        "Details were saved to:" & vbCrLf & logPath, _
        vbCritical, "QuizMaster startup error"
    WScript.Quit 1
End If
On Error GoTo 0

If exitCode <> 0 Then
    AppendLog fileSystem, logPath, "QuizMaster exited with code " & exitCode & "."
    MsgBox "QuizMaster could not start successfully (exit code " & exitCode & ")." & _
        vbCrLf & "Details were saved to:" & vbCrLf & logPath, _
        vbCritical, "QuizMaster startup error"
End If

Sub AppendLog(fileSystem, path, message)
    Dim logFile
    On Error Resume Next
    Set logFile = fileSystem.OpenTextFile(path, ForAppending, True, TristateFalse)
    If Err.Number = 0 Then
        logFile.WriteLine message
        logFile.Close
    End If
    On Error GoTo 0
End Sub
