# QuizMaster – Smart Quiz & Exam Practice System

A beginner-friendly desktop quiz application built with Core Java and Swing. It uses no Maven, Gradle, or JavaFX. SQLite JDBC dependencies are included as local JARs.

## Run the application

1. Install a JDK (Java 17 or newer).
2. Double-click `run-hidden.vbs` to launch without a Command Prompt window. It compiles the app and runs it with `javaw`; launch output is saved to `logs\quizmaster-launch.log`, and startup failures are shown in a Windows error dialog.
3. For debugging, run `run.bat` from Command Prompt to see compiler and Java output.
4. QuizMaster stores its SQLite database in `data\quizmaster.sqlite`.

The first launch includes a demo admin account:

- Username: `admin`
- Password: `admin123`

Students can create accounts from the login screen. Data is stored locally in the application's `data` folder.

## Quiz subjects

The application includes 20 multiple-choice questions in each of these subjects:

- General Knowledge
- Mathematics
- English
- Science
- Computer Basics
- History
- Geography
- Reasoning
- Current Affairs
- Basic Programming

The existing Java subject remains available. Each question has four options, a correct answer, a difficulty level, and a short explanation. Choose a 10- or 20-question session from the dashboard; practice mode shows an explanation after you answer.

Existing question files are upgraded on startup without deleting stored questions or scores. Questions that predate difficulty and explanation fields receive a default difficulty and a legacy explanation.

## Project structure

- `src\quizmaster\model` – users, abstract questions and their MCQ/true-false subclasses, quiz sessions, and scores
- `src\quizmaster\view` – Swing screens and dialogs
- `src\quizmaster\controller` – screen flow and quiz actions
- `src\quizmaster\service` – authentication, generic quiz engine, quiz logic, file storage, and SQLite connection/schema
- `src\quizmaster\exception` – custom quiz exceptions
- `src\quizmaster\util` – shared visual theme

## SQLite/JDBC foundation

The local SQLite JDBC driver (`3.50.3.0`) and its SLF4J runtime JARs are in `lib`. `DatabaseConnection` creates and upgrades the SQLite schema in `data\quizmaster.sqlite`; existing question rows receive the `MCQ` type by default. `MigrationService` imports the existing file data transactionally and verifies every imported record; running it again does not insert duplicates. The application now uses SQLite as its primary backend. The existing `.dat` files and verified backup are retained and are not an automatic fallback.

Questions share the abstract `Question` model. `MCQQuestion` and `TrueFalseQuestion` provide their option counts and answer checking; quiz scoring calls the question's overridden answer-checking method. Timed exams use one `QuizTimerThread`, which sends countdown and timeout callbacks to Swing's event-dispatch thread.

The initial migration imported 1 user, 11 categories, 220 questions, 6 quiz attempts, 10 answer reviews, and 2 settings. All original files remain unchanged in `data`; their verified backup is in `backups\before-sqlite-20261110-2229`.

## Student features

- Dashboard statistics show total quizzes, average and highest score, recent activity, and category performance.
- Timed exams last 10 minutes and include a question palette, answer status, review flags, a five-minute warning, and a submission confirmation. Practice mode has no timer and shows explanations after answers.
- Results show percentage, correct/incorrect/unanswered totals, elapsed time, and a review of every saved answer with its explanation.
- Profile settings include account information and password changes. Preferences save the default quiz length and timed-exam notifications.
- Quiz history can be exported to CSV.

Keyboard shortcuts: `Ctrl+1` Dashboard, `Ctrl+2` Quiz history, `Ctrl+3` Profile, `Ctrl+4` Settings, and `Ctrl+L` Log out. Admins can also use `Ctrl+5` for Administration.

## Administration

The admin page summarizes registered students, questions, and quiz attempts. Admins can manage questions and categories, view quiz history, and inspect student performance.

Data remains in the local `data` folder. Existing user, question, and score files are read compatibly; the application adds new optional fields without discarding legacy records.
In the existing question form, a new true/false question uses `True` and `False` as options A and B, leaves C and D empty, and selects A or B as the correct answer.

## Run the smoke tests

From the project directory, compile the application and tests and run the standalone checks:

```bat
javac -Xlint:all -encoding UTF-8 -cp "lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar" -d out -sourcepath "src;tests" src\quizmaster\QuizMasterApp.java tests\quizmaster\service\SmokeTest.java tests\quizmaster\service\SqliteIntegrationTest.java
java --enable-native-access=ALL-UNNAMED -ea -Djava.awt.headless=true -cp "out;lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar;lib\slf4j-nop-1.7.36.jar" quizmaster.service.SmokeTest
java --enable-native-access=ALL-UNNAMED -ea -Djava.awt.headless=true -cp "out;lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-1.7.36.jar;lib\slf4j-nop-1.7.36.jar" quizmaster.service.SqliteIntegrationTest
```
